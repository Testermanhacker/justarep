"""LaunchDarkly SDK and observability plugin setup."""

from __future__ import annotations

import logging
from typing import Optional, Dict, Any

import ldclient
from ldclient.config import Config
from ldclient import Context
from ldobserve import ObservabilityConfig, ObservabilityPlugin, observe
from ldai.client import LDAIClient, AIConfig, ModelConfig, LDMessage, ProviderConfig
from ldai.tracker import TokenUsage, FeedbackKind

from env import env
from logger_setup import logger

# Track which mode we're operating in
_sdk_mode: str = "disabled"  # "full", "observability_only", or "disabled"


def initialize_launchdarkly() -> Optional[ldclient.LDClient]:
    """Initialize LaunchDarkly SDK with observability plugin.

    Supports two modes:
    - Full SDK mode: Uses LAUNCHDARKLY_SDK_KEY for full feature access including AI configs.
    - Observability-only mode: Uses LAUNCHDARKLY_CLIENT_ID for observability features only.

    Returns the LD client if initialized, None otherwise.
    """
    global _sdk_mode

    sdk_key = env.get("LAUNCHDARKLY_SDK_KEY")
    client_id = env.get("LAUNCHDARKLY_CLIENT_ID")

    # Prefer SDK key for full access, fall back to client ID for observability only
    credential = sdk_key or client_id

    if not credential:
        logger.warning(
            "[ld] Neither LAUNCHDARKLY_SDK_KEY nor LAUNCHDARKLY_CLIENT_ID found, "
            "LaunchDarkly features disabled"
        )
        _sdk_mode = "disabled"
        return None

    try:
        # Configure LaunchDarkly with observability plugin
        config = Config(
            credential,
            base_uri="https://relay-prod.ld.catamorphic.com",
            events_uri="https://events.ld.catamorphic.com",
            stream_uri="https://stream.ld.catamorphic.com",
            plugins=[
                ObservabilityPlugin(
                    ObservabilityConfig(
                        environment=env.get("ENVIRONMENT"),
                        service_name=env.get("SERVICE_NAME"),
                        service_version="1.0.0",
                        otlp_endpoint=env.get("OTEL_EXPORTER_OTLP_ENDPOINT"),
                        backend_url="https://pub.observability.app.ld.catamorphic.com",
                    )
                )
            ],
        )

        # Use start_wait=0 to avoid blocking on initialization.
        # In observability-only mode (client ID), the server-side streaming
        # connection won't succeed anyway, so waiting just adds a 5s delay.
        client = ldclient.LDClient(config=config, start_wait=0)

        if sdk_key:
            _sdk_mode = "full"
            logger.info("[ld] LaunchDarkly SDK initialized with full access (SDK key)")
        else:
            _sdk_mode = "observability_only"
            logger.info(
                "[ld] LaunchDarkly SDK initialized with observability only (client ID)"
            )

        return client

    except Exception as e:
        logger.error(f"[ld] Failed to initialize LaunchDarkly: {e}")
        _sdk_mode = "disabled"
        return None


def record_operation_log(
    message: str, level: int = logging.INFO, attributes: Optional[dict] = None
):
    """Record a log entry using LaunchDarkly observability."""
    try:
        observe.record_log(message, level, attributes or {})
    except Exception as e:
        logger.warning(f"[ld] Failed to record log: {e}")


def start_operation_span(operation_name: str, attributes: Optional[dict] = None):
    """Start a span for tracking operations using LaunchDarkly observability."""
    try:
        return observe.start_span(operation_name, attributes=attributes or {})
    except Exception as e:
        logger.warning(f"[ld] Failed to start span: {e}")
        # Return a no-op context manager
        from contextlib import nullcontext

        return nullcontext()


def initialize_ai_client() -> Optional[LDAIClient]:
    """Initialize LaunchDarkly AI Client.

    Only available in full SDK mode (with LAUNCHDARKLY_SDK_KEY).
    Returns None in observability-only mode.
    """
    if not ld_client:
        logger.warning("[ld] Cannot initialize AI client without base LD client")
        return None

    if _sdk_mode != "full":
        logger.info("[ld] AI client not available in observability-only mode")
        return None

    try:
        ai_client = LDAIClient(ld_client)
        logger.info("[ld] LaunchDarkly AI client initialized successfully")
        return ai_client
    except Exception as e:
        logger.error(f"[ld] Failed to initialize LaunchDarkly AI client: {e}")
        return None


def get_ai_config(
    ai_client: LDAIClient,
    config_key: str,
    context_data: Dict[str, Any],
    fallback_config: AIConfig,
    variables: Optional[Dict[str, Any]] = None,
) -> tuple[Optional[AIConfig], Optional[Any]]:
    """
    Generic function to get AI Config from LaunchDarkly.

    Args:
        ai_client: LaunchDarkly AI client instance
        config_key: The AI Config key in LaunchDarkly
        context_data: Context data including project_id, user info, etc.
        fallback_config: Fallback configuration to use if LaunchDarkly is unavailable
        variables: Optional custom variables for template substitution

    Returns:
        Tuple of (config, tracker) or (None, None) if error
    """
    if not ai_client:
        logger.debug(f"[ld] No AI client available for config key: {config_key}")
        return None, None

    try:
        # Build context from provided data
        context_key = context_data.get(
            "context_key", context_data.get("project_id", "default")
        )
        context_builder = Context.builder(context_key)

        # Add any additional context attributes
        for key, value in context_data.items():
            if key not in ["context_key", "project_id"]:
                context_builder.set(key, value)

        context = context_builder.build()

        # Log the context being used for debugging
        logger.debug(
            f"[ld] Getting AI config for key={config_key}, context_key={context_key}, "
            f"context_attrs={list(context_data.keys())}, variables={list(variables.keys()) if variables else []}"
        )

        # Get customized AI config
        config, tracker = ai_client.config(
            config_key, context, fallback_config, variables or {}
        )

        # Log what we got back
        if config:
            logger.debug(
                f"[ld] AI config retrieved for {config_key}: "
                f"enabled={getattr(config, 'enabled', 'N/A')}, "
                f"model={config.model.name if config.model else 'None'}, "
                f"messages_count={len(config.messages) if config.messages else 0}"
            )

            # Log if we're using fallback or actual AI config
            if hasattr(config, "_ldMeta"):
                logger.debug(f"[ld] Using LaunchDarkly AI config for {config_key}")
            else:
                logger.debug(f"[ld] Using fallback config for {config_key}")

            record_operation_log(
                "AI Config retrieved",
                attributes={
                    "config_key": config_key,
                    "context_key": context_key,
                    "model_name": config.model.name if config.model else None,
                    "enabled": getattr(config, "enabled", None),
                    "message_count": len(config.messages) if config.messages else 0,
                    "has_variables": bool(variables),
                    "variable_keys": list(variables.keys()) if variables else [],
                },
            )

        return config, tracker

    except Exception as e:
        logger.error(f"[ld] Failed to get AI config for {config_key}: {e}")
        record_operation_log(
            "AI Config error",
            attributes={
                "config_key": config_key,
                "error": str(e),
                "context_data": context_data,
            },
        )
        return None, None


# Initialize LaunchDarkly on module import
ld_client = initialize_launchdarkly()
ai_client = initialize_ai_client()

__all__ = [
    "ld_client",
    "ai_client",
    "record_operation_log",
    "start_operation_span",
    "get_ai_config",
    "TokenUsage",
    "FeedbackKind",
    "AIConfig",
    "ModelConfig",
    "LDMessage",
    "ProviderConfig",
]
