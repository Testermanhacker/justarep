The `repos` directory is the intended location for any cloned repositories.
