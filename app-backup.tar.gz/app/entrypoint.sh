#!/bin/sh
set -e

# Ensure writable dirs exist on the mounted volumes
mkdir -p /tmp/claude /workspace

# Fix ownership on mounted volumes (Fargate mounts come in as root:root)
chown -R 1001:1001 /tmp /workspace

# Optional: make /tmp behave like normal Linux tmp
chmod 1777 /tmp

# Drop to non-root user for the actual app
exec gosu claude "$@"
