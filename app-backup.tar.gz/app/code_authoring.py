import os
import time
import jwt
import requests
from typing import List, Dict, Any
from urllib.parse import urlencode
from env import env


class GitHubClient:
    """GitHub API client for repository operations using GitHub App authentication."""

    def __init__(self, installation_id: int):
        self.client_id = env.get("GITHUB_CLIENT_ID")
        self.installation_id = installation_id

        if not self.client_id:
            raise ValueError("GITHUB_CLIENT_ID environment variable is required")
        if not self.installation_id:
            raise ValueError("installation_id parameter is required")

    def list_repositories(self, access_token: str) -> List[Dict[str, Any]]:
        """
        List all repositories available to the GitHub App installation using user access token.
        Automatically handles pagination to retrieve all repositories.

        Args:
            access_token: User OAuth access token

        Returns:
            List[Dict[str, Any]]: List of repository information dictionaries
        """
        try:
            # Use GitHub REST API to list installation repositories (user-scoped)
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github.v3+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }

            repo_list = []
            # Start with the first page
            url = f"https://api.github.com/user/installations/{self.installation_id}/repositories?per_page=100"

            while url:
                response = requests.get(url, headers=headers)
                response.raise_for_status()

                repositories_data = response.json()

                # Convert to list of dictionaries with relevant information
                for repo in repositories_data.get("repositories", []):
                    repo_info = {
                        "id": repo.get("id"),
                        "name": repo.get("name"),
                        "full_name": repo.get("full_name"),
                        "description": repo.get("description"),
                        "private": repo.get("private"),
                        "html_url": repo.get("html_url"),
                        "clone_url": repo.get("clone_url"),
                        "ssh_url": repo.get("ssh_url"),
                        "default_branch": repo.get("default_branch"),
                        "language": repo.get("language"),
                        "created_at": repo.get("created_at"),
                        "updated_at": repo.get("updated_at"),
                        "size": repo.get("size"),
                        "stargazers_count": repo.get("stargazers_count"),
                        "forks_count": repo.get("forks_count"),
                        "open_issues_count": repo.get("open_issues_count"),
                    }
                    repo_list.append(repo_info)

                # Check for next page in Link header
                url = None
                if "Link" in response.headers:
                    links = response.headers["Link"]
                    # Parse Link header to find 'next' link
                    for link in links.split(","):
                        if 'rel="next"' in link:
                            # Extract URL from <URL>
                            url = link[link.find("<") + 1 : link.find(">")]
                            break

            return repo_list

        except Exception as e:
            print(f"Error listing repositories: {e}")
            raise

    def create_pull_request(
        self,
        access_token: str,
        repo_owner: str,
        repo_name: str,
        title: str,
        body: str,
        head_branch: str,
        base_branch: str = "main",
        draft: bool = False,
        maintainer_can_modify: bool = True,
    ) -> Dict[str, Any]:
        """
        Create a pull request in a GitHub repository using user OAuth token.

        Args:
            access_token: User OAuth access token
            repo_owner: Repository owner (username or organization)
            repo_name: Repository name
            title: Pull request title
            body: Pull request description/body
            head_branch: Source branch (the branch with changes)
            base_branch: Target branch (default: "main")
            draft: Whether to create as draft PR (default: False)
            maintainer_can_modify: Allow maintainers to modify PR (default: True)

        Returns:
            Dict[str, Any]: Pull request information
        """
        try:
            # Use GitHub REST API to create pull request with user OAuth token
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github.v3+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }

            # Prepare pull request data
            pr_data = {
                "title": title,
                "body": body,
                "head": head_branch,
                "base": base_branch,
                "draft": draft,
                "maintainer_can_modify": maintainer_can_modify,
            }

            # Create pull request
            url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls"
            response = requests.post(url, headers=headers, json=pr_data)
            response.raise_for_status()

            pr_info = response.json()

            # Return formatted pull request information
            return {
                "id": pr_info.get("id"),
                "number": pr_info.get("number"),
                "title": pr_info.get("title"),
                "body": pr_info.get("body"),
                "state": pr_info.get("state"),
                "draft": pr_info.get("draft"),
                "html_url": pr_info.get("html_url"),
                "head_branch": pr_info.get("head", {}).get("ref"),
                "base_branch": pr_info.get("base", {}).get("ref"),
                "created_at": pr_info.get("created_at"),
                "updated_at": pr_info.get("updated_at"),
                "user": pr_info.get("user", {}).get("login"),
                "mergeable": pr_info.get("mergeable"),
                "mergeable_state": pr_info.get("mergeable_state"),
                "commits": pr_info.get("commits"),
                "additions": pr_info.get("additions"),
                "deletions": pr_info.get("deletions"),
                "changed_files": pr_info.get("changed_files"),
            }

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 422:
                # Validation failed - likely branch doesn't exist or PR already exists
                error_details = e.response.json()
                raise ValueError(
                    f"Pull request creation failed: {error_details.get('message', 'Validation error')}"
                )
            elif e.response.status_code == 404:
                raise ValueError(
                    f"Repository {repo_owner}/{repo_name} not found or not accessible"
                )
            elif e.response.status_code == 403:
                raise ValueError(
                    f"Permission denied. Check if the GitHub App has write access to {repo_owner}/{repo_name}"
                )
            else:
                raise ValueError(f"HTTP {e.response.status_code}: {e.response.text}")
        except Exception as e:
            raise ValueError(f"Error creating pull request: {e}")

    def create_issue(
        self,
        access_token: str,
        repo_owner: str,
        repo_name: str,
        title: str,
        body: str,
    ) -> Dict[str, Any]:
        """
        Create an issue in a GitHub repository using GraphQL API.

        Args:
            repo_owner: Repository owner (username or organization)
            repo_name: Repository name
            title: Issue title
            body: Issue description/body

        Returns:
            Dict[str, Any]: Issue information
        """
        try:
            # Use GitHub GraphQL API
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
            }
            graphql_url = "https://api.github.com/graphql"

            # Step 1: Get repository ID and Copilot bot ID
            repo_query = """
            query($owner: String!, $name: String!) {
              repository(owner: $owner, name: $name) {
                id
                suggestedActors(capabilities: [CAN_BE_ASSIGNED], first: 100) {
                  nodes {
                    login
                    __typename
                    ... on Bot {
                      id
                    }
                    ... on User {
                      id
                    }
                  }
                }
              }
            }
            """

            repo_response = requests.post(
                graphql_url,
                headers=headers,
                json={
                    "query": repo_query,
                    "variables": {
                        "owner": repo_owner,
                        "name": repo_name,
                    },
                },
            )
            repo_response.raise_for_status()
            repo_data = repo_response.json()

            if "errors" in repo_data:
                raise ValueError(f"GraphQL error: {repo_data['errors']}")

            repository = repo_data["data"]["repository"]
            repository_id = repository["id"]

            # Step 2: Find Copilot bot ID from suggested actors
            bot_id = None
            suggested_actors = repository.get("suggestedActors", {}).get("nodes", [])

            for actor in suggested_actors:
                if actor.get("login") == "copilot-swe-agent":
                    bot_id = actor.get("id")
                    break

            # Step 3: Create issue with optional bot assignee
            create_mutation = """
            mutation($repositoryId: ID!, $title: String!, $body: String!, $assigneeIds: [ID!]) {
              createIssue(input: {repositoryId: $repositoryId, title: $title, body: $body, assigneeIds: $assigneeIds}) {
                issue {
                  id
                  number
                  title
                  body
                  state
                  url
                  createdAt
                  updatedAt
                  author {
                    login
                  }
                  assignees(first: 10) {
                    nodes {
                      login
                    }
                  }
                }
              }
            }
            """

            # Prepare variables - only include assigneeIds if bot_id is found
            mutation_variables = {
                "repositoryId": repository_id,
                "title": title,
                "body": body,
                "assigneeIds": [bot_id] if bot_id else [],
            }

            create_response = requests.post(
                graphql_url,
                headers=headers,
                json={
                    "query": create_mutation,
                    "variables": mutation_variables,
                },
            )
            create_response.raise_for_status()
            create_data = create_response.json()

            if "errors" in create_data:
                raise ValueError(f"GraphQL error: {create_data['errors']}")

            issue_info = create_data["data"]["createIssue"]["issue"]

            # Return formatted issue information
            return {
                "id": issue_info.get("id"),
                "number": issue_info.get("number"),
                "title": issue_info.get("title"),
                "body": issue_info.get("body"),
                "state": issue_info.get("state"),
                "html_url": issue_info.get("url"),
                "created_at": issue_info.get("createdAt"),
                "updated_at": issue_info.get("updatedAt"),
                "user": issue_info.get("author", {}).get("login"),
                "labels": [],  # Labels would need to be added separately in GraphQL
                "assignees": [
                    assignee.get("login")
                    for assignee in issue_info.get("assignees", {}).get("nodes", [])
                ],
                "milestone": None,
                "comments": 0,
            }

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 422:
                # Validation failed
                error_details = e.response.json()
                raise ValueError(
                    f"Issue creation failed: {error_details.get('message', 'Validation error')}"
                )
            elif e.response.status_code == 404:
                raise ValueError(
                    f"Repository {repo_owner}/{repo_name} not found or not accessible"
                )
            elif e.response.status_code == 403:
                raise ValueError(
                    f"Permission denied. Check if the GitHub App has write access to {repo_owner}/{repo_name}"
                )
            else:
                raise ValueError(f"HTTP {e.response.status_code}: {e.response.text}")
        except Exception as e:
            raise ValueError(f"Error creating issue: {e}")

    def search_code(
        self,
        access_token: str,
        query: str,
        max_results: int = 30,
    ) -> Dict[str, Any]:
        """
        Search for code within all repositories accessible to the GitHub App installation, including public repositories.
        Note: You will generally want to add repository filters to the query to limit the results to the repositories you are interested in.
        Include as many or as few filters as you need.
        Example: "language:python path:src/ repo:org-name/repo-name config"

        Args:
            access_token: User OAuth access token
            query: GitHub code search query (supports full GitHub search syntax)
            max_results: Maximum number of results to return (default: 30, max: 100)

        Returns:
            Dict[str, Any]: Search results with repositories, file paths, and code snippets
        """
        try:
            # GitHub's code search API has a maximum of 100 results per page
            max_results = min(max_results, 100)
            per_page = min(max_results, 100)

            # Use GitHub REST API to search code
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github.text-match+json",  # Include text matches
                "X-GitHub-Api-Version": "2022-11-28",
            }

            # Build the search query
            search_params = {
                "q": query,
                "per_page": per_page,
                "page": 1,
            }

            all_items = []
            total_count = 0

            # Fetch results (handle pagination if needed)
            while len(all_items) < max_results:
                url = "https://api.github.com/search/code"

                response = requests.get(url, headers=headers, params=search_params)
                response.raise_for_status()

                search_data = response.json()
                total_count = search_data.get("total_count", 0)
                items = search_data.get("items", [])

                if not items:
                    break

                all_items.extend(items)

                # Check if we have more pages
                if len(all_items) >= total_count or len(items) < per_page:
                    break

                # Move to next page
                search_params["page"] += 1

                # Don't exceed max_results
                if len(all_items) >= max_results:
                    all_items = all_items[:max_results]
                    break

            # Format results
            results = []
            for item in all_items:
                repo = item.get("repository", {})
                text_matches = item.get("text_matches", [])

                # Extract code snippets from text matches
                snippets = []
                for match in text_matches:
                    snippet = {
                        "fragment": match.get("fragment", ""),
                        "matches": match.get("matches", []),
                    }
                    snippets.append(snippet)

                result = {
                    "repository": {
                        "full_name": repo.get("full_name"),
                        "name": repo.get("name"),
                        "owner": repo.get("owner", {}).get("login"),
                        "description": repo.get("description"),
                        "html_url": repo.get("html_url"),
                        "private": repo.get("private"),
                    },
                    "file_path": item.get("path"),
                    "file_name": item.get("name"),
                    "html_url": item.get("html_url"),
                    "git_url": item.get("git_url"),
                    "sha": item.get("sha"),
                    "code_snippets": snippets,
                }
                results.append(result)

            return {
                "total_count": total_count,
                "results_returned": len(results),
                "results": results,
            }

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 422:
                # Validation failed - likely invalid search query
                error_details = e.response.json()
                raise ValueError(
                    f"Code search failed: {error_details.get('message', 'Invalid query')}"
                )
            elif e.response.status_code == 403:
                # Rate limit or permission denied
                error_details = e.response.json()
                if "rate limit" in error_details.get("message", "").lower():
                    raise ValueError(
                        "GitHub API rate limit exceeded. Please try again later."
                    )
                else:
                    raise ValueError(
                        f"Permission denied: {error_details.get('message', 'Access denied')}"
                    )
            elif e.response.status_code == 503:
                raise ValueError(
                    "GitHub code search service is temporarily unavailable. Please try again later."
                )
            else:
                raise ValueError(f"HTTP {e.response.status_code}: {e.response.text}")
        except Exception as e:
            raise ValueError(f"Error searching code: {e}")

    def search_pull_requests(
        self,
        access_token: str,
        repo_owner: str,
        repo_name: str,
        state: str = "open",
        labels: List[str] | None = None,
        title_contains: str | None = None,
        max_results: int = 30,
    ) -> Dict[str, Any]:
        """
        Search for pull requests in a GitHub repository with optional filtering.

        Args:
            access_token: User OAuth access token
            repo_owner: Repository owner (username or organization)
            repo_name: Repository name
            state: PR state filter - "open", "closed", or "all" (default: "open")
            labels: List of label names to filter by (PRs must have all labels)
            title_contains: Filter PRs whose title contains this substring (case-insensitive)
            max_results: Maximum number of results to return (default: 30, max: 100)

        Returns:
            Dict[str, Any]: Search results with PR information
        """
        try:
            # Validate state parameter
            if state not in ["open", "closed", "all"]:
                raise ValueError(
                    f"Invalid state '{state}'. Must be 'open', 'closed', or 'all'"
                )

            # Cap max_results at 100
            max_results = min(max_results, 100)
            per_page = min(max_results, 100)

            # Use GitHub REST API to list pull requests
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github.v3+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }

            all_prs = []
            page = 1

            while len(all_prs) < max_results:
                # Build URL with query parameters
                url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls"
                params = {
                    "state": state,
                    "per_page": per_page,
                    "page": page,
                    "sort": "created",
                    "direction": "desc",
                }

                response = requests.get(url, headers=headers, params=params)
                response.raise_for_status()

                prs = response.json()

                if not prs:
                    break

                # Filter by labels if specified
                if labels:
                    prs = [
                        pr
                        for pr in prs
                        if all(
                            label_name in [l.get("name") for l in pr.get("labels", [])]
                            for label_name in labels
                        )
                    ]

                # Filter by title if specified
                if title_contains:
                    title_lower = title_contains.lower()
                    prs = [
                        pr for pr in prs if title_lower in pr.get("title", "").lower()
                    ]

                all_prs.extend(prs)

                # Check if we have more pages
                if len(response.json()) < per_page:
                    break

                page += 1

                # Don't exceed max_results
                if len(all_prs) >= max_results:
                    all_prs = all_prs[:max_results]
                    break

            # Format results
            results = []
            for pr in all_prs:
                result = {
                    "number": pr.get("number"),
                    "title": pr.get("title"),
                    "state": pr.get("state"),
                    "draft": pr.get("draft"),
                    "html_url": pr.get("html_url"),
                    "head_branch": pr.get("head", {}).get("ref"),
                    "base_branch": pr.get("base", {}).get("ref"),
                    "created_at": pr.get("created_at"),
                    "updated_at": pr.get("updated_at"),
                    "user": pr.get("user", {}).get("login"),
                    "labels": [l.get("name") for l in pr.get("labels", [])],
                    "body": pr.get("body"),
                }
                results.append(result)

            return {
                "total_count": len(results),
                "results": results,
            }

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise ValueError(
                    f"Repository {repo_owner}/{repo_name} not found or not accessible"
                )
            elif e.response.status_code == 403:
                error_details = e.response.json()
                if "rate limit" in error_details.get("message", "").lower():
                    raise ValueError(
                        "GitHub API rate limit exceeded. Please try again later."
                    )
                else:
                    raise ValueError(
                        f"Permission denied: {error_details.get('message', 'Access denied')}"
                    )
            else:
                raise ValueError(f"HTTP {e.response.status_code}: {e.response.text}")
        except Exception as e:
            raise ValueError(f"Error searching pull requests: {e}")

    def add_labels_to_pull_request(
        self,
        access_token: str,
        repo_owner: str,
        repo_name: str,
        pr_number: int,
        labels: List[str],
    ) -> Dict[str, Any]:
        """
        Add labels to a pull request in a GitHub repository.

        Note: GitHub PRs use the issues API for labels since PRs are backed by issues.

        Args:
            access_token: User OAuth access token
            repo_owner: Repository owner (username or organization)
            repo_name: Repository name
            pr_number: Pull request number
            labels: List of label names to add

        Returns:
            Dict[str, Any]: List of all labels on the PR after addition
        """
        try:
            # Use GitHub REST API to add labels (using issues endpoint)
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/vnd.github.v3+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }

            # Add labels to the PR (PRs use issue numbers)
            url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/issues/{pr_number}/labels"
            response = requests.post(url, headers=headers, json={"labels": labels})
            response.raise_for_status()

            label_data = response.json()

            # Return formatted label information
            return {
                "labels": [label.get("name") for label in label_data],
                "pr_number": pr_number,
            }

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                raise ValueError(
                    f"Repository {repo_owner}/{repo_name} or PR #{pr_number} not found"
                )
            elif e.response.status_code == 403:
                raise ValueError(
                    f"Permission denied. Check if the user has write access to {repo_owner}/{repo_name}"
                )
            elif e.response.status_code == 422:
                error_details = e.response.json()
                raise ValueError(
                    f"Failed to add labels: {error_details.get('message', 'Validation error')}"
                )
            else:
                raise ValueError(f"HTTP {e.response.status_code}: {e.response.text}")
        except Exception as e:
            raise ValueError(f"Error adding labels to pull request: {e}")
