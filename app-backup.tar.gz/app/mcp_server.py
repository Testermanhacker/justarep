import asyncio
import json
from pathlib import Path
from typing import Any, Optional

import aiohttp
import boto3
from fastmcp import FastMCP
from fastmcp.server.dependencies import get_http_headers

# GQL library imports
from gql import Client, gql
from gql.transport.aiohttp import AIOHTTPTransport

# OpenTelemetry instrumentation
from opentelemetry.instrumentation.anthropic import AnthropicInstrumentor
from starlette.requests import Request

from otel_middleware import OpenTelemetryMiddleware
from starlette.responses import JSONResponse

from claude_code_defaults import (
    REQUEST_TYPE_INVESTIGATE_WITH_CODE,
    REQUEST_TYPE_FIX,
    REQUEST_TYPE_FLAG_CLEANUP,
)
from env import env
from json_cleaner import (
    clean_logs_response,
    clean_metrics_response,
    clean_error_groups_response,
    clean_sessions_response,
    clean_traces_response,
    clean_timeline_indicator_events_response,
    clean_flag_evaluations_response,
    clean_visualization_response,
    clean_visualizations_list_response,
    estimate_token_reduction,
)

# LaunchDarkly instrumentation imports
from launchdarkly_setup import (
    record_operation_log,
    start_operation_span,
    ai_client,
    get_ai_config,
)
from logger_setup import logger

# Import utilities
from mcp_formatters import resolve_date_range

# Initialize Anthropic instrumentation
AnthropicInstrumentor().instrument()

# Module-specific defaults
from mcp_server_defaults import (
    get_default_tool_config,
    LOGS_DEFAULT_DESCRIPTION,
    METRICS_DEFAULT_DESCRIPTION,
    TRACES_DEFAULT_DESCRIPTION,
    ERROR_GROUPS_DEFAULT_DESCRIPTION,
    SESSIONS_DEFAULT_DESCRIPTION,
    TIMELINE_INDICATOR_EVENTS_DEFAULT_DESCRIPTION,
    FLAG_EVALUATIONS_DEFAULT_DESCRIPTION,
    LIST_DASHBOARDS_DEFAULT_DESCRIPTION,
    GET_DASHBOARD_DEFAULT_DESCRIPTION,
    CREATE_DASHBOARD_DEFAULT_DESCRIPTION,
    CREATE_GRAPH_DEFAULT_DESCRIPTION,
    GET_KEYS_DEFAULT_DESCRIPTION,
)

# Import the GitHubClient from code_authoring
from code_authoring import GitHubClient

# ---------------------------------------------------------------------------
# Server metadata
# ---------------------------------------------------------------------------

# Note: Logging setup is now handled by the centralized logging module

mcp = FastMCP(name="observability")
mcp.add_middleware(OpenTelemetryMiddleware())
logger.info("[mcp] Initialized FastMCP server: observability")

# ---------------------------------------------------------------------------
# Configuration – GraphQL endpoint + token
# ---------------------------------------------------------------------------

GRAPHQL_ENDPOINT: str = env["HIGHLIGHT_GRAPHQL_ENDPOINT"]
logger.info(f"[mcp] GraphQL endpoint: {GRAPHQL_ENDPOINT}")

# GraphQL execution timeout in seconds
GRAPHQL_EXECUTE_TIMEOUT_SECONDS = 59

# Operations directory
OPERATIONS_DIR = Path(__file__).resolve().parent / "operations"

MCP_ERRORS = [
    "github_refresh_token_missing",
    "github_refresh_token_expired",
]

# Vega PR identification constants
VEGA_PR_TITLE_PREFIX = "[Vega]"
VEGA_PR_LABEL = "vega-pr"


def get_aws_session():
    """Get AWS session with credentials for IAM signing."""
    try:
        # Create a boto3 session using default credential chain
        # This will look for credentials in environment variables, ~/.aws/credentials,
        # IAM roles, etc.
        session = boto3.Session(region_name=env["AWS_REGION"])
        return session
    except Exception as e:
        logger.error(f"[mcp] Failed to create AWS session: {e}")
        raise RuntimeError(f"Failed to create AWS session: {e}")


async def get_project_id_from_headers():
    """Extract project_id from request headers."""
    headers = get_http_headers()
    project_id = headers.get("x-project-id")
    if not project_id:
        logger.error(f"[mcp] Missing X-Project-Id header in request")
        raise RuntimeError("Missing X-Project-Id header")
    logger.debug(f"[mcp] Extracted project_id: {project_id}")
    return project_id


def get_allowed_repositories_from_headers() -> list[str] | None:
    """Extract allowed repositories from request headers.

    Returns:
        List of allowed repository full names (e.g., ['owner/repo1', 'owner/repo2']),
        or None if no restriction is specified.
    """
    headers = get_http_headers()
    allowed_repos = headers.get("x-allowed-repositories")
    if not allowed_repos:
        logger.debug("[mcp] No x-allowed-repositories header, no repository filtering")
        return None

    repos = [r.strip() for r in allowed_repos.split(",") if r.strip()]
    logger.info(f"[mcp] Allowed repositories from headers: {repos}")
    return repos if repos else None


def validate_github_read_operation_allowed(operation_name: str):
    """Validate that GitHub read operations (code search, repo listing) are allowed.

    Allowed in: InvestigateWithCode, Fix, FlagCleanup
    NOT allowed in: Investigate

    Args:
        operation_name: Name of the operation being performed (for logging)

    Raises:
        RuntimeError: If the operation is not allowed in the current request mode
    """
    headers = get_http_headers()
    request_type = headers.get("x-request-type", "")

    # GitHub read operations NOT allowed in basic Investigate mode
    allowed_modes = [
        REQUEST_TYPE_INVESTIGATE_WITH_CODE,
        REQUEST_TYPE_FIX,
        REQUEST_TYPE_FLAG_CLEANUP,
    ]

    if request_type not in allowed_modes:
        error_msg = (
            f"Operation '{operation_name}' is not allowed in request mode '{request_type}'. "
            f"This operation requires one of: {allowed_modes}. "
            f"GitHub code access is not permitted in Investigate mode."
        )
        logger.error(f"[mcp] {error_msg}")
        raise RuntimeError(error_msg)

    logger.debug(
        f"[mcp] GitHub read operation '{operation_name}' authorized for request mode '{request_type}'"
    )


def validate_pr_creation_allowed(operation_name: str):
    """Validate that PR creation is allowed.

    Allowed ONLY in: Fix, FlagCleanup
    NOT allowed in: Investigate, InvestigateWithCode

    Args:
        operation_name: Name of the operation being performed (for logging)

    Raises:
        RuntimeError: If the operation is not allowed in the current request mode
    """
    headers = get_http_headers()
    request_type = headers.get("x-request-type", "")

    # PR creation only allowed in Fix or FlagCleanup mode
    allowed_modes = [REQUEST_TYPE_FIX, REQUEST_TYPE_FLAG_CLEANUP]

    if request_type not in allowed_modes:
        error_msg = (
            f"Operation '{operation_name}' is not allowed in request mode '{request_type}'. "
            f"PR creation requires Fix or FlagCleanup mode."
        )
        logger.error(f"[mcp] {error_msg}")
        raise RuntimeError(error_msg)

    logger.debug(
        f"[mcp] PR creation '{operation_name}' authorized for request mode '{request_type}'"
    )


# ---------------------------------------------------------------------------
# Helper – perform GraphQL POST
# ---------------------------------------------------------------------------


async def _graphql_request(query: str, variables: dict[str, Any]) -> dict[str, Any]:
    """
    Async wrapper around GraphQL client using GQL library with LaunchDarkly instrumentation.
    """

    with start_operation_span(
        "graphql_request",
        {
            "query_length": len(query),
            "variable_count": len(variables),
            "endpoint": GRAPHQL_ENDPOINT,
        },
    ):
        logger.debug(f"[mcp] Making GraphQL request")

        try:
            # Extract project_id from headers for the shared client
            headers = get_http_headers()
            project_id = headers.get("x-project-id")

            # Convert headers to a regular dict
            mcp_headers = dict(headers)

            # Set up headers
            gql_headers = {"Content-Type": "application/json"}
            for k, v in mcp_headers.items():
                if k.lower() not in ["content-type"]:
                    gql_headers[k] = v
            if project_id:
                gql_headers["x-project-id"] = project_id

            # Use the query content as-is (already loaded from files at startup)
            query_content = query

            # Configure transport
            transport = AIOHTTPTransport(url=GRAPHQL_ENDPOINT, headers=gql_headers)

            # Create client and execute query
            client = Client(
                transport=transport,
                fetch_schema_from_transport=False,
                execute_timeout=GRAPHQL_EXECUTE_TIMEOUT_SECONDS,
            )
            async with client as session:
                result = await session.execute(
                    gql(query_content), variable_values=variables
                )

                record_operation_log(
                    "GraphQL request successful",
                    attributes={
                        "query_length": len(query),
                        "variable_count": len(variables),
                    },
                )

                return result

        except asyncio.TimeoutError as e:
            logger.warning(
                f"[mcp] GraphQL request timed out after {GRAPHQL_EXECUTE_TIMEOUT_SECONDS} seconds: {e}"
            )
            record_operation_log(
                "GraphQL request timeout",
                attributes={
                    "timeout_seconds": GRAPHQL_EXECUTE_TIMEOUT_SECONDS,
                    "query_length": len(query),
                    "variable_count": len(variables),
                },
            )
            raise RuntimeError(
                f"GraphQL request timed out after {GRAPHQL_EXECUTE_TIMEOUT_SECONDS} seconds. The query may be too complex or the server may be overloaded. Please try again or simplify the query."
            )
        except Exception as e:
            logger.error(f"[mcp] Error in GraphQL client: {e}")
            record_operation_log("GraphQL request error", attributes={"error": str(e)})
            raise RuntimeError(f"GraphQL request failed: {e}")


# ---------------------------------------------------------------------------
# Helper – get GitHub installation ID
# ---------------------------------------------------------------------------


async def get_github_installation_id(project_id: str) -> int:
    """
    Fetch the GitHub installation ID using GraphQL resolver.

    Args:
        project_id: The project ID to get the installation ID for

    Returns:
        int: GitHub installation ID

    Raises:
        ValueError: If installation ID cannot be fetched or is invalid
    """
    try:
        # GraphQL query to get GitHub installation ID
        query = """
        query GetGithubInstallationId($project_id: StringID!) {
            github_installation_id(project_id: $project_id)
        }
        """

        variables = {"project_id": project_id}

        # Execute query using shared GraphQL client
        result = await _graphql_request(query, variables)

        # Extract installation ID from response
        if "github_installation_id" in result:
            installation_id = result["github_installation_id"]
            if installation_id:
                logger.info(
                    f"Fetched GitHub installation ID: {installation_id} for project: {project_id}"
                )
                return int(installation_id)

        raise ValueError(
            f"No installation_id found in GraphQL response for project: {project_id}"
        )

    except Exception as e:
        logger.error(
            f"Failed to fetch GitHub installation ID for project {project_id}: {e}"
        )
        raise ValueError(f"Failed to fetch installation ID via GraphQL: {e}")


async def get_github_access_token() -> str:
    """
    Fetch the GitHub user access token using GraphQL resolver.

    This function retrieves a GitHub OAuth access token for the current user.
    The token is cached in Redis and automatically refreshed if expired.

    Returns:
        str: GitHub user access token

    Raises:
        ValueError: If the user needs to authorize GitHub access or if token cannot be fetched
    """
    try:
        # GraphQL query to get GitHub auth token
        query = """
        query GetGithubAuthToken {
            github_access_token
        }
        """

        # Execute query using shared GraphQL client
        result = await _graphql_request(query, {})

        # Extract auth token from response
        if "github_access_token" in result:
            auth_token = result["github_access_token"]
            if auth_token:
                logger.info("Successfully fetched GitHub auth token")
                return auth_token

        raise ValueError("No github_access_token found in GraphQL response")

    except Exception as e:
        error_message = str(e)

        # Check for specific error conditions that require reauthorization
        if "github_refresh_token_missing" in error_message:
            logger.warning("User has not authorized GitHub access")
            raise ValueError(
                f"github_refresh_token_missing: https://github.com/login/oauth/authorize?client_id={env.get('GITHUB_CLIENT_ID')}"
            )
        elif "github_refresh_token_expired" in error_message:
            logger.warning("GitHub refresh token has expired")
            raise ValueError(
                f"github_refresh_token_expired: https://github.com/login/oauth/authorize?client_id={env.get('GITHUB_CLIENT_ID')}"
            )

        # Generic error
        logger.error(f"Failed to fetch GitHub auth token: {e}")
        raise ValueError(f"Failed to fetch GitHub auth token via GraphQL: {e}")


async def get_ld_api_token() -> str:
    """
    Fetch the LaunchDarkly API token (ldso cookie) using GraphQL resolver.

    This function exchanges the ob_ldso cookie for the main ldso cookie that was
    stored in Redis when the user initiated the agent session. This allows the
    MCP service to make Gonfalon API calls without the ldso cookie being exposed
    to the untrusted autofix sandbox.

    Returns:
        str: LaunchDarkly API token (ldso cookie value)

    Raises:
        ValueError: If the token cannot be fetched (e.g., not stored or expired)
    """
    try:
        # GraphQL query to get LD API token
        query = """
        query GetLdApiToken {
            ld_api_token
        }
        """

        # Execute query using shared GraphQL client
        result = await _graphql_request(query, {})

        # Extract token from response
        if "ld_api_token" in result:
            api_token = result["ld_api_token"]
            if api_token:
                logger.info("Successfully fetched LD API token via secure exchange")
                return api_token

        raise ValueError("No ld_api_token found in GraphQL response")

    except Exception as e:
        error_message = str(e)

        # Check for specific error conditions
        if "ldso_token_not_found" in error_message:
            logger.warning("LDSO token not found in Redis - session may have expired")
            raise ValueError(
                "ldso_token_not_found: LaunchDarkly API token not available. The session may have expired."
            )
        elif "ldso_token_missing" in error_message:
            logger.warning("Not authenticated with LDSO")
            raise ValueError("ldso_token_missing: Not authenticated with LaunchDarkly.")

        # Generic error
        logger.error(f"Failed to fetch LD API token: {e}")
        raise ValueError(f"Failed to fetch LD API token via GraphQL: {e}")


# ---------------------------------------------------------------------------
# Load GraphQL operation texts
# ---------------------------------------------------------------------------

_base_dir = Path(__file__).resolve().parent
LOGS_QUERY: str = (_base_dir / "operations" / "logs.graphql").read_text()
METRICS_QUERY: str = (_base_dir / "operations" / "metrics.graphql").read_text()
TRACES_QUERY: str = (_base_dir / "operations" / "traces.graphql").read_text()
ERROR_GROUPS_QUERY: str = (
    _base_dir / "operations" / "error_groups.graphql"
).read_text()
SESSIONS_QUERY: str = (_base_dir / "operations" / "sessions.graphql").read_text()
# SESSION_SUMMARY_QUERY: str = (
#     _base_dir / "operations" / "session_summary.graphql"
# ).read_text()
TIMELINE_INDICATOR_EVENTS_QUERY: str = (
    _base_dir / "operations" / "timeline_indicator_events.graphql"
).read_text()
FLAG_EVALUATIONS_QUERY: str = (
    _base_dir / "operations" / "flag_evaluations.graphql"
).read_text()
VISUALIZATIONS_QUERY: str = (
    _base_dir / "operations" / "visualizations.graphql"
).read_text()
LOGS_KEYS_QUERY: str = (_base_dir / "operations" / "logs_keys.graphql").read_text()
TRACES_KEYS_QUERY: str = (_base_dir / "operations" / "traces_keys.graphql").read_text()
SESSIONS_KEYS_QUERY: str = (
    _base_dir / "operations" / "sessions_keys.graphql"
).read_text()
ERROR_GROUPS_KEYS_QUERY: str = (
    _base_dir / "operations" / "error_groups_keys.graphql"
).read_text()
METRICS_KEYS_QUERY: str = (
    _base_dir / "operations" / "metrics_keys.graphql"
).read_text()


# Try to load from in-docker path first, fallback to relative path
def _load_prompt_file(filename: str) -> str:
    """Load prompt file from in-docker path, falling back to relative path."""
    # Try in-docker path first
    docker_path = _base_dir / "prompts" / filename
    if docker_path.exists():
        return docker_path.read_text()

    # Fallback to existing relative path
    fallback_path = _base_dir / ".." / ".." / "backend" / "prompts" / filename
    return fallback_path.read_text()


QUERY_SYNTAX: str = _load_prompt_file("search_cleaned.md")
LOGS_QUERY_SYNTAX: str = _load_prompt_file("log-search_cleaned.md")


# ---------------------------------------------------------------------------
# Tool: logs
# ---------------------------------------------------------------------------


# Helper function to get tool description from AI Config
def _get_tool_description(tool_name: str, default_description: str) -> str:
    """Get tool description from AI Config or use default."""
    try:
        if ai_client:
            # Try to get project_id from environment or default
            context_data = {
                "context_key": f"mcp-server-{tool_name}",
                "tool_name": tool_name,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            config, tracker = get_ai_config(
                ai_client,
                f"mcp-tool-{tool_name}-description",
                context_data,
                get_default_tool_config(tool_name),
                {
                    "query_syntax": QUERY_SYNTAX,
                    "logs_query_syntax": (
                        LOGS_QUERY_SYNTAX
                        if tool_name
                        in [
                            "logs",
                            "traces",
                            "error_groups",
                            "sessions",
                            # "session_summary",
                            "timeline_indicator_events",
                            "flag_evaluations",
                        ]
                        else ""
                    ),
                },
            )

            if config and config.messages:
                description = config.messages[0].content
                logger.info(f"[mcp] Using AI Config description for {tool_name} tool")
                logger.debug(
                    f"[mcp] {tool_name} tool description length: {len(description)} chars"
                )
                logger.debug(
                    f"[mcp] {tool_name} description preview: {description[:300]}..."
                    if len(description) > 300
                    else f"[mcp] {tool_name} description: {description}"
                )

                record_operation_log(
                    f"MCP tool description loaded: {tool_name}",
                    attributes={
                        "tool_name": tool_name,
                        "description_source": "ai_config",
                        "description_length": len(description),
                        "description_preview": (
                            description[:200] + "..."
                            if len(description) > 200
                            else description
                        ),
                    },
                )
                return description
    except Exception as e:
        logger.warning(f"[mcp] Failed to get AI Config for {tool_name} tool: {e}")
        record_operation_log(
            f"MCP tool description fallback: {tool_name}",
            attributes={
                "tool_name": tool_name,
                "description_source": "default",
                "error": str(e),
            },
        )

    logger.error(
        f"[mcp] CRITICAL: Using fallback default description for {tool_name} tool. "
        f"AI Config should always be available. This indicates a configuration error."
    )
    logger.debug(
        f"[mcp] {tool_name} default description length: {len(default_description)} chars"
    )
    return default_description


# Helper function to log MCP tool inputs for debugging
def _log_tool_inputs(tool_name: str, **kwargs: Any) -> None:
    """
    Log all inputs to an MCP tool for debugging purposes.

    Args:
        tool_name: Name of the tool being called
        **kwargs: All input parameters passed to the tool
    """
    # Create a sanitized dict of inputs (exclude None values for cleaner logs)
    inputs = {k: v for k, v in kwargs.items() if v is not None}

    logger.info(
        f"[mcp] {tool_name}() called with inputs: {json.dumps(inputs, default=str)}"
    )

    record_operation_log(
        f"MCP tool {tool_name} inputs",
        attributes={
            "tool_name": tool_name,
            "inputs": inputs,
        },
    )


# Add query syntax to the default descriptions for full tool definitions
LOGS_FULL_DESCRIPTION = LOGS_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
METRICS_FULL_DESCRIPTION = (
    METRICS_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
)
TRACES_FULL_DESCRIPTION = TRACES_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
ERROR_GROUPS_FULL_DESCRIPTION = (
    ERROR_GROUPS_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
)
SESSIONS_FULL_DESCRIPTION = (
    SESSIONS_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
)
TIMELINE_INDICATOR_EVENTS_FULL_DESCRIPTION = (
    TIMELINE_INDICATOR_EVENTS_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
)
FLAG_EVALUATIONS_FULL_DESCRIPTION = (
    FLAG_EVALUATIONS_DEFAULT_DESCRIPTION + QUERY_SYNTAX + LOGS_QUERY_SYNTAX
)


@mcp.tool(
    name="logs",
    description=_get_tool_description("logs", LOGS_FULL_DESCRIPTION),
)
async def logs(
    start_date: str,  # ISO format start date (e.g., "2024-01-15T10:00:00Z") - REQUIRED
    end_date: Optional[
        str
    ] = None,  # ISO format end date (e.g., "2024-01-15T11:00:00Z") - defaults to current time
    query: Optional[str] = None,
    limit: int = 20,
    direction: str = "DESC",
) -> dict[str, Any]:
    """Query logs with simplified parameters and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "logs",
        start_date=start_date,
        end_date=end_date,
        query=query,
        limit=limit,
        direction=direction,
    )

    # Track AI config usage for logs tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "logs"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-logs-tracker",
                context_data,
                get_default_tool_config("logs"),
                {"query": query or "", "limit": limit},
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(f"[mcp] Could not initialize AI config tracking for logs: {e}")

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "mcp_logs_query",
        {
            "start_date": start_date,
            "end_date": end_date,
            "direction": direction,
            "limit": limit,
            "has_query": bool(query),
            "query_length": len(query) if query else 0,
            "date_range_start": date_range_start,
            "date_range_end": date_range_end,
        },
    ) as span:
        # Log the full query parameters for debugging
        logger.info(
            f"[mcp] logs() called with start_date={start_date}, end_date={end_date}, "
            f"direction={direction}, limit={limit}, "
            f"resolved_start={date_range_start[:19] if date_range_start else 'None'}, "
            f"resolved_end={date_range_end[:19] if date_range_end else 'None'}"
        )

        if query:
            logger.info(f"[mcp] logs() query: {query}")

        record_operation_log(
            "MCP logs query parameters",
            attributes={
                "start_date": start_date,
                "end_date": end_date,
                "direction": direction,
                "limit": limit,
                "has_custom_query": bool(query),
                "query": query or "",
                "date_range_start": date_range_start,
                "date_range_end": date_range_end,
            },
        )

        dr = {
            "start_date": date_range_start,
            "end_date": date_range_end,
        }

        try:
            project_id = await get_project_id_from_headers()
            variables: dict[str, Any] = {
                "project_id": project_id,
                "params": {"query": query or "", "date_range": dr},
                "direction": direction,
                "limit": min(limit, 50),  # Cap at 50 to prevent abuse
            }
            # Remove ``None`` values so we don't send spurious nulls.
            variables = {k: v for k, v in variables.items() if v is not None}

            result = await _graphql_request(LOGS_QUERY, variables)

            if result is None:
                logger.warning("[mcp] logs() received None result from GraphQL")
                record_operation_log(
                    "MCP logs query returned no data",
                    attributes={"project_id": project_id},
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "logs" in result:
                logs_data = result.get("logs", {})
                if isinstance(logs_data, dict) and "edges" in logs_data:
                    num_entries = len(logs_data.get("edges", []))
                    logger.info(f"[mcp] logs() returned {num_entries} log entries")

                    # Clean the logs data to remove GraphQL metadata
                    cleaned_result = clean_logs_response(logs_data)

                    # Calculate token reduction for monitoring
                    original_result = {"logs": logs_data}
                    final_result = {"logs": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] logs() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first entry for debugging
                    if num_entries > 0:
                        first_entry = cleaned_result.get("edges", [{}])[0].get(
                            "node", {}
                        )
                        logger.debug(
                            f"[mcp] First log entry: {first_entry.get('level', 'unknown')} - {first_entry.get('message', 'no message')[:100]}..."
                        )

                    record_operation_log(
                        "MCP logs query completed",
                        attributes={
                            "project_id": project_id,
                            "result_size": result_size,
                            "entry_count": num_entries,
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return empty result
            return {}

        except Exception as e:
            logger.exception(f"[mcp] Error in logs() function: {e}")
            record_operation_log(
                f"Error in logs query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: metrics
# ---------------------------------------------------------------------------


@mcp.tool(
    name="metrics",
    description=_get_tool_description("metrics", METRICS_FULL_DESCRIPTION),
)
async def metrics(
    metric_type: str,  # "errors", "requests", "logs", "sessions"
    start_date: str,  # ISO format start date (e.g., "2024-01-15T10:00:00Z") - REQUIRED
    end_date: Optional[
        str
    ] = None,  # ISO format end date (e.g., "2024-01-15T11:00:00Z") - defaults to current time
    query: Optional[str] = None,
    group_by: Optional[str] = None,
) -> dict[str, Any]:
    """Query metrics with simplified parameters and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "metrics",
        metric_type=metric_type,
        start_date=start_date,
        end_date=end_date,
        query=query,
        group_by=group_by,
    )

    # Map the simplified metric_type to product_type and expressions
    product_type_map = {
        "errors": "Errors",
        "requests": "Traces",
        "logs": "Logs",
        "sessions": "Sessions",
    }
    product_type = product_type_map.get(metric_type.lower(), "Logs")

    # Set defaults for bucket_by and expressions
    bucket_by = "Timestamp"
    bucket_count = 10
    expressions = [{"aggregator": "Count", "column": ""}]
    groupby_limit = 5  # we don't want more than 5 groups, total entries is buckets * groups, so if many groups, response could be too large
    groupby_limit_aggregator = "Count"

    # Convert group_by to list if specified
    group_by_list = [group_by] if group_by else []

    # Track AI config usage for metrics tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "metrics"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-metrics-tracker",
                context_data,
                get_default_tool_config("metrics"),
                {
                    "metric_type": metric_type,
                    "product_type": product_type,
                    "query": query or "",
                    "group_by": group_by or "",
                },
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(f"[mcp] Could not initialize AI config tracking for metrics: {e}")

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "mcp_metrics_query",
        {
            "metric_type": metric_type,
            "product_type": product_type,
            "start_date": start_date,
            "end_date": end_date,
            "bucket_by": bucket_by,
            "bucket_count": bucket_count,
            "has_query": bool(query),
            "expression_count": len(expressions),
            "has_groupby": bool(group_by),
            "limit": groupby_limit,
            "limit_aggregator": groupby_limit_aggregator,
            "date_range_start": date_range_start,
            "date_range_end": date_range_end,
        },
    ) as span:
        # Log the full query parameters for debugging
        logger.info(
            f"[mcp] metrics() called with metric_type={metric_type}, product_type={product_type}, "
            f"start_date={start_date}, end_date={end_date}, group_by={group_by_list}, "
            f"resolved_start={date_range_start[:19] if date_range_start else 'None'}, "
            f"resolved_end={date_range_end[:19] if date_range_end else 'None'}"
        )

        if query:
            logger.info(f"[mcp] metrics() query: {query}")

        record_operation_log(
            "MCP metrics query parameters",
            attributes={
                "metric_type": metric_type,
                "product_type": product_type,
                "start_date": start_date,
                "end_date": end_date,
                "bucket_by": bucket_by,
                "bucket_count": bucket_count,
                "has_custom_query": bool(query),
                "query": query or "",
                "expressions": expressions,
                "group_by": group_by_list,
                "limit": groupby_limit,
                "limit_aggregator": groupby_limit_aggregator,
                "date_range_start": date_range_start,
                "date_range_end": date_range_end,
            },
        )

        try:
            project_id = await get_project_id_from_headers()

            # Build params with date range
            processed_params = {
                "query": query or "",
                "date_range": {
                    "start_date": date_range_start,
                    "end_date": date_range_end,
                },
            }

            variables: dict[str, Any] = {
                "product_type": product_type,
                "project_id": project_id,
                "params": processed_params,
                "bucket_by": bucket_by,
                "bucket_count": bucket_count,
                "group_by": group_by_list,
                "limit": groupby_limit,
                "limit_aggregator": groupby_limit_aggregator,
                "expressions": expressions,
            }
            variables = {k: v for k, v in variables.items() if v is not None}

            result = await _graphql_request(METRICS_QUERY, variables)

            if result is None:
                logger.warning("[mcp] metrics() received None result from GraphQL")
                record_operation_log(
                    "MCP metrics query returned no data",
                    attributes={"project_id": project_id},
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "metrics" in result:
                metrics_data = result.get("metrics", {})
                if isinstance(metrics_data, dict) and "buckets" in metrics_data:
                    num_buckets = len(metrics_data.get("buckets", []))
                    logger.info(f"[mcp] metrics() returned {num_buckets} buckets")

                    # Clean the metrics data to remove GraphQL metadata
                    cleaned_result = clean_metrics_response(metrics_data)

                    # Calculate token reduction for monitoring
                    original_result = {"metrics": metrics_data}
                    final_result = {"metrics": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] metrics() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first bucket for debugging
                    if num_buckets > 0:
                        first_bucket = cleaned_result.get("buckets", [{}])[0]
                        logger.debug(
                            f"[mcp] First bucket: {first_bucket.get('metric_value', 'unknown')} at {first_bucket.get('bucket_min', 'unknown time')}"
                        )

                    record_operation_log(
                        "MCP metrics query completed",
                        attributes={
                            "project_id": project_id,
                            "product_type": product_type,
                            "result_size": result_size,
                            "bucket_count": num_buckets,
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return empty result
            return {}

        except Exception as e:
            logger.exception(f"[mcp] Error in metrics() function: {e}")
            record_operation_log(
                f"Error in metrics query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: session_summary (COMMENTED OUT - NOT READY FOR USE)
# ---------------------------------------------------------------------------


# @mcp.tool(
#     name="session_summary",
#     description="""
# Generate a session summary with UX evaluation from browser session recordings.
# Calls an external AI service that analyzes screenshots from user sessions to provide summaries and UX evaluations.
#
# REQUIRED INPUTS:
# - session: Numeric or string session ID (e.g., 30165790, "5IS5I3TWZFOHPbXArePYxKjH2IM5")
#
# OPTIONAL INPUTS:
# - ts: Start timestamp in milliseconds (e.g., 0, 1500). When provided with tsEnd, generates summary from 50 screenshots taken at even intervals during the specified period.
# - tsEnd: End timestamp in milliseconds (e.g., 10000, 15000). When provided with ts, generates summary from 50 screenshots taken at even intervals during the specified period.
#
# If ts and tsEnd are omitted, the summary will be generated from screenshots taken at and around all user interactions during the session.
# Usually, you would first query without ts/tsEnd parameters to get an overview, then include those to investigate specific time periods deeper.
#
# The response includes:
# - summary: Array of strings describing what happened in the session
# - evaluation: Text evaluation of the user experience quality
# - score: Numeric UX score (0-100). This is pretty arbitrary, so don't rely on it too much, but it's a good indicator of the overall quality of the session.
#
# Example usage:
# {
#   "session": 30165790
# }
#
# Or for a specific time range:
# {
#   "session": "5IS5I3TWZFOHPbXArePYxKjH2IM5",
#   "ts": 0,
#   "tsEnd": 10000
# }
# """,
# )
# async def session_summary(
#     session: int | str,
#     ts: Optional[int] = None,
#     tsEnd: Optional[int] = None,
# ) -> dict[str, Any]:
#     """Generate a session summary with UX evaluation from browser session recordings."""
#
#     project_id = await get_project_id_from_headers()
#
#     with start_operation_span(
#         "mcp_session_summary",
#         {
#             "project": project_id,
#             "session": session,
#             "has_time_range": bool(ts is not None and tsEnd is not None),
#             "ts": ts,
#             "tsEnd": tsEnd,
#         },
#     ):
#         record_operation_log(
#             "Session summary requested",
#             attributes={
#                 "project": project_id,
#                 "session": session,
#                 "has_time_range": bool(ts is not None and tsEnd is not None),
#             },
#         )
#
#         logger.info(
#             f"[mcp] session_summary() called with project: {project_id}, session: {session}, ts: {ts}, tsEnd: {tsEnd}"
#         )
#
#         try:
#             params = {
#                 "project_id": str(project_id),
#                 "session_id": str(session),
#             }
#
#             # Add optional time range parameters if provided
#             if ts is not None:
#                 params["ts"] = str(ts)
#             if tsEnd is not None:
#                 params["ts_end"] = str(tsEnd)
#
#             result = await _graphql_request(SESSION_SUMMARY_QUERY, params)
#
#             if result is None:
#                 logger.warning(
#                     "[mcp] session_summary() received None result from GraphQL"
#                 )
#                 record_operation_log(
#                     "Session summary query returned no data",
#                     attributes={"project_id": project_id},
#                 )
#                 return {}
#
#             return result
#
#         except Exception as e:
#             logger.exception(f"[mcp] Error in session_summary() function: {e}")
#             record_operation_log(
#                 f"Error in session summary query: {e}", attributes={"error": str(e)}
#             )
#             raise


# ---------------------------------------------------------------------------
# Tool: traces
# ---------------------------------------------------------------------------


@mcp.tool(
    name="traces",
    description=_get_tool_description("traces", TRACES_FULL_DESCRIPTION),
)
async def traces(
    start_date: str,  # ISO format start date (e.g., "2024-01-15T10:00:00Z") - REQUIRED
    end_date: Optional[
        str
    ] = None,  # ISO format end date (e.g., "2024-01-15T11:00:00Z") - defaults to current time
    query: Optional[str] = None,
    limit: int = 20,
    direction: str = "DESC",
) -> dict[str, Any]:
    """Query traces with simplified parameters and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "traces",
        start_date=start_date,
        end_date=end_date,
        query=query,
        limit=limit,
        direction=direction,
    )

    # Track AI config usage for traces tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "traces"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-traces-tracker",
                context_data,
                get_default_tool_config("traces"),
                {
                    "start_date": start_date,
                    "end_date": end_date,
                    "query": query or "",
                    "limit": limit,
                },
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(f"[mcp] Could not initialize AI config tracking for traces: {e}")

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "mcp_traces_query",
        {
            "start_date": start_date,
            "end_date": end_date,
            "direction": direction,
            "limit": limit,
            "has_query": bool(query),
            "query_length": len(query) if query else 0,
            "date_range_start": date_range_start,
            "date_range_end": date_range_end,
        },
    ):
        record_operation_log(
            "Traces query requested",
            attributes={
                "start_date": start_date,
                "end_date": end_date,
                "direction": direction,
                "limit": limit,
                "query_length": len(query) if query else 0,
            },
        )
        logger.info(
            f"[mcp] traces() called with start_date={start_date}, end_date={end_date}, "
            f"direction={direction}, limit={limit}, "
            f"resolved_start={date_range_start[:19] if date_range_start else 'None'}, "
            f"resolved_end={date_range_end[:19] if date_range_end else 'None'}"
        )

        dr = {
            "start_date": date_range_start,
            "end_date": date_range_end,
        }

        try:
            project_id = await get_project_id_from_headers()
            variables: dict[str, Any] = {
                "project_id": project_id,
                "params": {"query": query or "", "date_range": dr},
                "direction": direction,
                "limit": min(limit, 50),  # Cap at 50 to prevent abuse
            }
            # Remove ``None`` values so we don't send spurious nulls.
            variables = {k: v for k, v in variables.items() if v is not None}

            result = await _graphql_request(TRACES_QUERY, variables)

            if result is None:
                logger.warning("[mcp] traces() received None result from GraphQL")
                record_operation_log(
                    "Traces query returned no data",
                    attributes={"project_id": project_id},
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "traces" in result:
                traces_data = result.get("traces", {})
                if isinstance(traces_data, dict):
                    edges = traces_data.get("edges", [])
                    logger.info(f"[mcp] traces() returning {len(edges)} trace edges")

                    # Clean the traces data to remove GraphQL metadata
                    cleaned_result = clean_traces_response(traces_data)

                    # Calculate token reduction for monitoring
                    original_result = {"traces": traces_data}
                    final_result = {"traces": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] traces() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first trace for debugging
                    if len(edges) > 0:
                        first_trace = cleaned_result.get("edges", [{}])[0].get(
                            "node", {}
                        )
                        logger.debug(
                            f"[mcp] First trace: {first_trace.get('spanName', 'unknown')} in {first_trace.get('serviceName', 'unknown service')}"
                        )

                    record_operation_log(
                        "Traces query completed successfully",
                        attributes={
                            "project_id": project_id,
                            "result_size": result_size,
                            "trace_count": len(edges),
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return a generic message
            return {}

        except Exception as e:
            logger.exception(f"[mcp] Error in traces() function: {e}")
            record_operation_log(
                f"Error in traces query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: error_groups
# ---------------------------------------------------------------------------


@mcp.tool(
    name="error_groups",
    description=_get_tool_description("error_groups", ERROR_GROUPS_FULL_DESCRIPTION),
)
async def error_groups(
    start_date: str,  # ISO format start date (e.g., "2024-01-15T10:00:00Z") - REQUIRED
    end_date: Optional[
        str
    ] = None,  # ISO format end date (e.g., "2024-01-15T11:00:00Z") - defaults to current time
    query: Optional[str] = None,
    count: int = 10,
    page: Optional[int] = None,
) -> dict[str, Any]:
    """Query error groups with simplified parameters and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "error_groups",
        start_date=start_date,
        end_date=end_date,
        query=query,
        count=count,
        page=page,
    )

    # Track AI config usage for error_groups tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "error_groups"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-error_groups-tracker",
                context_data,
                get_default_tool_config("error_groups"),
                {
                    "start_date": start_date,
                    "end_date": end_date,
                    "query": query or "",
                    "count": count,
                },
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(
            f"[mcp] Could not initialize AI config tracking for error_groups: {e}"
        )

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "error_groups_query",
        {
            "start_date": start_date,
            "end_date": end_date,
            "count": count,
            "has_query": bool(query),
            "page": page or 1,
            "date_range_start": date_range_start,
            "date_range_end": date_range_end,
        },
    ):
        record_operation_log(
            "Error groups query requested",
            attributes={
                "start_date": start_date,
                "end_date": end_date,
                "count": count,
                "query_length": len(query) if query else 0,
                "page": page or 1,
            },
        )
        logger.info(
            f"[mcp] error_groups() called with start_date={start_date}, end_date={end_date}, "
            f"count={count}, page={page}, "
            f"resolved_start={date_range_start[:19] if date_range_start else 'None'}, "
            f"resolved_end={date_range_end[:19] if date_range_end else 'None'}"
        )

        dr = {
            "start_date": date_range_start,
            "end_date": date_range_end,
        }

        try:
            project_id = await get_project_id_from_headers()
            variables: dict[str, Any] = {
                "project_id": project_id,
                "params": {"query": query or "", "date_range": dr},
                "count": min(count, 50),  # Cap at 50 to prevent abuse
                "page": page or 1,
            }
            # Remove ``None`` values so we don't send spurious nulls.
            variables = {k: v for k, v in variables.items() if v is not None}

            result = await _graphql_request(ERROR_GROUPS_QUERY, variables)

            if result is None:
                logger.warning("[mcp] error_groups() received None result from GraphQL")
                record_operation_log(
                    "Error groups query returned no data",
                    attributes={"project_id": project_id},
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "error_groups" in result:
                error_groups_data = result.get("error_groups", {})
                if isinstance(error_groups_data, dict):
                    groups = error_groups_data.get("error_groups", [])
                    logger.info(
                        f"[mcp] error_groups() returning {len(groups)} error groups"
                    )

                    # Clean the error groups data to remove GraphQL metadata
                    cleaned_result = clean_error_groups_response(error_groups_data)

                    # Calculate token reduction for monitoring
                    original_result = {"error_groups": error_groups_data}
                    final_result = {"error_groups": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] error_groups() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first error group for debugging
                    if len(groups) > 0:
                        first_error = cleaned_result.get("error_groups", [{}])[0]
                        logger.debug(
                            f"[mcp] First error: {first_error.get('type', 'unknown')} in {first_error.get('serviceName', 'unknown service')}"
                        )

                    record_operation_log(
                        "Error groups query completed successfully",
                        attributes={
                            "project_id": project_id,
                            "result_size": result_size,
                            "group_count": len(groups),
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return a generic message
            return {}

        except Exception as e:
            logger.exception(f"[mcp] Error in error_groups() function: {e}")
            record_operation_log(
                f"Error in error groups query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: sessions
# ---------------------------------------------------------------------------


@mcp.tool(
    name="sessions",
    description=_get_tool_description("sessions", SESSIONS_FULL_DESCRIPTION),
)
async def sessions(
    start_date: str,  # ISO format start date (e.g., "2024-01-15T10:00:00Z") - REQUIRED
    end_date: Optional[
        str
    ] = None,  # ISO format end date (e.g., "2024-01-15T11:00:00Z") - defaults to current time
    query: Optional[str] = None,
    count: int = 10,
    sort_field: str = "created_at",
    sort_desc: bool = True,
    page: int = 1,
) -> dict[str, Any]:
    """Query user sessions with simplified parameters and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "sessions",
        start_date=start_date,
        end_date=end_date,
        query=query,
        count=count,
        sort_field=sort_field,
        sort_desc=sort_desc,
        page=page,
    )

    # Track AI config usage for sessions tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "sessions"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-sessions-tracker",
                context_data,
                get_default_tool_config("sessions"),
                {
                    "start_date": start_date,
                    "end_date": end_date,
                    "query": query or "",
                    "count": count,
                    "sort_field": sort_field,
                    "sort_desc": sort_desc,
                },
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(f"[mcp] Could not initialize AI config tracking for sessions: {e}")

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "sessions_query",
        {
            "start_date": start_date,
            "end_date": end_date,
            "count": count,
            "has_query": bool(query),
            "sort_field": sort_field,
            "sort_desc": sort_desc,
            "page": page,
            "date_range_start": date_range_start,
            "date_range_end": date_range_end,
        },
    ):
        record_operation_log(
            "Sessions query requested",
            attributes={
                "start_date": start_date,
                "end_date": end_date,
                "count": count,
                "query_length": len(query) if query else 0,
                "sort_field": sort_field,
                "sort_desc": sort_desc,
                "page": page,
            },
        )
        logger.info(
            f"[mcp] sessions() called with start_date={start_date}, end_date={end_date}, "
            f"count={count}, sort_field={sort_field}, page={page}, "
            f"resolved_start={date_range_start[:19] if date_range_start else 'None'}, "
            f"resolved_end={date_range_end[:19] if date_range_end else 'None'}"
        )

        dr = {
            "start_date": date_range_start,
            "end_date": date_range_end,
        }

        try:
            project_id = await get_project_id_from_headers()
            variables: dict[str, Any] = {
                "project_id": project_id,
                "params": {"query": query or "", "date_range": dr},
                "count": min(count, 50),  # Cap at 50 to prevent abuse
                "sort_field": sort_field,
                "sort_desc": sort_desc,
                "page": page,
            }
            # Remove ``None`` values so we don't send spurious nulls.
            variables = {k: v for k, v in variables.items() if v is not None}

            result = await _graphql_request(SESSIONS_QUERY, variables)

            if result is None:
                logger.warning("[mcp] sessions() received None result from GraphQL")
                record_operation_log(
                    "Sessions query returned no data",
                    attributes={"project_id": project_id},
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "sessions" in result:
                sessions_data = result.get("sessions", {})
                if isinstance(sessions_data, dict):
                    sessions_list = sessions_data.get("sessions", [])
                    logger.info(
                        f"[mcp] sessions() returning {len(sessions_list)} sessions"
                    )

                    # Clean the sessions data to remove GraphQL metadata
                    cleaned_result = clean_sessions_response(sessions_data)

                    # Calculate token reduction for monitoring
                    original_result = {"sessions": sessions_data}
                    final_result = {"sessions": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] sessions() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first session for debugging
                    if len(sessions_list) > 0:
                        first_session = cleaned_result.get("sessions", [{}])[0]
                        user_props = first_session.get("user_properties", {})
                        user_id = "unknown user"
                        if isinstance(user_props, dict):
                            for key in ["email", "id", "userId", "username"]:
                                if key in user_props:
                                    user_id = user_props[key]
                                    break
                        logger.debug(
                            f"[mcp] First session: {user_id} - {first_session.get('length', 0)}ms"
                        )

                    record_operation_log(
                        "Sessions query completed successfully",
                        attributes={
                            "project_id": project_id,
                            "result_size": result_size,
                            "session_count": len(sessions_list),
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return a generic message
            return {}

        except Exception as e:
            logger.exception(f"[mcp] Error in sessions() function: {e}")
            record_operation_log(
                f"Error in sessions query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Timeline Indicator Events Tool
# ---------------------------------------------------------------------------


@mcp.tool(
    name="timeline_events",
    description=_get_tool_description(
        "timeline_events", TIMELINE_INDICATOR_EVENTS_FULL_DESCRIPTION
    ),
)
async def timeline_indicator_events(
    session_secure_id: str,
) -> dict[str, Any]:
    """Query timeline indicator events for a specific session and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "timeline_indicator_events",
        session_secure_id=session_secure_id,
    )

    # Track AI config usage for timeline_indicator_events tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "timeline_indicator_events"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-timeline-indicator-events-tracker",
                context_data,
                get_default_tool_config("timeline_events"),
                {
                    "session_secure_id": session_secure_id,
                },
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(
            f"[mcp] Could not initialize AI config tracking for timeline_indicator_events: {e}"
        )

    with start_operation_span(
        "timeline_indicator_events_query",
        {
            "session_secure_id": session_secure_id,
        },
    ):
        record_operation_log(
            "Timeline indicator events query requested",
            attributes={
                "session_secure_id": session_secure_id,
            },
        )
        logger.info(
            f"[mcp] timeline_indicator_events() called with session_secure_id: {session_secure_id}"
        )

        try:
            project_id = await get_project_id_from_headers()
            variables: dict[str, Any] = {
                "session_secure_id": session_secure_id,
            }

            result = await _graphql_request(TIMELINE_INDICATOR_EVENTS_QUERY, variables)

            if result is None:
                logger.warning(
                    "[mcp] timeline_indicator_events() received None result from GraphQL"
                )
                record_operation_log(
                    "Timeline indicator events query returned no data",
                    attributes={
                        "project_id": project_id,
                        "session_secure_id": session_secure_id,
                    },
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "timeline_indicator_events" in result:
                timeline_events_data = result.get("timeline_indicator_events", [])
                if isinstance(timeline_events_data, list):
                    logger.info(
                        f"[mcp] timeline_indicator_events() returning {len(timeline_events_data)} events"
                    )

                    # Clean the timeline events data to remove GraphQL metadata
                    cleaned_result = clean_timeline_indicator_events_response(
                        timeline_events_data
                    )

                    # Calculate token reduction for monitoring
                    original_result = {
                        "timeline_indicator_events": timeline_events_data
                    }
                    final_result = {"timeline_indicator_events": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] timeline_indicator_events() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first event for debugging
                    if len(timeline_events_data) > 0:
                        first_event = cleaned_result[0] if cleaned_result else {}
                        logger.debug(
                            f"[mcp] First timeline event: type={first_event.get('type', 'unknown')} - timestamp={first_event.get('timestamp', 'unknown')}"
                        )

                    record_operation_log(
                        "Timeline indicator events query completed successfully",
                        attributes={
                            "project_id": project_id,
                            "session_secure_id": session_secure_id,
                            "result_size": result_size,
                            "event_count": len(timeline_events_data),
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return a generic message
            return {}

        except Exception as e:
            logger.exception(
                f"[mcp] Error in timeline_indicator_events() function: {e}"
            )
            record_operation_log(
                f"Error in timeline indicator events query: {e}",
                attributes={"error": str(e)},
            )
            raise


# ---------------------------------------------------------------------------
# Tool: flag_evaluations
# ---------------------------------------------------------------------------


@mcp.tool(
    name="flag_evaluations",
    description=_get_tool_description(
        "flag_evaluations", FLAG_EVALUATIONS_FULL_DESCRIPTION
    ),
)
async def flag_evaluations(
    session_secure_id: str,
    start_date: str,  # ISO format start date (e.g., "2024-01-15T10:00:00Z") - REQUIRED
    end_date: Optional[
        str
    ] = None,  # ISO format end date (e.g., "2024-01-15T11:00:00Z") - defaults to current time
    direction: str = "DESC",
    limit: int = 50,
) -> dict[str, Any]:
    """Query flag evaluations for a specific session and return cleaned JSON."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "flag_evaluations",
        session_secure_id=session_secure_id,
        start_date=start_date,
        end_date=end_date,
        direction=direction,
        limit=limit,
    )

    # Track AI config usage for flag_evaluations tool if available
    ai_config_tracker = None
    try:
        project_id = await get_project_id_from_headers()
        if ai_client and project_id:
            headers = get_http_headers()
            context_data = {
                "project_id": project_id,
                "environment": env.get("ENVIRONMENT", "production"),
            }

            # Add user information if available
            if "x-user-id" in headers:
                context_data["user_id"] = headers["x-user-id"]

            # Add tool name to context
            context_data["tool_name"] = "flag_evaluations"

            config, ai_config_tracker = get_ai_config(
                ai_client,
                "mcp-tool-flag-evaluations-tracker",
                context_data,
                get_default_tool_config("flag_evaluations"),
                {
                    "session_secure_id": session_secure_id,
                    "start_date": start_date,
                    "end_date": end_date,
                    "direction": direction,
                    "limit": limit,
                },
            )

            if ai_config_tracker:
                # Start tracking this tool usage
                ai_config_tracker.track_request()
    except Exception as e:
        logger.debug(
            f"[mcp] Could not initialize AI config tracking for flag_evaluations: {e}"
        )

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "flag_evaluations_query",
        {
            "session_secure_id": session_secure_id,
            "start_date": start_date,
            "end_date": end_date,
            "direction": direction,
            "limit": limit,
            "date_range_start": date_range_start,
            "date_range_end": date_range_end,
        },
    ):
        record_operation_log(
            "Flag evaluations query requested",
            attributes={
                "session_secure_id": session_secure_id,
                "start_date": start_date,
                "end_date": end_date,
                "direction": direction,
                "limit": limit,
                "date_range_start": date_range_start,
                "date_range_end": date_range_end,
            },
        )
        logger.info(
            f"[mcp] flag_evaluations() called with session_secure_id={session_secure_id}, "
            f"start_date={start_date}, end_date={end_date}, "
            f"direction={direction}, limit={limit}, "
            f"resolved_start={date_range_start[:19] if date_range_start else 'None'}, "
            f"resolved_end={date_range_end[:19] if date_range_end else 'None'}"
        )

        dr = {
            "start_date": date_range_start,
            "end_date": date_range_end,
        }

        try:
            project_id = await get_project_id_from_headers()

            # Build the query to filter for flag evaluations for the specific session
            query = f"service_name=gonfalon-web AND events.name=feature_flag AND secure_session_id={session_secure_id}"

            variables: dict[str, Any] = {
                "project_id": project_id,
                "params": {"query": query, "date_range": dr},
                "direction": direction,
                "limit": min(limit, 100),  # Cap at 100 to prevent abuse
            }

            result = await _graphql_request(FLAG_EVALUATIONS_QUERY, variables)

            if result is None:
                logger.warning(
                    "[mcp] flag_evaluations() received None result from GraphQL"
                )
                record_operation_log(
                    "Flag evaluations query returned no data",
                    attributes={
                        "project_id": project_id,
                        "session_secure_id": session_secure_id,
                    },
                )
                return {}

            # Format the result into a readable text representation
            if isinstance(result, dict) and "traces" in result:
                traces_data = result.get("traces", {})
                if isinstance(traces_data, dict) and "edges" in traces_data:
                    edges = traces_data.get("edges", [])
                    logger.info(
                        f"[mcp] flag_evaluations() returning {len(edges)} flag evaluation traces"
                    )

                    # Clean the flag evaluations data to remove GraphQL metadata
                    cleaned_result = clean_flag_evaluations_response(traces_data)

                    # Calculate token reduction for monitoring
                    original_result = {"traces": traces_data}
                    final_result = {"flag_evaluations": cleaned_result}

                    reduction_stats = estimate_token_reduction(
                        original_result, final_result
                    )
                    result_size = reduction_stats["cleaned_size"]

                    logger.info(
                        f"[mcp] flag_evaluations() returning cleaned JSON, size: {result_size} chars "
                        f"({reduction_stats['reduction_percent']}% reduction, ~{reduction_stats['estimated_token_reduction']} tokens saved)"
                    )

                    # Log first flag evaluation for debugging
                    if len(edges) > 0:
                        first_trace = cleaned_result.get("edges", [{}])[0].get(
                            "node", {}
                        )
                        events = first_trace.get("events", [])
                        if events:
                            first_event = events[0]
                            logger.debug(
                                f"[mcp] First flag evaluation event: name={first_event.get('name', 'unknown')} - timestamp={first_event.get('timestamp', 'unknown')}"
                            )

                    record_operation_log(
                        "Flag evaluations query completed successfully",
                        attributes={
                            "project_id": project_id,
                            "session_secure_id": session_secure_id,
                            "result_size": result_size,
                            "trace_count": len(edges),
                            "token_reduction_percent": reduction_stats[
                                "reduction_percent"
                            ],
                            "estimated_tokens_saved": reduction_stats[
                                "estimated_token_reduction"
                            ],
                        },
                    )

                    # Track successful completion if we have a tracker
                    if ai_config_tracker:
                        try:
                            ai_config_tracker.track_success(True)
                        except Exception as e:
                            logger.debug(
                                f"[mcp] Could not track AI config success: {e}"
                            )

                    return final_result

            # If we couldn't process the result properly, return empty result
            return {}

        except Exception as e:
            logger.exception(f"[mcp] Error in flag_evaluations() function: {e}")
            record_operation_log(
                f"Error in flag evaluations query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: list_dashboards
# ---------------------------------------------------------------------------


@mcp.tool(
    name="list_dashboards",
    description=_get_tool_description(
        "list_dashboards", LIST_DASHBOARDS_DEFAULT_DESCRIPTION
    ),
)
async def list_dashboards(
    search: Optional[str] = None,
    limit: int = 10,
) -> dict[str, Any]:
    """List dashboards (visualizations) for the current project."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "list_dashboards",
        search=search,
        limit=limit,
    )

    with start_operation_span(
        "mcp_list_dashboards",
        {
            "search": search or "",
            "limit": limit,
        },
    ):
        record_operation_log(
            "List dashboards requested",
            attributes={
                "search": search or "",
                "limit": limit,
            },
        )
        logger.info(
            f"[mcp] list_dashboards() called with search={search}, limit={limit}"
        )

        try:
            project_id = await get_project_id_from_headers()

            # Extract the GetVisualizations query from the combined file
            get_visualizations_query = """
            query GetVisualizations(
                $project_id: StringID!
                $input: String!
                $count: Int!
                $offset: Int!
            ) {
                visualizations(
                    project_id: $project_id
                    input: $input
                    count: $count
                    offset: $offset
                ) {
                    count
                    results {
                        id
                        name
                        updatedAt
                        graphs {
                            id
                            title
                            type
                            productType
                        }
                    }
                }
            }
            """

            variables: dict[str, Any] = {
                "project_id": project_id,
                "input": search or "",
                "count": min(limit, 50),
                "offset": 0,
            }

            result = await _graphql_request(get_visualizations_query, variables)

            if result is None:
                logger.warning(
                    "[mcp] list_dashboards() received None result from GraphQL"
                )
                record_operation_log(
                    "List dashboards query returned no data",
                    attributes={"project_id": project_id},
                )
                return {"dashboards": [], "total_count": 0}

            if isinstance(result, dict) and "visualizations" in result:
                viz_data = result.get("visualizations", {})
                if not isinstance(viz_data, dict):
                    viz_data = {}
                total_count = viz_data.get("count", 0)
                results = viz_data.get("results", [])

                logger.info(
                    f"[mcp] list_dashboards() returned {len(results)} dashboards"
                )

                # Clean the response
                cleaned_results = clean_visualizations_list_response(viz_data)

                # Build dashboard list with URLs
                dashboards = []
                for viz in cleaned_results.get("results", []):
                    dashboard = {
                        "id": viz.get("id"),
                        "name": viz.get("name"),
                        "graph_count": viz.get(
                            "graph_count", len(viz.get("graphs", []))
                        ),
                        "updated_at": viz.get("updatedAt"),
                        "dashboard_url": f"/dashboards/{viz.get('id')}",
                        "graphs": viz.get("graphs", []),
                    }
                    dashboards.append(dashboard)

                record_operation_log(
                    "List dashboards completed",
                    attributes={
                        "project_id": project_id,
                        "dashboard_count": len(dashboards),
                        "total_count": total_count,
                    },
                )

                return {
                    "dashboards": dashboards,
                    "total_count": total_count,
                }

            return {"dashboards": [], "total_count": 0}

        except Exception as e:
            logger.exception(f"[mcp] Error in list_dashboards() function: {e}")
            record_operation_log(
                f"Error in list dashboards query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: get_dashboard
# ---------------------------------------------------------------------------


@mcp.tool(
    name="get_dashboard",
    description=_get_tool_description(
        "get_dashboard", GET_DASHBOARD_DEFAULT_DESCRIPTION
    ),
)
async def get_dashboard(
    dashboard_id: int | str,
) -> dict[str, Any]:
    """Get detailed information about a specific dashboard."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "get_dashboard",
        dashboard_id=dashboard_id,
    )

    with start_operation_span(
        "mcp_get_dashboard",
        {
            "dashboard_id": dashboard_id,
        },
    ):
        record_operation_log(
            "Get dashboard requested",
            attributes={
                "dashboard_id": dashboard_id,
            },
        )
        logger.info(f"[mcp] get_dashboard() called with dashboard_id={dashboard_id}")

        try:
            project_id = await get_project_id_from_headers()

            # Extract the GetVisualization query
            get_visualization_query = """
            query GetVisualization($id: Int!) {
                visualization(id: $id) {
                    id
                    name
                    projectId
                    timePreset
                    graphs {
                        id
                        type
                        title
                        description
                        productType
                        query
                        groupByKeys
                        bucketByKey
                        bucketCount
                        display
                        expressions {
                            aggregator
                            column
                        }
                    }
                }
            }
            """

            variables: dict[str, Any] = {
                "id": int(dashboard_id),
            }

            result = await _graphql_request(get_visualization_query, variables)

            if result is None:
                logger.warning(
                    "[mcp] get_dashboard() received None result from GraphQL"
                )
                record_operation_log(
                    "Get dashboard query returned no data",
                    attributes={"dashboard_id": dashboard_id},
                )
                return {"error": "Dashboard not found", "dashboard_id": dashboard_id}

            if isinstance(result, dict) and "visualization" in result:
                viz_data = result.get("visualization", {})
                if not isinstance(viz_data, dict):
                    viz_data = {}

                logger.info(
                    f"[mcp] get_dashboard() returned dashboard: {viz_data.get('name')}"
                )

                # Clean the response
                cleaned_result = clean_visualization_response(viz_data)

                # Build response with URL
                dashboard = {
                    "id": cleaned_result.get("id"),
                    "name": cleaned_result.get("name"),
                    "project_id": cleaned_result.get("projectId"),
                    "time_preset": cleaned_result.get("timePreset"),
                    "dashboard_url": f"/dashboards/{cleaned_result.get('id')}",
                    "graphs": cleaned_result.get("graphs", []),
                    "graph_count": len(cleaned_result.get("graphs", [])),
                }

                record_operation_log(
                    "Get dashboard completed",
                    attributes={
                        "dashboard_id": dashboard_id,
                        "dashboard_name": dashboard.get("name"),
                        "graph_count": dashboard.get("graph_count"),
                    },
                )

                return dashboard

            return {"error": "Dashboard not found", "dashboard_id": dashboard_id}

        except Exception as e:
            logger.exception(f"[mcp] Error in get_dashboard() function: {e}")
            record_operation_log(
                f"Error in get dashboard query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: create_dashboard
# ---------------------------------------------------------------------------


@mcp.tool(
    name="create_dashboard",
    description=_get_tool_description(
        "create_dashboard", CREATE_DASHBOARD_DEFAULT_DESCRIPTION
    ),
)
async def create_dashboard(
    name: str,
    time_preset: str = "last_24_hours",
) -> dict[str, Any]:
    """Create a new dashboard (visualization)."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "create_dashboard",
        name=name,
        time_preset=time_preset,
    )

    with start_operation_span(
        "mcp_create_dashboard",
        {
            "name": name,
            "time_preset": time_preset,
        },
    ):
        record_operation_log(
            "Create dashboard requested",
            attributes={
                "name": name,
                "time_preset": time_preset,
            },
        )
        logger.info(
            f"[mcp] create_dashboard() called with name={name}, time_preset={time_preset}"
        )

        try:
            project_id = await get_project_id_from_headers()

            # Upsert visualization mutation
            upsert_visualization_mutation = """
            mutation UpsertVisualization($visualization: VisualizationInput!) {
                upsertVisualization(visualization: $visualization)
            }
            """

            variables: dict[str, Any] = {
                "visualization": {
                    "projectId": project_id,
                    "name": name,
                    "timePreset": time_preset,
                }
            }

            result = await _graphql_request(upsert_visualization_mutation, variables)

            if result is None:
                logger.warning(
                    "[mcp] create_dashboard() received None result from GraphQL"
                )
                record_operation_log(
                    "Create dashboard mutation returned no data",
                    attributes={"project_id": project_id, "name": name},
                )
                return {
                    "dashboard_created": False,
                    "error": "Failed to create dashboard",
                }

            if isinstance(result, dict) and "upsertVisualization" in result:
                dashboard_id = result.get("upsertVisualization")

                logger.info(
                    f"[mcp] create_dashboard() created dashboard with ID: {dashboard_id}"
                )

                record_operation_log(
                    "Create dashboard completed",
                    attributes={
                        "project_id": project_id,
                        "dashboard_id": dashboard_id,
                        "name": name,
                    },
                )

                return {
                    "dashboard_created": True,
                    "dashboard_id": str(dashboard_id),
                    "dashboard_url": f"/dashboards/{dashboard_id}",
                    "name": name,
                    "time_preset": time_preset,
                }

            return {"dashboard_created": False, "error": "Unexpected response format"}

        except Exception as e:
            logger.exception(f"[mcp] Error in create_dashboard() function: {e}")
            record_operation_log(
                f"Error in create dashboard: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: create_graph
# ---------------------------------------------------------------------------


@mcp.tool(
    name="create_graph",
    description=_get_tool_description("create_graph", CREATE_GRAPH_DEFAULT_DESCRIPTION),
)
async def create_graph(
    dashboard_id: int | str,
    title: str,
    type: str,
    product_type: str,
    expressions: list[dict[str, str]],
    query: Optional[str] = None,
    group_by: Optional[list[str]] = None,
    bucket_by: str = "Timestamp",
    bucket_count: int = 12,
    display: Optional[str] = None,
) -> dict[str, Any]:
    """Create a new graph (chart) within an existing dashboard."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "create_graph",
        dashboard_id=dashboard_id,
        title=title,
        type=type,
        product_type=product_type,
        expressions=expressions,
        query=query,
        group_by=group_by,
        bucket_by=bucket_by,
        bucket_count=bucket_count,
        display=display,
    )

    with start_operation_span(
        "mcp_create_graph",
        {
            "dashboard_id": dashboard_id,
            "title": title,
            "type": type,
            "product_type": product_type,
        },
    ):
        record_operation_log(
            "Create graph requested",
            attributes={
                "dashboard_id": dashboard_id,
                "title": title,
                "type": type,
                "product_type": product_type,
            },
        )
        logger.info(
            f"[mcp] create_graph() called with dashboard_id={dashboard_id}, "
            f"title={title}, type={type}, product_type={product_type}"
        )

        try:
            project_id = await get_project_id_from_headers()

            # Upsert graph mutation
            upsert_graph_mutation = """
            mutation UpsertGraph($graph: GraphInput!) {
                upsertGraph(graph: $graph) {
                    id
                    title
                    type
                }
            }
            """

            # Build graph input
            graph_input: dict[str, Any] = {
                "visualizationId": str(dashboard_id),
                "title": title,
                "type": type,
                "productType": product_type,
                "query": query or "",
                "expressions": expressions,
                "bucketByKey": bucket_by,
                "bucketCount": bucket_count,
            }

            # Add optional fields
            if group_by:
                graph_input["groupByKeys"] = group_by
            if display:
                graph_input["display"] = display

            variables: dict[str, Any] = {"graph": graph_input}

            result = await _graphql_request(upsert_graph_mutation, variables)

            if result is None:
                logger.warning("[mcp] create_graph() received None result from GraphQL")
                record_operation_log(
                    "Create graph mutation returned no data",
                    attributes={"dashboard_id": dashboard_id, "title": title},
                )
                return {
                    "graph_created": False,
                    "error": "Failed to create graph",
                }

            if isinstance(result, dict) and "upsertGraph" in result:
                graph_data = result.get("upsertGraph", {})
                if not isinstance(graph_data, dict):
                    graph_data = {}
                graph_id = graph_data.get("id")

                logger.info(
                    f"[mcp] create_graph() created graph with ID: {graph_id} "
                    f"in dashboard {dashboard_id}"
                )

                record_operation_log(
                    "Create graph completed",
                    attributes={
                        "dashboard_id": dashboard_id,
                        "graph_id": graph_id,
                        "title": title,
                        "type": type,
                    },
                )

                return {
                    "graph_created": True,
                    "graph_id": str(graph_id),
                    "dashboard_id": str(dashboard_id),
                    "dashboard_url": f"/dashboards/{dashboard_id}",
                    "title": title,
                    "type": type,
                    "product_type": product_type,
                }

            return {"graph_created": False, "error": "Unexpected response format"}

        except Exception as e:
            logger.exception(f"[mcp] Error in create_graph() function: {e}")
            record_operation_log(
                f"Error in create graph: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Tool: get_keys
# ---------------------------------------------------------------------------


@mcp.tool(
    name="get_keys",
    description=_get_tool_description("get_keys", GET_KEYS_DEFAULT_DESCRIPTION),
)
async def get_keys(
    product_type: str,
    start_date: str,
    end_date: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 25,
) -> dict[str, Any]:
    """Get available keys/dimensions for a product type to help with dashboard creation."""

    # Log all inputs for debugging
    _log_tool_inputs(
        "get_keys",
        product_type=product_type,
        start_date=start_date,
        end_date=end_date,
        search=search,
        limit=limit,
    )

    # Convert start_date and end_date to actual dates
    date_range_start, date_range_end = resolve_date_range(
        start_date=start_date, end_date=end_date
    )

    with start_operation_span(
        "mcp_get_keys",
        {
            "product_type": product_type,
            "start_date": start_date,
            "end_date": end_date,
            "search": search or "",
            "limit": limit,
        },
    ):
        record_operation_log(
            "Get keys requested",
            attributes={
                "product_type": product_type,
                "start_date": start_date,
                "end_date": end_date,
                "search": search or "",
                "limit": limit,
            },
        )
        logger.info(
            f"[mcp] get_keys() called with product_type={product_type}, "
            f"start_date={start_date}, end_date={end_date}, search={search}"
        )

        try:
            project_id = await get_project_id_from_headers()

            # Map product type to the appropriate keys query
            # Note: errors_keys query does not support the count parameter
            product_type_lower = product_type.lower()
            supports_count = True
            if product_type_lower in ["logs", "log"]:
                keys_query = LOGS_KEYS_QUERY
                query_name = "logs_keys"
            elif product_type_lower in ["traces", "trace"]:
                keys_query = TRACES_KEYS_QUERY
                query_name = "traces_keys"
            elif product_type_lower in ["sessions", "session"]:
                keys_query = SESSIONS_KEYS_QUERY
                query_name = "sessions_keys"
            elif product_type_lower in ["errors", "error"]:
                keys_query = ERROR_GROUPS_KEYS_QUERY
                query_name = "errors_keys"
                supports_count = False
            elif product_type_lower in ["metrics", "metric"]:
                keys_query = METRICS_KEYS_QUERY
                query_name = "metrics_keys"
            else:
                return {
                    "error": f"Unknown product type: {product_type}",
                    "supported_types": [
                        "Logs",
                        "Traces",
                        "Sessions",
                        "Errors",
                        "Metrics",
                    ],
                }

            variables: dict[str, Any] = {
                "project_id": project_id,
                "date_range": {
                    "start_date": date_range_start,
                    "end_date": date_range_end,
                },
            }
            if supports_count:
                variables["count"] = min(limit, 100)

            if search:
                variables["query"] = search

            result = await _graphql_request(keys_query, variables)

            if result is None:
                logger.warning("[mcp] get_keys() received None result from GraphQL")
                record_operation_log(
                    "Get keys query returned no data",
                    attributes={"project_id": project_id, "product_type": product_type},
                )
                return {"keys": [], "product_type": product_type}

            # Extract keys from result
            keys_data = result.get(query_name, [])
            if isinstance(keys_data, list):
                keys = [
                    {"name": k.get("name"), "type": k.get("type")}
                    for k in keys_data
                    if isinstance(k, dict)
                ]

                logger.info(
                    f"[mcp] get_keys() returned {len(keys)} keys for {product_type}"
                )

                record_operation_log(
                    "Get keys completed",
                    attributes={
                        "project_id": project_id,
                        "product_type": product_type,
                        "key_count": len(keys),
                    },
                )

                return {
                    "keys": keys,
                    "product_type": product_type,
                    "key_count": len(keys),
                }

            return {"keys": [], "product_type": product_type}

        except Exception as e:
            logger.exception(f"[mcp] Error in get_keys() function: {e}")
            record_operation_log(
                f"Error in get keys query: {e}", attributes={"error": str(e)}
            )
            raise


# ---------------------------------------------------------------------------
# Health endpoint
# ---------------------------------------------------------------------------


@mcp.custom_route("/health", methods=["GET"])
async def health_check(request: Request):
    """Health check endpoint that returns 200 OK."""
    with start_operation_span("mcp_health_check"):
        record_operation_log("MCP health check requested")
        return JSONResponse({"status": "ok"})


# ---------------------------------------------------------------------------
# GitHub Repositories Tool
# ---------------------------------------------------------------------------


@mcp.tool(
    name="github_repositories",
    description="List all private GitHub repositories accessible to the GitHub app and user, each with git_clone_command. Has no input parameters.",
)
async def github_repositories() -> dict[str, Any]:
    """List GitHub repositories accessible to the user."""

    # Log all inputs for debugging
    _log_tool_inputs("github_repositories")

    # Validate that this operation is allowed in the current request mode
    validate_github_read_operation_allowed("github_repositories")

    try:
        # Get project ID from headers
        project_id = await get_project_id_from_headers()
        if not project_id:
            return {
                "status": "error",
                "error": "missing_project_id",
                "message": "Project ID is required but not found in request headers",
            }

        # Get GitHub installation ID for the project
        installation_id = await get_github_installation_id(project_id)

        # Initialize GitHub client with installation ID
        github_client = GitHubClient(installation_id=installation_id)

        # Get GitHub access token
        access_token = await get_github_access_token()

        # List repositories
        repositories = github_client.list_repositories(access_token=access_token)

        # Only return private repositories
        private_repositories = [repo for repo in repositories if repo["private"]]

        # Filter by allowed repositories if specified in headers
        allowed_repos = get_allowed_repositories_from_headers()
        if allowed_repos:
            # Filter to only include repositories in the allowed list
            private_repositories = [
                repo
                for repo in private_repositories
                if repo["full_name"] in allowed_repos
            ]
            logger.info(
                f"[mcp] Filtered to {len(private_repositories)} repositories "
                f"from allowed list: {allowed_repos}"
            )

        # Add git clone commands to each repository (using standard GitHub URLs)
        # Git is configured with URL rewriting and bearer token auth at runtime
        for repo in private_repositories:
            repo["repo_path"] = repo["full_name"]
            repo["git_clone_command"] = (
                f"git clone https://github.com/{repo['full_name']}.git"
            )

        return {
            "status": "success",
            "total_repositories": len(private_repositories),
            "repositories": private_repositories,
            "filtering_info": {
                "allowed_repositories": allowed_repos,
                "is_filtered": allowed_repos is not None,
            },
        }

    except ValueError as e:
        # Check if this is a specific GitHub auth error that should be preserved verbatim
        error_message = str(e)
        for mcp_error in MCP_ERRORS:
            if error_message.startswith(mcp_error):
                logger.error(f"GitHub auth error in github_repositories: {e}")
                return {
                    "status": "error",
                    "error": error_message,
                    "message": error_message,
                }

        # For other ValueErrors, use generic error handling
        logger.error(f"Validation error fetching GitHub repositories: {e}")
        return {"status": "error", "error": "validation_error", "message": str(e)}
    except Exception as e:
        logger.error(f"Error fetching GitHub repositories: {e}")
        return {
            "status": "error",
            "error": str(e),
            "message": "Failed to fetch GitHub repositories. Check GITHUB_CLIENT_ID and GITHUB_PRIVATE_KEY environment variables.",
        }


@mcp.tool(
    name="create_github_pull_request",
    description=f"""Create a pull request in a GitHub repository from a specific branch.

NOTE: All PRs created by this tool are automatically:
- Prefixed with "{VEGA_PR_TITLE_PREFIX}" in the title (for identification)
- Labeled with "{VEGA_PR_LABEL}" (to easily find agent-created PRs)

Use search_github_pull_requests with vega_only=True to check for existing agent-created PRs before creating duplicates.""",
)
async def create_github_pull_request(
    repo_owner: str,
    repo_name: str,
    title: str,
    body: str,
    head_branch: str,
    base_branch: str = "main",
    draft: bool = False,
    maintainer_can_modify: bool = True,
) -> dict[str, Any]:
    """
    Create a pull request in a GitHub repository.

    Args:
        repo_owner: Repository owner (username or organization)
        repo_name: Repository name
        title: Pull request title (will be prefixed with [Vega] automatically)
        body: Pull request description/body
        head_branch: Source branch (the branch with changes)
        base_branch: Target branch (default: "main")
        draft: Whether to create as draft PR (default: False)
        maintainer_can_modify: Allow maintainers to modify PR (default: True)
    """

    # Log all inputs for debugging
    _log_tool_inputs(
        "create_github_pull_request",
        repo_owner=repo_owner,
        repo_name=repo_name,
        title=title,
        body=body,
        head_branch=head_branch,
        base_branch=base_branch,
        draft=draft,
        maintainer_can_modify=maintainer_can_modify,
    )

    # Validate that this operation is allowed in the current request mode
    validate_pr_creation_allowed("create_github_pull_request")

    try:
        # Import the GitHubClient from code_authoring
        from code_authoring import GitHubClient

        # Check if repository is in allowed list
        allowed_repos = get_allowed_repositories_from_headers()
        full_repo_name = f"{repo_owner}/{repo_name}"
        if allowed_repos and full_repo_name not in allowed_repos:
            logger.warning(
                f"[mcp] Attempted to create PR in non-allowed repository: {full_repo_name}. "
                f"Allowed: {allowed_repos}"
            )
            return {
                "status": "error",
                "error": "repository_not_allowed",
                "message": f"Repository {full_repo_name} is not in the allowed list: {allowed_repos}",
            }

        # Get project ID from headers
        project_id = await get_project_id_from_headers()
        if not project_id:
            return {
                "status": "error",
                "error": "missing_project_id",
                "message": "Project ID is required but not found in request headers",
            }

        # Get GitHub installation ID for the project
        installation_id = await get_github_installation_id(project_id)

        access_token = await get_github_access_token()

        # Initialize GitHub client with installation ID
        github_client = GitHubClient(installation_id=installation_id)

        # Add Vega prefix to title if not already present
        pr_title = title
        if not pr_title.startswith(VEGA_PR_TITLE_PREFIX):
            pr_title = f"{VEGA_PR_TITLE_PREFIX} {pr_title}"
            logger.info(f"[mcp] Added Vega prefix to PR title: {pr_title}")

        # Create pull request
        pr_info = github_client.create_pull_request(
            access_token=access_token,
            repo_owner=repo_owner,
            repo_name=repo_name,
            title=pr_title,
            body=body,
            head_branch=head_branch,
            base_branch=base_branch,
            draft=draft,
            maintainer_can_modify=maintainer_can_modify,
        )

        # Add the vega-pr label to identify agent-created PRs
        try:
            label_result = github_client.add_labels_to_pull_request(
                access_token=access_token,
                repo_owner=repo_owner,
                repo_name=repo_name,
                pr_number=pr_info["number"],
                labels=[VEGA_PR_LABEL],
            )
            pr_info["labels"] = label_result.get("labels", [VEGA_PR_LABEL])
            logger.info(
                f"[mcp] Added '{VEGA_PR_LABEL}' label to PR #{pr_info['number']}"
            )
        except Exception as label_error:
            # Log the error but don't fail the PR creation
            logger.warning(
                f"[mcp] Failed to add '{VEGA_PR_LABEL}' label to PR #{pr_info['number']}: {label_error}"
            )
            pr_info["label_warning"] = f"Failed to add label: {str(label_error)}"

        return {
            "status": "success",
            "message": f"Pull request #{pr_info['number']} created successfully with Vega identification",
            "pull_request": pr_info,
            "vega_identification": {
                "title_prefix": VEGA_PR_TITLE_PREFIX,
                "label": VEGA_PR_LABEL,
            },
        }

    except ValueError as e:
        # Check if this is a specific GitHub auth error that should be preserved verbatim
        error_message = str(e)
        for mcp_error in MCP_ERRORS:
            if error_message.startswith(mcp_error):
                logger.error(f"GitHub auth error in create_github_pull_request: {e}")
                return {
                    "status": "error",
                    "error": error_message,
                    "message": error_message,
                }

        # For other ValueErrors, use generic error handling
        logger.error(f"Validation error creating pull request: {e}")
        return {"status": "error", "error": "validation_error", "message": str(e)}
    except Exception as e:
        logger.error(f"Error creating GitHub pull request: {e}")
        return {
            "status": "error",
            "error": "github_api_error",
            "message": f"Failed to create pull request: {str(e)}",
        }


@mcp.tool(
    name="github_code_search",
    description="Search for code within all GitHub repositories accessible to the GitHub App, including public repositories. Use GitHub's code search syntax to find specific code patterns, function names, or text. Supports qualifiers like 'language:python', 'path:src/', 'extension:go', 'repo:owner/name', etc. Returns repository names, file paths, and code snippets showing matches with surrounding context. Useful for finding which repository to clone when investigating an issue.",
)
async def github_code_search(
    query: str,  # GitHub code search query (supports full GitHub search syntax like 'language:python', 'path:src/', 'extension:go', 'repo:owner/name', etc.)
    max_results: int = 30,  # Maximum number of results to return (default: 30, max: 100)
) -> dict[str, Any]:
    """
    Search for code within GitHub repositories accessible to the GitHub App.

    This tool helps identify which repository to clone when investigating an issue
    by searching for specific code patterns, function names, error messages, or text.

    Args:
        query: GitHub code search query supporting full search syntax:
            - Basic text: "function_name"
            - Language filter: "language:python error handling"
            - Path filter: "path:src/ config"
            - Extension filter: "extension:go struct"
            - Repository filter: "repo:owner/repo-name"
            - Combine filters: "language:typescript path:components/ useState"
        max_results: Maximum number of results to return (1-100, default: 30)

    Returns:
        Dictionary with:
        - status: "success" or "error"
        - total_count: Total number of matches found
        - results_returned: Number of results included in response
        - results: Array of matches with repository info, file paths, and code snippets
    """

    # Validate that this operation is allowed in the current request mode
    validate_github_read_operation_allowed("github_code_search")

    try:
        # Get project ID from headers
        project_id = await get_project_id_from_headers()
        if not project_id:
            return {
                "status": "error",
                "error": "missing_project_id",
                "message": "Project ID is required but not found in request headers",
            }

        # Get GitHub installation ID for the project
        installation_id = await get_github_installation_id(project_id)

        access_token = await get_github_access_token()

        # Initialize GitHub client with installation ID
        github_client = GitHubClient(installation_id=installation_id)

        # Validate max_results
        if max_results < 1 or max_results > 100:
            return {
                "status": "error",
                "error": "invalid_parameter",
                "message": "max_results must be between 1 and 100",
            }

        # Get allowed repositories from headers
        allowed_repos = get_allowed_repositories_from_headers()

        # If repositories are restricted, modify the query to only search in allowed repos
        search_query = query
        if allowed_repos:
            # Add repo: filters to restrict search to allowed repositories
            repo_filters = " ".join([f"repo:{repo}" for repo in allowed_repos])
            search_query = f"{query} {repo_filters}"
            logger.info(
                f"[mcp] Modified search query with repo filters: {search_query}"
            )

        # Search code
        logger.info(
            f"Searching GitHub code with query: {search_query}, max_results: {max_results}"
        )
        search_results = github_client.search_code(
            access_token=access_token,
            query=search_query,
            max_results=max_results,
        )

        # Filter results to only include allowed repos (defense in depth)
        # This prevents bypassing restrictions via repo: qualifiers in the original query
        if allowed_repos:
            search_results["results"] = [
                result
                for result in search_results.get("results", [])
                if result.get("repository", {}).get("full_name") in allowed_repos
            ]

        logger.info(
            f"GitHub code search returned {search_results['results_returned']} results (total: {search_results['total_count']})"
        )

        return {
            "status": "success",
            "message": f"Found {search_results['total_count']} matches, returning {search_results['results_returned']} results",
            "total_count": search_results["total_count"],
            "results_returned": search_results["results_returned"],
            "results": search_results["results"],
            "filtering_info": {
                "allowed_repositories": allowed_repos,
                "is_filtered": allowed_repos is not None,
            },
        }

    except ValueError as e:
        # Check if this is a specific GitHub auth error that should be preserved verbatim
        error_message = str(e)
        for mcp_error in MCP_ERRORS:
            if error_message.startswith(mcp_error):
                logger.error(f"GitHub auth error in github_code_search: {e}")
                return {
                    "status": "error",
                    "error": error_message,
                    "message": error_message,
                }

        # For other ValueErrors, use generic error handling
        logger.error(f"Validation error searching code: {e}")
        return {"status": "error", "error": "validation_error", "message": str(e)}
    except Exception as e:
        logger.error(f"Error searching GitHub code: {e}")
        return {
            "status": "error",
            "error": "github_api_error",
            "message": f"Failed to search code: {str(e)}",
        }


@mcp.tool(
    name="search_github_pull_requests",
    description=f"""Search for pull requests in a GitHub repository. Useful for checking if a similar PR already exists before creating a new one.

IMPORTANT: PRs created by this agent have the "{VEGA_PR_TITLE_PREFIX}" prefix in their title and the "{VEGA_PR_LABEL}" label. Use the vega_only parameter to filter for agent-created PRs.

Parameters:
- repo_owner (required): Repository owner (username or organization)
- repo_name (required): Repository name  
- state (optional, default "open"): PR state filter - "open", "closed", or "all"
- vega_only (optional, default False): If True, only return PRs with the "{VEGA_PR_LABEL}" label (PRs created by this agent)
- title_contains (optional): Filter PRs whose title contains this substring (case-insensitive)
- max_results (optional, default 30): Maximum number of results (1-100)

Returns PR details including: number, title, state, html_url, head_branch, base_branch, labels, created_at, user.""",
)
async def search_github_pull_requests(
    repo_owner: str,
    repo_name: str,
    state: str = "open",
    vega_only: bool = False,
    title_contains: str | None = None,
    max_results: int = 30,
) -> dict[str, Any]:
    """
    Search for pull requests in a GitHub repository.

    Args:
        repo_owner: Repository owner (username or organization)
        repo_name: Repository name
        state: PR state filter - "open", "closed", or "all" (default: "open")
        vega_only: If True, only return PRs with the vega-pr label
        title_contains: Filter PRs whose title contains this substring
        max_results: Maximum number of results to return (1-100, default: 30)
    """

    # Log all inputs for debugging
    _log_tool_inputs(
        "search_github_pull_requests",
        repo_owner=repo_owner,
        repo_name=repo_name,
        state=state,
        vega_only=vega_only,
        title_contains=title_contains,
        max_results=max_results,
    )

    # Validate that this operation is allowed in the current request mode
    validate_github_read_operation_allowed("search_github_pull_requests")

    try:
        # Check if repository is in allowed list
        allowed_repos = get_allowed_repositories_from_headers()
        full_repo_name = f"{repo_owner}/{repo_name}"
        if allowed_repos and full_repo_name not in allowed_repos:
            logger.warning(
                f"[mcp] Attempted to search PRs in non-allowed repository: {full_repo_name}. "
                f"Allowed: {allowed_repos}"
            )
            return {
                "status": "error",
                "error": "repository_not_allowed",
                "message": f"Repository {full_repo_name} is not in the allowed list: {allowed_repos}",
            }

        # Get project ID from headers
        project_id = await get_project_id_from_headers()
        if not project_id:
            return {
                "status": "error",
                "error": "missing_project_id",
                "message": "Project ID is required but not found in request headers",
            }

        # Get GitHub installation ID for the project
        installation_id = await get_github_installation_id(project_id)

        access_token = await get_github_access_token()

        # Initialize GitHub client with installation ID
        github_client = GitHubClient(installation_id=installation_id)

        # Validate max_results
        if max_results < 1 or max_results > 100:
            return {
                "status": "error",
                "error": "invalid_parameter",
                "message": "max_results must be between 1 and 100",
            }

        # Build labels filter
        labels = [VEGA_PR_LABEL] if vega_only else None

        # Search pull requests
        logger.info(
            f"Searching GitHub PRs in {repo_owner}/{repo_name} with state={state}, "
            f"vega_only={vega_only}, title_contains={title_contains}, max_results={max_results}"
        )
        search_results = github_client.search_pull_requests(
            access_token=access_token,
            repo_owner=repo_owner,
            repo_name=repo_name,
            state=state,
            labels=labels,
            title_contains=title_contains,
            max_results=max_results,
        )

        logger.info(
            f"GitHub PR search returned {search_results['total_count']} results"
        )

        return {
            "status": "success",
            "message": f"Found {search_results['total_count']} pull requests",
            "total_count": search_results["total_count"],
            "results": search_results["results"],
            "filters_applied": {
                "state": state,
                "vega_only": vega_only,
                "title_contains": title_contains,
                "vega_label": VEGA_PR_LABEL if vega_only else None,
            },
        }

    except ValueError as e:
        # Check if this is a specific GitHub auth error that should be preserved verbatim
        error_message = str(e)
        for mcp_error in MCP_ERRORS:
            if error_message.startswith(mcp_error):
                logger.error(f"GitHub auth error in search_github_pull_requests: {e}")
                return {
                    "status": "error",
                    "error": error_message,
                    "message": error_message,
                }

        # For other ValueErrors, use generic error handling
        logger.error(f"Validation error searching pull requests: {e}")
        return {"status": "error", "error": "validation_error", "message": str(e)}
    except Exception as e:
        logger.error(f"Error searching GitHub pull requests: {e}")
        return {
            "status": "error",
            "error": "github_api_error",
            "message": f"Failed to search pull requests: {str(e)}",
        }


# ---------------------------------------------------------------------------
# LaunchDarkly API – shared authenticated request helper
# ---------------------------------------------------------------------------


async def _ld_api_request(
    url: str,
    context_label: str,
    *,
    extra_headers: dict[str, str] | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """
    Perform an authenticated GET to the LaunchDarkly (Gonfalon) API.

    Gets the ldso token via secure exchange, builds browser-mimicking headers,
    and handles 401/403/404/generic HTTP errors consistently.

    Returns:
        (response_json, None) on success; (None, error_dict) on auth or HTTP error.
    """
    try:
        ldso_token = await get_ld_api_token()
        ldso_cookie = f"ldso={ldso_token}"
    except ValueError as e:
        logger.warning(f"[mcp] Failed to get LD API token: {e}")
        return None, {
            "status": "error",
            "error": "authentication_failed",
            "message": f"Failed to authenticate with LaunchDarkly: {str(e)}",
        }

    gonfalon_url = env.get("GONFALON_URL")
    request_headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": gonfalon_url,
        "Referer": f"{gonfalon_url}/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "Cookie": ldso_cookie,
    }
    if extra_headers:
        request_headers.update(extra_headers)

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                headers=request_headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as response:
                if response.status == 401:
                    logger.error(f"[mcp] Unauthorized when fetching {context_label}")
                    return None, {
                        "status": "error",
                        "error": "unauthorized",
                        "message": f"Not authorized to access {context_label}. Please ensure you are logged in.",
                    }
                if response.status == 403:
                    logger.error(f"[mcp] Forbidden when fetching {context_label}")
                    return None, {
                        "status": "error",
                        "error": "forbidden",
                        "message": f"Access denied to {context_label}.",
                    }
                if response.status == 404:
                    logger.error(f"[mcp] Not found when fetching {context_label}")
                    return None, {
                        "status": "error",
                        "error": "not_found",
                        "message": f"Not found: {context_label}.",
                    }
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(
                        f"[mcp] Failed to fetch {context_label}: {response.status} - {error_text}"
                    )
                    return None, {
                        "status": "error",
                        "error": "api_error",
                        "message": f"Failed to fetch {context_label}: HTTP {response.status}",
                    }
                data = await response.json()
                return data, None
    except Exception as e:
        logger.error(f"[mcp] Error fetching {context_label}: {e}")
        return None, {
            "status": "error",
            "error": "unexpected_error",
            "message": f"Failed to fetch {context_label}: {str(e)}",
        }


# ---------------------------------------------------------------------------
# LaunchDarkly Environment Tool
# ---------------------------------------------------------------------------


@mcp.tool(
    name="launchdarkly_environments",
    description="""List all LaunchDarkly environments for a project, showing which environments are marked as critical.

Returns a list of environments with their key, name, and critical status. Use each environment's `key` (not `name`) when calling launchdarkly_flag_evaluations — e.g. name "Production" may have key "production".

Parameters:
- project_key: The LaunchDarkly project key (defaults to "default")

Returns:
- environments: List of {key: string, name: string, critical: boolean} for each environment
- project_key: The LaunchDarkly project key used""",
)
async def launchdarkly_environments(project_key: str = "default") -> dict[str, Any]:
    """
    List LaunchDarkly environments for a project.
    Uses the user's cookie for authentication to ensure proper access control.
    The ldso cookie is retrieved via secure exchange through the GraphQL API.
    """

    _log_tool_inputs("launchdarkly_environments", project_key=project_key)

    with start_operation_span(
        "mcp_launchdarkly_environments",
        {"tool": "launchdarkly_environments", "project_key": project_key},
    ):
        gonfalon_url = env.get("GONFALON_URL")
        api_url = (
            f"{gonfalon_url}/api/v2/projects/{project_key}/environments?sort=critical"
        )
        logger.info(f"[mcp] Fetching environments from: {api_url}")

        data, err = await _ld_api_request(api_url, "environments")
        if err is not None:
            if err.get("error") == "not_found":
                err["error"] = "project_not_found"
                err["message"] = f"Project '{project_key}' not found in LaunchDarkly."
            return err

        environments = []
        for item in data.get("items", []):
            environments.append(
                {
                    "key": item.get("key", ""),
                    "name": item.get("name", ""),
                    "critical": item.get("critical", False),
                }
            )

        logger.info(
            f"[mcp] Successfully fetched {len(environments)} environments for project {project_key}"
        )
        record_operation_log(
            "LaunchDarkly environments fetched",
            attributes={
                "project_key": project_key,
                "environment_count": len(environments),
            },
        )
        return {
            "status": "success",
            "project_key": project_key,
            "environments": environments,
            "total_count": len(environments),
        }


# ---------------------------------------------------------------------------
# LaunchDarkly Flag Evaluations Usage Tool
# ---------------------------------------------------------------------------


@mcp.tool(
    name="launchdarkly_flag_evaluations",
    description="""Get evaluation usage data for a specific feature flag in an environment.

Returns time-series arrays of the number of times a flag is evaluated, broken down by the variation that resulted from that evaluation. The granularity of the data depends on the age of the data requested:
- Within the past 2 hours: minutely data
- Within the past 2 days: hourly data
- Otherwise: daily data

Parameters:
- flag_key: The feature flag key (required)
- environment_key: The environment key (required, e.g., "production", "test")
- project_key: The LaunchDarkly project key (defaults to "default")
- from_timestamp: Start timestamp for the data series (optional, defaults to 30 days ago)
- to_timestamp: End timestamp for the data series (optional, defaults to current time)

Returns:
- metadata: Information about each series/variation
- series: Array of data points with timestamps and evaluation counts per variation""",
)
async def launchdarkly_flag_evaluations(
    flag_key: str,
    environment_key: str,
    project_key: str = "default",
    from_timestamp: str | None = None,
    to_timestamp: str | None = None,
) -> dict[str, Any]:
    """
    Get evaluation usage data for a specific feature flag.
    Uses the user's cookie for authentication to ensure proper access control.
    The ldso cookie is retrieved via secure exchange through the GraphQL API.
    """

    _log_tool_inputs(
        "launchdarkly_flag_evaluations",
        flag_key=flag_key,
        environment_key=environment_key,
        project_key=project_key,
        from_timestamp=from_timestamp,
        to_timestamp=to_timestamp,
    )

    with start_operation_span(
        "mcp_launchdarkly_flag_evaluations",
        {
            "tool": "launchdarkly_flag_evaluations",
            "flag_key": flag_key,
            "environment_key": environment_key,
            "project_key": project_key,
        },
    ):
        gonfalon_url = env.get("GONFALON_URL")
        api_url = f"{gonfalon_url}/api/v2/usage/evaluations/{project_key}/{environment_key}/{flag_key}"
        query_params = []
        if from_timestamp:
            query_params.append(f"from={from_timestamp}")
        if to_timestamp:
            query_params.append(f"to={to_timestamp}")
        if query_params:
            api_url += "?" + "&".join(query_params)
        logger.info(f"[mcp] Fetching flag evaluations from: {api_url}")

        data, err = await _ld_api_request(
            api_url,
            "flag evaluations",
            extra_headers={"LD-API-Version": "beta"},
        )
        if err is not None:
            if err.get("error") == "not_found":
                err["message"] = (
                    f"Flag '{flag_key}' or environment '{environment_key}' not found in project '{project_key}'."
                )
            return err

        metadata = data.get("metadata", [])
        series = data.get("series", [])

        logger.info(
            f"[mcp] Successfully fetched {len(series)} data points for flag {flag_key}"
        )
        record_operation_log(
            "LaunchDarkly flag evaluations fetched",
            attributes={
                "flag_key": flag_key,
                "environment_key": environment_key,
                "project_key": project_key,
                "data_points": len(series),
            },
        )
        return {
            "status": "success",
            "flag_key": flag_key,
            "environment_key": environment_key,
            "project_key": project_key,
            "metadata": metadata,
            "series": series,
            "data_points_count": len(series),
        }


# ---------------------------------------------------------------------------
# LaunchDarkly Get Feature Flag Tool
# ---------------------------------------------------------------------------


@mcp.tool(
    name="launchdarkly_get_flag",
    description="""Get details of a feature flag, including the mapping of variation indices to their values.

This is useful for understanding what each variation index means when analyzing flag evaluation data.
For example, if evaluation data shows a flag is being evaluated to index '1', this tool will tell you
what value corresponds to that index (e.g., true, false, "variant-a", etc.).

Parameters:
- flag_key: The feature flag key (required)
- project_key: The LaunchDarkly project key (defaults to "default")
- environment_key: Optional environment to filter configurations (reduces response size)

Returns:
- name: The flag's human-friendly name
- key: The flag key
- kind: The flag type (boolean or multivariate)
- variations: A mapping of variation index to variation details (value, name, description)
- temporary: Whether this is a temporary flag
- archived: Whether the flag is archived
- deprecated: Whether the flag is deprecated""",
)
async def launchdarkly_get_flag(
    flag_key: str,
    project_key: str = "default",
    environment_key: str | None = None,
) -> dict[str, Any]:
    """
    Get feature flag details including variation values.
    Uses the user's cookie for authentication to ensure proper access control.
    The ldso cookie is retrieved via secure exchange through the GraphQL API.
    """

    _log_tool_inputs(
        "launchdarkly_get_flag",
        flag_key=flag_key,
        project_key=project_key,
        environment_key=environment_key,
    )

    with start_operation_span(
        "mcp_launchdarkly_get_flag",
        {
            "tool": "launchdarkly_get_flag",
            "flag_key": flag_key,
            "project_key": project_key,
        },
    ):
        gonfalon_url = env.get("GONFALON_URL")
        api_url = f"{gonfalon_url}/api/v2/flags/{project_key}/{flag_key}"
        if environment_key:
            api_url += f"?env={environment_key}"
        logger.info(f"[mcp] Fetching flag details from: {api_url}")

        data, err = await _ld_api_request(api_url, "flag details")
        if err is not None:
            if err.get("error") == "not_found":
                err["message"] = (
                    f"Flag '{flag_key}' not found in project '{project_key}'."
                )
            return err

        raw_variations = data.get("variations", [])
        variations = {}
        for idx, var in enumerate(raw_variations):
            variations[idx] = {
                "value": var.get("value"),
                "name": var.get("name", ""),
                "description": var.get("description", ""),
            }

        logger.info(
            f"[mcp] Successfully fetched flag {flag_key} with {len(variations)} variations"
        )
        record_operation_log(
            "LaunchDarkly flag details fetched",
            attributes={
                "flag_key": flag_key,
                "project_key": project_key,
                "variation_count": len(variations),
            },
        )
        return {
            "status": "success",
            "flag_key": flag_key,
            "project_key": project_key,
            "name": data.get("name", ""),
            "kind": data.get("kind", ""),
            "description": data.get("description", ""),
            "variations": variations,
            "temporary": data.get("temporary", False),
            "archived": data.get("archived", False),
            "deprecated": data.get("deprecated", False),
            "tags": data.get("tags", []),
        }


# ---------------------------------------------------------------------------
# Entrypoint – run as Streamable-HTTP server
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logger.info("[mcp] Starting MCP server on host=0.0.0.0, port=4000, path=/mcp")
    mcp.run(transport="http", host="0.0.0.0", port=4000, path="/mcp", log_level="debug")
