from __future__ import annotations

import base64
import gzip
import json
import os
import re
from datetime import datetime
from typing import Any
from typing import AsyncGenerator

import claude_agent_sdk._internal.transport.subprocess_cli as _cli
from claude_agent_sdk import ResultMessage, query as cc_query, ClaudeAgentOptions
from claude_agent_sdk.types import (
    McpHttpServerConfig,
    UserMessage,
    AssistantMessage,
    SystemMessage,
    TextBlock,
    ToolUseBlock,
    ToolResultBlock,
    ContentBlock,
    Message,
)  # type: ignore
from opentelemetry import propagate

from claude_code_defaults import (
    REQUEST_TYPE_FIX,
    REQUEST_TYPE_INVESTIGATE,
    REQUEST_TYPE_INVESTIGATE_WITH_CODE,
    REQUEST_TYPE_FLAG_CLEANUP,
    get_default_system_prompt_parts,
)
from env import env
from launchdarkly_setup import record_operation_log, start_operation_span
from logger_setup import logger

_cli._MAX_BUFFER_SIZE = 10 * 1024 * 1024

# Pattern to strip <system-reminder>...</system-reminder> from tool result text
# so the agent still receives it (from the tool) but we don't send it to the client.
_SYSTEM_REMINDER_PATTERN = re.compile(
    r"\n*<system-reminder>.*?</system-reminder>\s*",
    re.DOTALL,
)


def _strip_system_reminder_from_tool_result_text(text: str) -> str:
    """Remove system-reminder blocks from tool result text before sending to client."""
    if not text or not isinstance(text, str):
        return text
    return _SYSTEM_REMINDER_PATTERN.sub("", text)


def _strip_system_reminder_from_tool_result_content(content: Any) -> Any:
    """Strip system-reminder from tool result content (str or list of blocks) for client display."""
    if isinstance(content, str):
        return _strip_system_reminder_from_tool_result_text(content)
    if isinstance(content, list):
        return [
            (
                {
                    **item,
                    "text": _strip_system_reminder_from_tool_result_text(item["text"]),
                }
                if isinstance(item, dict)
                and item.get("type") == "text"
                and "text" in item
                else item
            )
            for item in content
        ]
    return content


__all__ = [
    "claude_code_generator",
    "Message",
    "ContentBlock",
    "TextBlock",
    "ToolUseBlock",
    "ToolResultBlock",
    "convert_db_messages_to_claude_messages",
    "convert_claude_message_to_db_content",
]


def _to_serializable(obj):
    """Recursively convert SDK objects to JSON-serializable types."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {k: _to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_serializable(item) for item in obj]
    # Handle specific SDK content block types - add type discriminator
    if isinstance(obj, TextBlock):
        return {"type": "text", "text": obj.text}
    if isinstance(obj, ToolUseBlock):
        return {
            "type": "tool_use",
            "id": obj.id,
            "name": obj.name,
            "input": _to_serializable(obj.input),
        }
    if isinstance(obj, ToolResultBlock):
        # Wrap content in MCP content block format for UI compatibility
        # The UI expects: content: [{type: "text", text: "<json string>"}]
        # Strip system-reminder blocks so the client doesn't see them (agent still does).
        content = obj.content
        if isinstance(content, str):
            content = [
                {
                    "type": "text",
                    "text": _strip_system_reminder_from_tool_result_text(content),
                }
            ]
        elif isinstance(content, list):
            content = _to_serializable(content)
            content = _strip_system_reminder_from_tool_result_content(content)
        else:
            content = [
                {
                    "type": "text",
                    "text": _strip_system_reminder_from_tool_result_text(
                        str(content) if content else ""
                    ),
                }
            ]
        return {
            "type": "tool_result",
            "tool_use_id": obj.tool_use_id,
            "content": content,
            "is_error": obj.is_error,
        }
    # Handle other SDK dataclass objects by converting to dict
    if hasattr(obj, "__dataclass_fields__"):
        return {k: _to_serializable(getattr(obj, k)) for k in obj.__dataclass_fields__}
    # Handle objects with __dict__
    if hasattr(obj, "__dict__"):
        return {
            k: _to_serializable(v)
            for k, v in obj.__dict__.items()
            if not k.startswith("_")
        }
    # Fallback to string representation
    return str(obj)


def _message_to_json(message: Message) -> str:
    """Convert SDK Message to JSON string."""
    if isinstance(message, ResultMessage):
        return json.dumps(
            {
                "type": "result",
                "subtype": message.subtype,
                "duration_ms": message.duration_ms,
                "duration_api_ms": message.duration_api_ms,
                "is_error": message.is_error,
                "num_turns": message.num_turns,
                "session_id": message.session_id,
                "total_cost_usd": message.total_cost_usd,
                "usage": _to_serializable(message.usage),
                "result": _to_serializable(message.result),
            }
        )
    elif isinstance(message, AssistantMessage):
        content_blocks = []
        text_parts = []  # Collect text for the "result" field
        for block in message.content:
            if isinstance(block, TextBlock):
                if block.text.startswith(
                    "github_refresh_token_missing"
                ) or block.text.startswith("github_refresh_token_expired"):
                    content_blocks.append({"type": "mcp_error", "text": block.text})
                else:
                    content_blocks.append({"type": "text", "text": block.text})
                    text_parts.append(block.text)
            elif isinstance(block, ToolUseBlock):
                content_blocks.append(
                    {
                        "type": "tool_use",
                        "id": block.id,
                        "name": block.name,
                        "input": _to_serializable(block.input),
                    }
                )
            elif isinstance(block, ToolResultBlock):
                # Wrap content in MCP content block format for UI compatibility
                # The UI expects: content: [{type: "text", text: "<json string>"}]
                # Strip system-reminder blocks so the client doesn't see them (agent still does).
                content = block.content
                if isinstance(content, str):
                    content = [
                        {
                            "type": "text",
                            "text": _strip_system_reminder_from_tool_result_text(
                                content
                            ),
                        }
                    ]
                elif isinstance(content, list):
                    content = _to_serializable(content)
                    content = _strip_system_reminder_from_tool_result_content(content)
                else:
                    content = [
                        {
                            "type": "text",
                            "text": _strip_system_reminder_from_tool_result_text(
                                str(content) if content else ""
                            ),
                        }
                    ]
                content_blocks.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.tool_use_id,
                        "content": content,
                        "is_error": block.is_error,
                    }
                )
        # Include "result" field with combined text for consistent extraction by Go backend
        result_text = "\n\n".join(text_parts) if text_parts else ""
        return json.dumps(
            {"type": "assistant", "content": content_blocks, "result": result_text}
        )
    elif isinstance(message, UserMessage):
        return json.dumps(
            {"type": "user", "content": _to_serializable(message.content)}
        )
    elif isinstance(message, SystemMessage):
        return json.dumps(
            {
                "type": "system",
                "subtype": message.subtype,
                "data": _to_serializable(message.data),
            }
        )
    else:
        # Unknown message type
        return json.dumps({"type": "unknown", "content": str(message)})


def convert_db_messages_to_claude_messages(db_messages: list) -> list[Message]:
    """Convert database message records to Claude SDK Message objects.

    Args:
        db_messages: List of message dictionaries or objects from database/API

    Returns:
        List of Claude SDK Message objects
    """
    claude_messages = []

    for db_msg in db_messages:
        try:
            # Handle both dictionary and object access patterns
            if isinstance(db_msg, dict):
                role = db_msg.get("role")
                content = db_msg.get("content")
            else:
                # Object with attributes (for backwards compatibility)
                role = getattr(db_msg, "Role", None) or getattr(db_msg, "role", None)
                content = getattr(db_msg, "Content", None) or getattr(
                    db_msg, "content", None
                )

            # Parse the JSON content stored in the database
            content_data = json.loads(content) if isinstance(content, str) else content

            # Handle wrapped content structure from Go backend
            if isinstance(content_data, dict) and "content" in content_data:
                content_data = content_data["content"]

            # Convert content blocks
            content_blocks = []
            if isinstance(content_data, list):
                # Content is already a list of blocks
                for block_data in content_data:
                    if isinstance(block_data, dict):
                        if block_data.get("type") == "text":
                            # Decompress text content if needed
                            text_content = block_data.get("text", "")
                            decompressed_text = _decompress_content(text_content)
                            content_blocks.append(TextBlock(text=decompressed_text))
                        elif block_data.get("type") == "tool_use":
                            content_blocks.append(
                                ToolUseBlock(
                                    id=block_data.get("id"),
                                    name=block_data.get("name"),
                                    input=block_data.get("input", {}),
                                )
                            )
                        elif block_data.get("type") == "tool_result":
                            content_blocks.append(
                                ToolResultBlock(
                                    tool_use_id=block_data.get("tool_use_id"),
                                    content=block_data.get("content"),
                                    is_error=block_data.get("is_error", False),
                                )
                            )
            elif isinstance(content_data, str):
                # Content is a simple string, decompress if needed and wrap in TextBlock
                decompressed_content = _decompress_content(content_data)
                content_blocks.append(TextBlock(text=decompressed_content))
            elif isinstance(content_data, dict) and content_data.get("text"):
                # Content is a single text block, decompress if needed
                text_content = content_data["text"]
                decompressed_text = _decompress_content(text_content)
                content_blocks.append(TextBlock(text=decompressed_text))

            # Create the appropriate message type
            if role == "user":
                claude_messages.append(UserMessage(content=content_blocks))
            elif role == "assistant":
                claude_messages.append(
                    AssistantMessage(
                        content=content_blocks, model=env["ANTHROPIC_MODEL"]
                    )
                )
            elif role == "system":
                # System messages are handled differently in Claude SDK
                # We'll skip system messages for now as they're usually set via options
                pass

        except Exception as e:
            logger.warning(f"[claude_code] Failed to convert database message: {e}")
            # Skip invalid messages rather than failing the whole conversation
            continue

    return claude_messages


def convert_claude_message_to_db_content(message: Message) -> dict:
    """Convert a Claude SDK Message to database-storable content.

    Args:
        message: Claude SDK Message object

    Returns:
        Dictionary representing the message content for database storage
    """
    content_blocks = []

    for block in message.content:
        if isinstance(block, TextBlock):
            content_blocks.append({"type": "text", "text": block.text})
        elif isinstance(block, ToolUseBlock):
            content_blocks.append(
                {
                    "type": "tool_use",
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                }
            )
        elif isinstance(block, ToolResultBlock):
            content_blocks.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.tool_use_id,
                    "content": block.content,
                    "is_error": block.is_error,
                }
            )

    return content_blocks


# Note: Message storage removed - now handled by Go backend after responses complete


def _extract_text_from_sdk_message(content: str) -> str:
    """Extract actual conversational text from Claude Code SDK message JSON.

    The Go backend stores raw SDK messages which include system messages, result metadata,
    and other non-conversational content. This function extracts text and formats tool usage
    in a way that preserves context.

    Args:
        content: String that may be SDK message JSON

    Returns:
        Extracted text content with tool usage formatted as text, or original string if not parseable
    """
    try:
        data = json.loads(content)

        # Skip system/result messages - they're SDK metadata, not conversation
        if isinstance(data, dict):
            msg_type = data.get("type")

            # System init messages - skip entirely
            if msg_type == "system":
                logger.debug(
                    f"[claude_code] Skipping system message: {data.get('subtype')}"
                )
                return ""

            # Result messages - skip entirely
            if msg_type == "result":
                logger.debug(f"[claude_code] Skipping result message")
                return ""

            # Assistant messages - extract text and tool usage
            if msg_type == "assistant" and "content" in data:
                content_blocks = data["content"]
                if isinstance(content_blocks, list):
                    parts = []
                    for block in content_blocks:
                        if not isinstance(block, dict):
                            continue

                        block_type = block.get("type")

                        # Text content
                        if block_type == "text":
                            text = block.get("text", "")
                            if text.strip():
                                parts.append(text)

                        # Tool usage - format as descriptive text
                        elif block_type == "tool_use":
                            tool_name = block.get("name", "unknown")
                            tool_input = block.get("input", {})
                            # Create a readable summary
                            input_preview_full = json.dumps(tool_input, indent=2)
                            input_preview = input_preview_full[:200]
                            if len(input_preview_full) > 200:
                                input_preview += "..."
                            parts.append(
                                f"[Used tool: {tool_name}]\nInput: {input_preview}"
                            )

                    extracted = "\n\n".join(parts)
                    if extracted:
                        logger.debug(
                            f"[claude_code] Extracted assistant content: {len(extracted)} chars"
                        )
                        return extracted

            # User messages with tool results
            if msg_type == "user" and "content" in data:
                content_blocks = data["content"]
                if isinstance(content_blocks, list):
                    parts = []
                    for block in content_blocks:
                        if not isinstance(block, dict):
                            continue

                        block_type = block.get("type")

                        # Text content
                        if block_type == "text":
                            text = block.get("text", "")
                            if text.strip():
                                parts.append(text)

                        # Tool results
                        elif block_type == "tool_result":
                            tool_content = block.get("content", "")
                            is_error = block.get("is_error", False)

                            # Format tool result
                            result_preview = str(tool_content)[:500]
                            if len(str(tool_content)) > 500:
                                result_preview += "..."

                            if is_error:
                                parts.append(f"[Tool Error]\n{result_preview}")
                            else:
                                parts.append(f"[Tool Result]\n{result_preview}")

                    extracted = "\n\n".join(parts)
                    if extracted:
                        logger.debug(
                            f"[claude_code] Extracted user content with tool results: {len(extracted)} chars"
                        )
                        return extracted

        # If we can't extract anything meaningful, return original
        return content

    except json.JSONDecodeError:
        # Not JSON, return as-is
        return content


def _decompress_content(content: str) -> str:
    """Decompress base64-encoded gzip content if detected, then extract conversational text.

    Args:
        content: String that may be base64-encoded gzip data

    Returns:
        Decompressed and extracted string if it was compressed, otherwise original string
    """
    # Check if content looks like base64-encoded gzip (starts with H4sIA which is gzip magic header in base64)
    if content.startswith("H4sIA"):
        try:
            # Decode base64
            compressed_data = base64.b64decode(content)
            # Decompress gzip
            decompressed_data = gzip.decompress(compressed_data)
            # Decode to string
            decompressed_text = decompressed_data.decode("utf-8")
            logger.debug(
                f"[claude_code] Decompressed content: {len(content)} chars -> {len(decompressed_text)} chars"
            )

            # Now extract actual conversational text from SDK message JSON
            extracted_text = _extract_text_from_sdk_message(decompressed_text)
            return extracted_text

        except Exception as e:
            logger.warning(f"[claude_code] Failed to decompress content: {e}")
            # Return empty string to filter out unreadable compressed content
            return ""

    # Not compressed, but might still be SDK message JSON
    return _extract_text_from_sdk_message(content)


def _convert_messages_to_prompt(messages: list[Message]) -> str:
    """Convert a list of Claude SDK Messages to a single prompt string.

    This is used when the underlying API doesn't support conversation history directly.
    Preserves conversation context including tool uses and their results.
    """
    prompt_parts = []

    for message in messages:
        if isinstance(message, UserMessage):
            # Extract all content from user message
            user_text_parts = []
            for block in message.content:
                if isinstance(block, TextBlock):
                    # Skip empty text blocks (from filtered SDK messages)
                    if not block.text.strip():
                        continue
                    user_text_parts.append(block.text)
                elif isinstance(block, ToolResultBlock):
                    # Include tool results in the conversation history
                    tool_result_preview = str(block.content)[:500]
                    if len(str(block.content)) > 500:
                        tool_result_preview += "... (truncated)"
                    user_text_parts.append(f"[Tool Result: {tool_result_preview}]")

            if user_text_parts:
                user_content = "\n".join(user_text_parts)
                prompt_parts.append(f"Human: {user_content}")

        elif isinstance(message, AssistantMessage):
            # Extract all content from assistant message, preserving original order
            content_parts = []

            for block in message.content:
                if isinstance(block, TextBlock):
                    # Skip empty text blocks (from filtered SDK messages)
                    if not block.text.strip():
                        continue
                    content_parts.append(block.text)
                elif isinstance(block, ToolUseBlock):
                    # Include more detail about tool usage
                    tool_input_preview_full = json.dumps(block.input, indent=2)
                    tool_input_preview = tool_input_preview_full[:200]
                    if len(tool_input_preview_full) > 200:
                        tool_input_preview += "... (truncated)"
                    content_parts.append(
                        f"[Tool Use: {block.name}]\n" f"Input: {tool_input_preview}"
                    )
                elif isinstance(block, ToolResultBlock):
                    # Include tool results that appear in assistant messages
                    tool_result_preview = str(block.content)[:500]
                    if len(str(block.content)) > 500:
                        tool_result_preview += "... (truncated)"
                    content_parts.append(f"[Tool Result: {tool_result_preview}]")

            if content_parts:
                assistant_content = "\n".join(content_parts)
                prompt_parts.append(f"Assistant: {assistant_content}")

    # Join all parts with double newlines for readability
    full_prompt = "\n\n".join(prompt_parts)

    return full_prompt


async def claude_code_generator(
    prompt: str | None = None,
    messages: list[Message] | None = None,
    max_turns: int | None = None,
    headers: dict[str, str] | None = None,
    project_id: str | None = None,
    request_type: str = REQUEST_TYPE_INVESTIGATE,
    system_prompt_template: str | None = None,
    repositories: list[str] | None = None,
) -> AsyncGenerator[str, None]:
    """Stream native SDK Message objects as JSON strings from the Claude Code SDK.


    Args:
        prompt: Single user prompt (for new conversations)
        messages: Full conversation history (for continuing conversations)
        max_turns: Maximum number of turns to execute
        headers: HTTP headers for authentication
        project_id: Project identifier
        conversation_id: Conversation ID for message storage
        store_messages: Whether to store messages in the backend (default: True)
    """

    # Validate input parameters
    if not prompt and not messages:
        raise ValueError("Either prompt or messages must be provided")
    if prompt and messages:
        raise ValueError("Cannot provide both prompt and messages")

    # Get effective prompt length for logging
    if prompt:
        prompt_length = len(prompt)
        prompt_preview = prompt[:200] + "..." if len(prompt) > 200 else prompt
        log_type = "new conversation"
    else:
        # For messages, calculate total length of user messages
        user_messages = [msg for msg in messages if isinstance(msg, UserMessage)]
        prompt_length = sum(
            len(str(block.text))
            for msg in user_messages
            for block in msg.content
            if isinstance(block, TextBlock)
        )
        latest_user_msg = user_messages[-1] if user_messages else None
        prompt_preview = (
            str(latest_user_msg.content[0].text[:200]) + "..."
            if latest_user_msg and latest_user_msg.content
            else "conversation continuation"
        )
        log_type = f"conversation continuation ({len(messages)} messages)"

    with start_operation_span(
        "claude_code_generation",
        {
            "prompt_length": prompt_length,
            "max_turns": max_turns,
            "project_id": project_id,
            "message_count": len(messages) if messages else 1,
            "type": log_type,
        },
    ) as span:
        # Log the conversation details
        logger.info(
            f"[claude_code] Starting generator: {log_type}, prompt_len={prompt_length}, max_turns={max_turns}, project_id={project_id}"
        )
        logger.debug(f"[claude_code] Prompt preview: {prompt_preview}")

        record_operation_log(
            f"Claude Code {log_type}",
            attributes={
                "prompt_length": prompt_length,
                "prompt_preview": prompt_preview,
                "max_turns": max_turns,
                "project_id": project_id,
                "message_count": len(messages) if messages else 1,
            },
        )

    # Ensure the required runtime configuration is present for the SDK.
    os.environ.update(env)
    logger.info(f"[claude_code] Environment updated")

    # Configure git to rewrite GitHub URLs to proxy and use bearer token for authentication
    git_proxy_url = env.get("GIT_PROXY_URL")
    if git_proxy_url and headers and headers.get("authorization"):
        bearer_token = headers.get("authorization")
        git_proxy_url = git_proxy_url.rstrip("/")

        # Configure git via environment variables (not http.proxy which uses CONNECT)
        config_count = 0

        # Add URL rewrite: github.com -> proxy
        os.environ[f"GIT_CONFIG_KEY_{config_count}"] = f"url.{git_proxy_url}/.insteadOf"
        os.environ[f"GIT_CONFIG_VALUE_{config_count}"] = "https://github.com/"
        config_count += 1

        # Add bearer token header scoped to the proxy URL only.
        # Using http.<url>.extraHeader ensures the Authorization header is
        # never sent to arbitrary remotes (e.g. attacker-controlled servers).
        os.environ[f"GIT_CONFIG_KEY_{config_count}"] = (
            f"http.{git_proxy_url}/.extraHeader"
        )
        os.environ[f"GIT_CONFIG_VALUE_{config_count}"] = (
            f"Authorization: {bearer_token}"
        )
        config_count += 1

        os.environ["GIT_CONFIG_COUNT"] = str(config_count)
        logger.info(f"[claude_code] Git configured for proxy: {git_proxy_url}")

    # Add Claude CLI path if it exists, avoiding hardcoded user-specific paths
    claude_local_path = os.path.expanduser("~/.claude/local")
    if os.path.exists(claude_local_path):
        current_path = os.environ.get("PATH", "")
        if claude_local_path not in current_path:
            os.environ["PATH"] = current_path + ":" + claude_local_path
            logger.info(f"[claude_code] Added Claude CLI to PATH")
        else:
            logger.info(f"[claude_code] Claude CLI already in PATH")
    else:
        logger.info(f"[claude_code] Claude CLI path does not exist")

    # Set up MCP headers
    mcp_headers = {"x-project-id": project_id, "x-request-type": request_type}
    if headers is not None:
        mcp_headers["authorization"] = headers.get("authorization", "")
        mcp_headers["cookie"] = headers.get("cookie", "")
    # Pass allowed repositories to MCP server for tool filtering
    if repositories:
        mcp_headers["x-allowed-repositories"] = ",".join(repositories)
    propagate.inject(mcp_headers)

    mcp_servers = {
        "observability": McpHttpServerConfig(
            type="http",
            url=env["HIGHLIGHT_MCP_SERVER_URL"],
            headers=mcp_headers,
        ),
    }
    logger.info(
        f"[claude_code] MCP server configured: url={env['HIGHLIGHT_MCP_SERVER_URL']} project_id={project_id}, has_auth={bool(headers and headers.get('authorization'))}, traceparent={mcp_headers.get('traceparent')}"
    )

    record_operation_log(
        "Claude Code configuration",
        attributes={
            "model": env["ANTHROPIC_MODEL"],
            "max_turns": max_turns,
            "mcp_server_url": env["HIGHLIGHT_MCP_SERVER_URL"],
            "project_id": project_id,
            "has_authorization": bool(headers and headers.get("authorization")),
        },
    )

    # Use system prompt template from Go backend (preferred for security - keeps SDK key in Go)
    # or fall back to local defaults if not provided
    if system_prompt_template:
        final_system_prompt = system_prompt_template
        logger.info("[claude_code] Using system prompt template from Go backend")
        logger.debug(
            f"[claude_code] System prompt length: {len(final_system_prompt)} chars"
        )

        record_operation_log(
            "System prompt from Go backend",
            attributes={
                "project_id": project_id,
                "prompt_length": len(final_system_prompt),
            },
        )
    else:
        # Fall back to default system prompt construction
        # This path is used when Go backend doesn't provide a template
        logger.warning(
            "[claude_code] No system prompt template from Go backend, using fallback defaults"
        )
        system_prompt_parts = get_default_system_prompt_parts("", request_type)
        final_system_prompt = "\n".join(system_prompt_parts)

        record_operation_log(
            "Claude Code system prompt fallback",
            attributes={
                "project_id": project_id,
                "request_type": request_type,
                "description_source": "default",
            },
        )

    # Log the final system prompt for debugging
    logger.debug(
        f"[claude_code] Final system prompt length: {len(final_system_prompt)} chars"
    )
    logger.debug(
        f"[claude_code] System prompt preview: {final_system_prompt[:500]}..."
        if len(final_system_prompt) > 500
        else f"[claude_code] System prompt: {final_system_prompt}"
    )

    record_operation_log(
        "Claude Code final system prompt",
        attributes={
            "prompt_source": "go_backend" if system_prompt_template else "default",
            "prompt_length": len(final_system_prompt),
            "prompt_preview": (
                final_system_prompt[:500] + "..."
                if len(final_system_prompt) > 500
                else final_system_prompt
            ),
        },
    )

    # Define MCP tools that are always allowed (read-only observability queries)
    observability_read_tools = [
        "mcp__observability__logs",
        "mcp__observability__metrics",
        "mcp__observability__traces",
        "mcp__observability__error_groups",
        "mcp__observability__sessions",
        "mcp__observability__timeline_events",
        "mcp__observability__flag_evaluations",
        "mcp__observability__list_dashboards",
        "mcp__observability__get_dashboard",
        "mcp__observability__get_keys",
    ]

    # Observability write tools (dashboard/graph creation)
    observability_write_tools = [
        "mcp__observability__create_dashboard",
        "mcp__observability__create_graph",
    ]

    # GitHub read-only tools (code search and repository listing)
    github_read_tools = [
        "mcp__observability__github_repositories",
        "mcp__observability__github_code_search",
        "mcp__observability__search_github_pull_requests",
    ]

    # GitHub write tools (PR and issue creation)
    github_write_pr_tools = [
        "mcp__observability__create_github_pull_request",
    ]

    github_write_issue_tools = [
        "mcp__observability__create_github_issue",
    ]

    launchdarkly_flag_cleanup_tools = [
        "mcp__observability__launchdarkly_environments",
        "mcp__observability__launchdarkly_flag_evaluations",
        "mcp__observability__launchdarkly_get_flag",
    ]

    # Base allowed tools (available in all modes)
    allowed_tools = [
        "AskUserQuestion",
        "Task",
        "NotebookRead",
        "TodoRead",
        "TodoWrite",
        "Read",
        "Write",
        "LS",
        "Glob",
        "Grep",
        "Bash",
    ] + observability_read_tools

    # Mode-specific tool permissions
    if request_type == REQUEST_TYPE_INVESTIGATE:
        # Investigate mode: Read-only observability, NO code access, NO GitHub operations
        pass  # Only base tools + observability read tools

    elif request_type == REQUEST_TYPE_INVESTIGATE_WITH_CODE:
        # InvestigateWithCode mode: Can search/clone code, but NO write operations
        # Bash allowed because AI composes commands (mkdir && cd && git clone...)
        allowed_tools.extend(github_read_tools)

    elif request_type == REQUEST_TYPE_FIX:
        # Fix mode: Full read/write access, can create PRs but NOT issues
        # Bash allowed because AI composes commands (mkdir && cd && git clone...)
        allowed_tools.extend(
            [
                "NotebookEdit",
                "Edit",
                "Write",
                "MultiEdit",
            ]
            + github_read_tools
            + github_write_pr_tools
            + observability_write_tools
        )

    elif request_type == REQUEST_TYPE_FLAG_CLEANUP:
        allowed_tools.extend(
            [
                "NotebookEdit",
                "Edit",
                "Write",
                "MultiEdit",
            ]
            + github_read_tools
            + github_write_pr_tools
            + launchdarkly_flag_cleanup_tools
        )

    else:
        # Unknown request type - default to most restrictive (investigate mode)
        logger.warning(
            f"[claude_code] Unknown request_type '{request_type}', defaulting to investigate mode permissions"
        )

    options = ClaudeAgentOptions(
        model=env["ANTHROPIC_MODEL"],
        system_prompt=final_system_prompt,
        allowed_tools=allowed_tools,
        mcp_servers=mcp_servers,
        permission_mode="dontAsk",
        cwd="/workspace",
    )

    try:
        # Track metrics if we have an AI config tracker
        generation_start = datetime.now()
        message_count = 0

        # For conversation continuation, convert message history to prompt format
        if messages and not prompt:
            # Log incoming message types for debugging
            message_types = [
                f"{i+1}: {type(msg).__name__} ({len(msg.content)} blocks)"
                for i, msg in enumerate(messages)
            ]
            logger.debug(
                f"[claude_code] Incoming messages for conversion: {message_types}"
            )

            # Convert conversation history to prompt format
            conversation_prompt = _convert_messages_to_prompt(messages)
            logger.debug(
                f"[claude_code] Converted {len(messages)} messages to prompt format ({len(conversation_prompt)} chars)"
            )
            # Log a preview of the converted prompt for debugging
            prompt_preview = conversation_prompt[:500]
            if len(conversation_prompt) > 500:
                prompt_preview += "... (truncated)"
            logger.debug(f"[claude_code] Prompt preview:\n{prompt_preview}")
            query_generator = cc_query(prompt=conversation_prompt, options=options)
        else:
            # Use direct prompt for new conversations
            query_generator = cc_query(prompt=prompt, options=options)

        async for message in query_generator:
            message_count += 1

            # Log each message type for debugging
            if isinstance(message, AssistantMessage):
                logger.debug(f"[claude_code] Assistant message #{message_count}")
                # Log tool use blocks specifically
                for block in message.content:
                    if isinstance(block, ToolUseBlock):
                        logger.info(
                            f"[claude_code] Tool use: {block.name} with input: {json.dumps(block.input, indent=2) if block.input else 'None'}"
                        )
                        record_operation_log(
                            f"MCP tool call: {block.name}",
                            attributes={
                                "tool_name": block.name,
                                "tool_id": block.id,
                                "tool_input": block.input,
                                "message_number": message_count,
                            },
                        )
                    elif isinstance(block, TextBlock):
                        text_preview = (
                            block.text[:200] + "..."
                            if len(block.text) > 200
                            else block.text
                        )
                        logger.debug(f"[claude_code] Assistant text: {text_preview}")
            elif isinstance(message, UserMessage):
                logger.debug(
                    f"[claude_code] User message #{message_count}: {message.content[:200]}..."
                    if len(message.content) > 200
                    else f"[claude_code] User message #{message_count}: {message.content}"
                )
            elif isinstance(message, SystemMessage):
                logger.debug(
                    f"[claude_code] System message #{message_count}: subtype={message.subtype}"
                )
                if message.subtype == "tool_result":
                    # Log tool results for debugging
                    logger.info(
                        f"[claude_code] Tool result received: {str(message.data)[:500]}..."
                        if len(str(message.data)) > 500
                        else f"[claude_code] Tool result: {message.data}"
                    )
                    record_operation_log(
                        "MCP tool result",
                        attributes={
                            "message_number": message_count,
                            "data_preview": (
                                str(message.data)[:200] + "..."
                                if len(str(message.data)) > 200
                                else str(message.data)
                            ),
                        },
                    )

            # Note: Message storage now handled by Go backend after completion

            # Yield the native SDK message as JSON
            json_output = _message_to_json(message)
            yield json_output

            # Track result messages specifically
            if isinstance(message, ResultMessage):
                # Log the final result
                cost_value = message.total_cost_usd if message.total_cost_usd else 0
                logger.info(
                    f"[claude_code] Result message: duration={message.duration_ms}ms, "
                    f"api_duration={message.duration_api_ms}ms, turns={message.num_turns}, "
                    f"cost=${cost_value:.4f}, "
                    f"is_error={message.is_error}"
                )

                # Log usage details
                if message.usage:
                    logger.info(
                        f"[claude_code] Token usage: input={message.usage.get('input_tokens', 0)}, "
                        f"output={message.usage.get('output_tokens', 0)}, "
                        f"total={message.usage.get('input_tokens', 0) + message.usage.get('output_tokens', 0)}"
                    )

                # Log the result content for debugging
                result_preview = (
                    str(message.result)[:500] + "..."
                    if len(str(message.result)) > 500
                    else str(message.result)
                )
                logger.debug(f"[claude_code] Result content: {result_preview}")

                record_operation_log(
                    "Claude Code result",
                    attributes={
                        "duration_ms": message.duration_ms,
                        "duration_api_ms": message.duration_api_ms,
                        "num_turns": message.num_turns,
                        "total_cost_usd": message.total_cost_usd,
                        "is_error": message.is_error,
                        "session_id": message.session_id,
                        "usage": message.usage,
                        "result_preview": result_preview,
                    },
                )

                # Note: AI config metrics (duration, success/error) are tracked by the Go backend
                # which holds the LaunchDarkly AI tracker. Token usage is tracked via OpenTelemetry
                # since the actual Claude API calls happen here in Python.

        # Record final operation metrics
        generation_duration = (datetime.now() - generation_start).total_seconds()
        record_operation_log(
            "Claude Code generation completed",
            attributes={
                "total_messages": message_count,
                "duration_seconds": generation_duration,
                "project_id": project_id,
            },
        )

    except Exception as e:
        logger.exception(f"[claude_code] Exception in claude_code_generator: {e}")
        record_operation_log(
            "Claude Code generation error",
            attributes={"error": str(e), "project_id": project_id},
        )
        raise
