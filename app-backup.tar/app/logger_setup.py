"""
Centralized logging configuration for AI autofix components.

Provides a single logger that can be used across all components.
Use context strings in log messages to identify the source component.
"""

import logging
import os

# Single logger for all autofix components
logger = logging.getLogger("ai_autofix")

# Configure logging if not already done
if not logger.hasHandlers():
    # Check if debug logging is enabled
    debug_enabled = os.environ.get("AI_DEBUG_LOGGING", "true").lower() in [
        "true",
        "1",
        "yes",
    ]
    log_level = logging.DEBUG if debug_enabled else logging.INFO

    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Log the debug status on startup
    if debug_enabled:
        logger.info("[logger] Debug logging enabled (AI_DEBUG_LOGGING=true)")
    else:
        logger.info(
            "[logger] Debug logging disabled (set AI_DEBUG_LOGGING=true to enable)"
        )

# Reduce verbosity of noisy third-party libraries
logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)
logging.getLogger("mcp.server.lowlevel.server").setLevel(logging.WARNING)
logging.getLogger("mcp.server.streamable_http").setLevel(logging.WARNING)
logging.getLogger("sse_starlette.sse").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("gql.transport.aiohttp").setLevel(logging.WARNING)
logging.getLogger("gql.transport.requests").setLevel(logging.WARNING)
