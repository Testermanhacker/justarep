"""
Formatter utilities for MCP server tools.

This module provides utility functions for MCP server tools,
primarily for time range parsing.
"""

from datetime import datetime, timedelta
from typing import Tuple, Optional


def parse_time_range(time_range: str) -> Tuple[str, str]:
    """
    Convert a simple time range string to start and end dates.

    Args:
        time_range: String like "15m", "1h", "6h", "24h", "7d"

    Returns:
        Tuple of (start_date, end_date) as ISO format strings
    """
    now = datetime.now().astimezone()

    # Parse the time range
    if time_range.endswith("m"):
        try:
            minutes = int(time_range[:-1])
            start_date = (now - timedelta(minutes=minutes)).isoformat()
        except ValueError:
            start_date = (now - timedelta(hours=1)).isoformat()  # Default to 1h
    elif time_range.endswith("h"):
        try:
            hours = int(time_range[:-1])
            start_date = (now - timedelta(hours=hours)).isoformat()
        except ValueError:
            start_date = (now - timedelta(hours=1)).isoformat()  # Default to 1h
    elif time_range.endswith("d"):
        try:
            days = int(time_range[:-1])
            start_date = (now - timedelta(days=days)).isoformat()
        except ValueError:
            start_date = (now - timedelta(hours=1)).isoformat()  # Default to 1h
    else:
        # Default to 1 hour if format is invalid
        start_date = (now - timedelta(hours=1)).isoformat()

    return start_date, now.isoformat()


def resolve_date_range(
    start_date: str, end_date: Optional[str] = None
) -> Tuple[str, str]:
    """
    Resolve date range from explicit start and optional end dates.

    Args:
        start_date: Required explicit start date in ISO format
        end_date: Optional explicit end date in ISO format. If not provided, uses current time.

    Returns:
        Tuple of (start_date, end_date) as ISO format strings
    """
    now = datetime.now().astimezone()

    # If both dates provided, use them as-is
    if end_date:
        return start_date, end_date

    # If only start_date provided, use current time as end_date
    return start_date, now.isoformat()
