"""
JSON cleanup utilities for MCP server tools to remove GraphQL metadata and optimize output.

This module provides functions to clean GraphQL responses by removing extraneous
metadata fields while preserving the essential data structure for frontend compatibility.
"""

from typing import Any, Dict

# Fields to remove from GraphQL responses to reduce token usage
GRAPHQL_METADATA_FIELDS = {
    "__typename",
    "__schema",
    "__type",
    "__field",
    "__directive",
    "__enumValue",
    "__inputValue",
}

# Additional verbose fields that aren't essential for LLM consumption but should be kept for frontend
VERBOSE_FIELDS = {
    "pageInfo",  # Keep for pagination info
    "totalCount",  # Keep for result counts
    "cursor",  # Keep for pagination
}

# Fields that are often null or empty and can be omitted if empty
OPTIONAL_FIELDS = {
    "traceState",
    "parentSpanID",
    "statusMessage",
    "serviceVersion",
    "user_object",
    "fields",
    "structured_stack_trace",
    "mapped_stack_trace",
    "snoozed_until",
}


def clean_graphql_response(data: Any) -> Any:
    """
    Recursively clean GraphQL response data by removing metadata fields and empty values.

    Args:
        data: GraphQL response data (dict, list, or primitive)

    Returns:
        Cleaned data with GraphQL metadata removed
    """
    if isinstance(data, dict):
        cleaned = {}
        for key, value in data.items():
            # Skip GraphQL metadata fields
            if key in GRAPHQL_METADATA_FIELDS:
                continue

            # Skip optional fields that are null or empty
            if key in OPTIONAL_FIELDS and (value is None or value == "" or value == []):
                continue

            # Recursively clean nested data
            cleaned_value = clean_graphql_response(value)

            # Only include non-null values (but keep empty strings and 0)
            if cleaned_value is not None:
                cleaned[key] = cleaned_value

        return cleaned

    elif isinstance(data, list):
        # Clean each item in the list
        return [clean_graphql_response(item) for item in data if item is not None]

    else:
        # Return primitive values as-is
        return data


def clean_logs_response(logs_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clean logs GraphQL response by removing unnecessary fields while preserving structure.

    Args:
        logs_data: Raw logs data from GraphQL

    Returns:
        Cleaned logs data optimized for both LLM and frontend consumption
    """
    if not logs_data:
        return {}

    cleaned = clean_graphql_response(logs_data)

    # Additional logs-specific cleanup
    if "edges" in cleaned:
        for edge in cleaned["edges"]:
            if "node" in edge:
                node = edge["node"]

                # Truncate very long messages for LLM efficiency (keep full for frontend)
                if (
                    "message" in node
                    and isinstance(node["message"], str)
                    and len(node["message"]) > 1000
                ):
                    # Keep the full message but add a truncated preview for logging
                    pass  # Don't truncate, let LLM handle it

                # Clean up logAttributes if present
                if "logAttributes" in node and isinstance(node["logAttributes"], dict):
                    # Remove empty or null attributes
                    node["logAttributes"] = {
                        k: v
                        for k, v in node["logAttributes"].items()
                        if v is not None and v != "" and v != []
                    }
                    # Remove the whole logAttributes if it's empty
                    if not node["logAttributes"]:
                        del node["logAttributes"]

    return cleaned


def clean_metrics_response(metrics_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clean metrics GraphQL response by removing unnecessary fields.

    Args:
        metrics_data: Raw metrics data from GraphQL

    Returns:
        Cleaned metrics data
    """
    if not metrics_data:
        return {}

    cleaned = clean_graphql_response(metrics_data)

    # Additional metrics-specific cleanup
    if "buckets" in cleaned:
        for bucket in cleaned["buckets"]:
            # Round metric values to reasonable precision
            if "metric_value" in bucket and isinstance(bucket["metric_value"], float):
                bucket["metric_value"] = round(bucket["metric_value"], 4)

    return cleaned


def clean_error_groups_response(error_groups_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clean error groups GraphQL response by removing unnecessary fields.

    Args:
        error_groups_data: Raw error groups data from GraphQL

    Returns:
        Cleaned error groups data
    """
    if not error_groups_data:
        return {}

    cleaned = clean_graphql_response(error_groups_data)

    # Additional error groups specific cleanup
    if "error_groups" in cleaned:
        for error_group in cleaned["error_groups"]:
            # Truncate very long stack traces
            if "stack_trace" in error_group and isinstance(
                error_group["stack_trace"], str
            ):
                if len(error_group["stack_trace"]) > 2000:
                    error_group["stack_trace"] = (
                        error_group["stack_trace"][:2000] + "...[truncated]"
                    )

            # Keep only the first few frames of structured stack trace
            if "structured_stack_trace" in error_group and isinstance(
                error_group["structured_stack_trace"], list
            ):
                if len(error_group["structured_stack_trace"]) > 5:
                    error_group["structured_stack_trace"] = error_group[
                        "structured_stack_trace"
                    ][:5]

    return cleaned


def clean_sessions_response(sessions_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clean sessions GraphQL response by removing unnecessary fields.

    Args:
        sessions_data: Raw sessions data from GraphQL

    Returns:
        Cleaned sessions data
    """
    if not sessions_data:
        return {}

    cleaned = clean_graphql_response(sessions_data)

    # Additional sessions-specific cleanup
    if "sessions" in cleaned:
        for session in cleaned["sessions"]:
            # Simplify user_properties if it's too verbose
            if "user_properties" in session and isinstance(
                session["user_properties"], dict
            ):
                # Keep only essential user properties
                essential_props = {}
                for key, value in session["user_properties"].items():
                    if key.lower() in {
                        "id",
                        "email",
                        "username",
                        "name",
                        "user_id",
                        "userid",
                    }:
                        essential_props[key] = value

                if essential_props:
                    session["user_properties"] = essential_props
                else:
                    # Remove empty user_properties
                    del session["user_properties"]

    return cleaned


def clean_traces_response(traces_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clean traces GraphQL response by removing unnecessary fields.

    Args:
        traces_data: Raw traces data from GraphQL

    Returns:
        Cleaned traces data
    """
    if not traces_data:
        return {}

    cleaned = clean_graphql_response(traces_data)

    # Additional traces-specific cleanup
    if "edges" in cleaned:
        for edge in cleaned["edges"]:
            if "node" in edge:
                node = edge["node"]

                # Simplify traceAttributes if present and verbose
                if "traceAttributes" in node and isinstance(
                    node["traceAttributes"], dict
                ):
                    # Keep only non-empty attributes
                    node["traceAttributes"] = {
                        k: v
                        for k, v in node["traceAttributes"].items()
                        if v is not None and v != "" and v != []
                    }
                    # Remove if empty
                    if not node["traceAttributes"]:
                        del node["traceAttributes"]

    return cleaned


def clean_timeline_indicator_events_response(
    timeline_events_data: Any,
) -> Any:
    """
    Clean timeline indicator events response by removing GraphQL metadata.

    Args:
        timeline_events_data: Raw timeline indicator events data from GraphQL

    Returns:
        Cleaned timeline indicator events data
    """
    cleaned = clean_graphql_response(timeline_events_data)

    # Additional cleaning specific to timeline indicator events if needed
    if isinstance(cleaned, list):
        # Clean individual timeline events
        for event in cleaned:
            if isinstance(event, dict):
                # Remove any additional metadata fields if needed
                pass

    return cleaned


def clean_flag_evaluations_response(
    flag_evaluations_data: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Clean flag evaluations GraphQL response by removing unnecessary fields.

    Args:
        flag_evaluations_data: Raw flag evaluations data from GraphQL

    Returns:
        Cleaned flag evaluations data
    """
    if not flag_evaluations_data:
        return {}

    cleaned = clean_graphql_response(flag_evaluations_data)

    # Additional flag evaluations-specific cleanup
    if "edges" in cleaned:
        for edge in cleaned["edges"]:
            if "node" in edge:
                node = edge["node"]

                # Clean up events if present
                if "events" in node and isinstance(node["events"], list):
                    for event in node["events"]:
                        if isinstance(event, dict):
                            # Clean up attributes if present and verbose
                            if "attributes" in event and isinstance(
                                event["attributes"], dict
                            ):
                                # Keep only non-empty attributes
                                event["attributes"] = {
                                    k: v
                                    for k, v in event["attributes"].items()
                                    if v is not None and v != "" and v != []
                                }
                                # Remove if empty
                                if not event["attributes"]:
                                    del event["attributes"]

    return cleaned


def clean_visualization_response(visualization_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Clean visualization (dashboard) GraphQL response by removing unnecessary fields.

    Args:
        visualization_data: Raw visualization data from GraphQL

    Returns:
        Cleaned visualization data
    """
    if not visualization_data:
        return {}

    cleaned = clean_graphql_response(visualization_data)

    # Additional visualization-specific cleanup
    if "graphs" in cleaned and isinstance(cleaned["graphs"], list):
        for graph in cleaned["graphs"]:
            if isinstance(graph, dict):
                # Clean up expressions if present
                if "expressions" in graph and isinstance(graph["expressions"], list):
                    # Keep only non-empty expressions
                    graph["expressions"] = [
                        expr
                        for expr in graph["expressions"]
                        if isinstance(expr, dict) and expr.get("aggregator")
                    ]

                # Clean up groupByKeys if empty
                if "groupByKeys" in graph and (
                    graph["groupByKeys"] is None or graph["groupByKeys"] == []
                ):
                    del graph["groupByKeys"]

    return cleaned


def clean_visualizations_list_response(
    visualizations_data: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Clean visualizations list GraphQL response by removing unnecessary fields.

    Args:
        visualizations_data: Raw visualizations list data from GraphQL

    Returns:
        Cleaned visualizations list data
    """
    if not visualizations_data:
        return {}

    cleaned = clean_graphql_response(visualizations_data)

    # Additional visualizations list-specific cleanup
    if "results" in cleaned and isinstance(cleaned["results"], list):
        for viz in cleaned["results"]:
            if isinstance(viz, dict) and "graphs" in viz:
                # Simplify graphs in list view - just keep count and basic info
                graphs = viz.get("graphs", [])
                # Keep simplified graph info (filter first, then count)
                simplified_graphs = [
                    {
                        "id": g.get("id"),
                        "title": g.get("title"),
                        "type": g.get("type"),
                        "productType": g.get("productType"),
                    }
                    for g in graphs
                    if isinstance(g, dict)
                ]
                viz["graphs"] = simplified_graphs
                viz["graph_count"] = len(simplified_graphs)

    return cleaned


def estimate_token_reduction(
    original_data: Dict[str, Any], cleaned_data: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Estimate the token reduction achieved by cleaning the data.

    Args:
        original_data: Original GraphQL response
        cleaned_data: Cleaned response data

    Returns:
        Dictionary with reduction statistics
    """
    import json

    original_size = len(json.dumps(original_data))
    cleaned_size = len(json.dumps(cleaned_data))

    reduction_bytes = original_size - cleaned_size
    reduction_percent = (
        (reduction_bytes / original_size * 100) if original_size > 0 else 0
    )

    # Rough token estimation (1 token ≈ 4 characters)
    estimated_token_reduction = reduction_bytes // 4

    return {
        "original_size": original_size,
        "cleaned_size": cleaned_size,
        "reduction_bytes": reduction_bytes,
        "reduction_percent": round(reduction_percent, 2),
        "estimated_token_reduction": estimated_token_reduction,
    }
