"""
Tests for the OpenTelemetry middleware for FastMCP.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timezone
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from otel_middleware import OpenTelemetryMiddleware, MCPHeaderGetter
from fastmcp.server.middleware import MiddlewareContext


class TestMCPHeaderGetter:
    """Tests for the MCPHeaderGetter class."""

    def test_get_header_case_insensitive(self):
        """Test that header retrieval is case-insensitive."""
        getter = MCPHeaderGetter()
        carrier = {
            "Content-Type": "application/json",
            "traceparent": "00-trace-span-01",
        }

        # Test lowercase
        result = getter.get(carrier, "traceparent")
        assert result == ["00-trace-span-01"]

        # Test uppercase
        result = getter.get(carrier, "TRACEPARENT")
        assert result == ["00-trace-span-01"]

        # Test mixed case
        result = getter.get(carrier, "TraceParent")
        assert result == ["00-trace-span-01"]

    def test_get_header_not_found(self):
        """Test that missing headers return None."""
        getter = MCPHeaderGetter()
        carrier = {"Content-Type": "application/json"}

        result = getter.get(carrier, "missing-header")
        assert result is None

    def test_get_header_empty_carrier(self):
        """Test that empty carrier returns None."""
        getter = MCPHeaderGetter()
        result = getter.get({}, "any-header")
        assert result is None

    def test_keys(self):
        """Test that keys() returns all header keys."""
        getter = MCPHeaderGetter()
        carrier = {
            "Content-Type": "application/json",
            "traceparent": "00-trace-span-01",
        }

        result = getter.keys(carrier)
        assert set(result) == {"Content-Type", "traceparent"}


class TestOpenTelemetryMiddleware:
    """Tests for the OpenTelemetryMiddleware class."""

    @pytest.fixture
    def middleware(self):
        """Create a middleware instance for testing."""
        return OpenTelemetryMiddleware()

    @pytest.fixture
    def mock_context(self):
        """Create a mock MiddlewareContext for testing."""
        ctx = MagicMock(spec=MiddlewareContext)
        ctx.method = "tools/call"
        ctx.source = "client"
        ctx.type = "request"
        ctx.timestamp = datetime.now(timezone.utc)
        ctx.message = MagicMock()

        # Mock the fastmcp_context with request headers
        ctx.fastmcp_context = MagicMock()
        ctx.fastmcp_context.request_context = MagicMock()
        ctx.fastmcp_context.request_context.request = MagicMock()
        ctx.fastmcp_context.request_context.request.headers = {}

        return ctx

    def test_middleware_initialization(self, middleware):
        """Test that middleware initializes correctly."""
        assert middleware is not None
        assert middleware.tracer is not None

    def test_create_span_attributes(self, middleware, mock_context):
        """Test that span attributes are created correctly."""
        attributes = middleware._create_span_attributes(mock_context)

        assert attributes["mcp.method"] == "tools/call"
        assert attributes["mcp.source"] == "client"
        assert attributes["mcp.type"] == "request"
        assert "mcp.timestamp" in attributes

    @pytest.mark.anyio
    async def test_on_message_creates_span(self, middleware, mock_context):
        """Test that on_message executes successfully and calls next handler."""
        call_next = AsyncMock(return_value="result")

        # Execute the middleware
        result = await middleware.on_message(mock_context, call_next)

        # Verify call_next was called
        call_next.assert_called_once_with(mock_context)
        assert result == "result"

    @pytest.mark.anyio
    async def test_on_message_handles_exceptions(self, middleware, mock_context):
        """Test that on_message re-raises exceptions."""
        call_next = AsyncMock(side_effect=ValueError("Test error"))

        # Test that exceptions are properly re-raised
        with pytest.raises(ValueError, match="Test error"):
            await middleware.on_message(mock_context, call_next)

    @pytest.mark.anyio
    async def test_on_call_tool_adds_attributes(self, middleware, mock_context):
        """Test that on_call_tool adds tool-specific attributes."""
        mock_context.message.name = "test_tool"
        call_next = AsyncMock(return_value="result")

        with patch("otel_middleware.trace.get_current_span") as mock_get_span:
            mock_span = MagicMock()
            mock_span.is_recording.return_value = True
            mock_get_span.return_value = mock_span

            result = await middleware.on_call_tool(mock_context, call_next)

            # Verify tool name was added to span
            mock_span.set_attribute.assert_called_once_with(
                "mcp.tool.name", "test_tool"
            )
            assert result == "result"

    @pytest.mark.anyio
    async def test_on_read_resource_adds_attributes(self, middleware, mock_context):
        """Test that on_read_resource adds resource-specific attributes."""
        mock_context.message.uri = "file:///test/resource"
        call_next = AsyncMock(return_value="result")

        with patch("otel_middleware.trace.get_current_span") as mock_get_span:
            mock_span = MagicMock()
            mock_span.is_recording.return_value = True
            mock_get_span.return_value = mock_span

            result = await middleware.on_read_resource(mock_context, call_next)

            # Verify resource URI was added to span
            mock_span.set_attribute.assert_called_once_with(
                "mcp.resource.uri", "file:///test/resource"
            )
            assert result == "result"

    @pytest.mark.anyio
    async def test_on_get_prompt_adds_attributes(self, middleware, mock_context):
        """Test that on_get_prompt adds prompt-specific attributes."""
        mock_context.message.name = "test_prompt"
        call_next = AsyncMock(return_value="result")

        with patch("otel_middleware.trace.get_current_span") as mock_get_span:
            mock_span = MagicMock()
            mock_span.is_recording.return_value = True
            mock_get_span.return_value = mock_span

            result = await middleware.on_get_prompt(mock_context, call_next)

            # Verify prompt name was added to span
            mock_span.set_attribute.assert_called_once_with(
                "mcp.prompt.name", "test_prompt"
            )
            assert result == "result"
