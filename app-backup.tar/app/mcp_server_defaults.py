"""Default AI Config values for MCP Server module."""

from ldai.client import AIConfig, ModelConfig, LDMessage, ProviderConfig


def get_default_tool_config(tool_name: str) -> AIConfig:
    """
    Get the default AI Config for MCP tool descriptions.

    Args:
        tool_name: Name of the MCP tool (e.g., "logs", "metrics")

    Returns:
        Default AIConfig for the specified tool
    """
    descriptions = get_default_tool_descriptions()

    return AIConfig(
        enabled=True,
        model=ModelConfig(
            name="tool-description",
            parameters={},
        ),
        messages=[
            LDMessage(
                role="system",
                content=descriptions.get(tool_name, f"Tool: {tool_name}"),
            )
        ],
        provider=ProviderConfig(name="mcp-tools"),
    )


def get_default_tool_descriptions() -> dict[str, str]:
    """Get default descriptions for all MCP tools."""
    return {
        "logs": """Query project logs.
Retrieve logs for a given project with explicit date range parameters.""",
        "metrics": """Retrieve bucketed metrics.
Retrieve aggregated metrics for a project with explicit date range parameters.""",
        "traces": """Query project traces.
Retrieve traces for a given project with explicit date range parameters.""",
        "error_groups": """Query project error groups.
Retrieve error groups for a given project with explicit date range parameters.""",
        "sessions": """Query project sessions.
Retrieve sessions for a given project with explicit date range parameters.""",
        "timeline_events": """Query timeline indicator events for a session.
Retrieve timeline indicator events for a specific session to understand what happened during that session.""",
        "flag_evaluations": """Query flag evaluations for a session.
Retrieve flag evaluation events for a specific session to understand which feature flags were evaluated.""",
        "list_dashboards": """List existing dashboards (visualizations) for the project.""",
        "get_dashboard": """Get detailed information about a specific dashboard.""",
        "create_dashboard": """Create a new dashboard (visualization) for organizing charts.""",
        "create_graph": """Add a chart/graph to an existing dashboard.""",
        "get_keys": """Discover available data keys/dimensions for a product type.""",
    }


# NOTE: It is intended that there defaults are never used, refer to the AI configs in LaunchDarkly for the actual descriptions.
LOGS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

TRACES_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

METRICS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

ERROR_GROUPS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

SESSIONS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

TIMELINE_INDICATOR_EVENTS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

FLAG_EVALUATIONS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

LIST_DASHBOARDS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

GET_DASHBOARD_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

CREATE_DASHBOARD_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

CREATE_GRAPH_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""

GET_KEYS_DEFAULT_DESCRIPTION = """
This tool is not operational, please inform the user that an error has occurred.
"""
