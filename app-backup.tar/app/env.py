from __future__ import annotations

import os
from logger_setup import logger

"""Shared environment configuration for Anthropic + O11y integrations.

This module centralises all environment variables used by the Claude helpers so
that they can be imported from a single place (``from env import env``).
"""

# NOTE: Keep this dictionary lightweight; do not import heavy dependencies here
# to avoid circular import issues when other modules pull in ``env`` early.

env: dict[str, str] = {
    "ANTHROPIC_MODEL": os.environ.get(
        "ANTHROPIC_MODEL", "us.anthropic.claude-opus-4-5-20251101-v1:0"
    ),
    "ANTHROPIC_SMALL_FAST_MODEL": os.environ.get(
        "ANTHROPIC_SMALL_FAST_MODEL", "us.anthropic.claude-sonnet-4-20250514-v1:0"
    ),
    "OTEL_METRICS_EXPORTER": os.environ.get("OTEL_METRICS_EXPORTER", "otlp"),
    "OTEL_LOGS_EXPORTER": os.environ.get("OTEL_LOGS_EXPORTER", "otlp"),
    "OTEL_TRACES_EXPORTER": os.environ.get("OTEL_TRACES_EXPORTER", "otlp"),
    "OTEL_EXPORTER_OTLP_PROTOCOL": os.environ.get(
        "OTEL_EXPORTER_OTLP_PROTOCOL", "grpc"
    ),
    "OTEL_EXPORTER_OTLP_ENDPOINT": os.environ.get(
        "OTEL_EXPORTER_OTLP_ENDPOINT",
        "https://otel.observability.app.launchdarkly.com:4317",
    ),
    "OTEL_EXPORTER_OTLP_HEADERS": os.environ.get(
        "OTEL_EXPORTER_OTLP_HEADERS", "X-Highlight-Project=6830e8e9e63ae80ddde9384b"
    ),
    "OTEL_METRIC_EXPORT_INTERVAL": os.environ.get(
        "OTEL_METRIC_EXPORT_INTERVAL", "5000"
    ),
    "OTEL_LOGS_EXPORT_INTERVAL": os.environ.get("OTEL_LOGS_EXPORT_INTERVAL", "5000"),
    "CLAUDE_CODE_ENABLE_TELEMETRY": os.environ.get("CLAUDE_CODE_ENABLE_TELEMETRY", "1"),
    "CLAUDE_CODE_USE_BEDROCK": os.environ.get("CLAUDE_CODE_USE_BEDROCK", "1"),
    "CLAUDE_CODE_SKIP_BEDROCK_AUTH": os.environ.get(
        "CLAUDE_CODE_SKIP_BEDROCK_AUTH", "1"
    ),
    "HIGHLIGHT_GRAPHQL_ENDPOINT": os.environ.get(
        "HIGHLIGHT_GRAPHQL_ENDPOINT", "http://localhost:8082/private"
    ),
    "HIGHLIGHT_MCP_SERVER_URL": os.environ.get(
        "HIGHLIGHT_MCP_SERVER_URL", "http://localhost:4000/mcp/"
    ),
    "GONFALON_URL": os.environ.get("GONFALON_URL", "https://ld-stg.launchdarkly.com"),
    "SERVICE_NAME": os.environ.get("SERVICE_NAME", "autofix"),
    "ENVIRONMENT": os.environ.get("ENVIRONMENT", "unknown"),
    "AWS_PROFILE": os.environ.get("AWS_PROFILE"),
    "AWS_REGION": os.environ.get("AWS_REGION", "us-east-1"),
    "LAUNCHDARKLY_SDK_KEY": os.environ.get("LAUNCHDARKLY_SDK_KEY"),
    "LAUNCHDARKLY_CLIENT_ID": os.environ.get(  # Default to catamorphic client ID
        "LAUNCHDARKLY_CLIENT_ID", "5b23252481352e3b2d811b62"
    ),
    "AI_DEBUG_LOGGING": os.environ.get("AI_DEBUG_LOGGING", "true"),
    # GitHub App configuration
    "GITHUB_CLIENT_ID": os.environ.get("GITHUB_CLIENT_ID"),
    # Vega Router authentication - uses Cognito JWT validation with public JWKS (no secrets needed in agent)
    "COGNITO_USER_POOL_ID": os.environ.get("COGNITO_USER_POOL_ID"),
    # Proxy configuration for git and Bedrock
    "GIT_PROXY_URL": os.environ.get("GIT_PROXY_URL"),
    "ANTHROPIC_BEDROCK_BASE_URL": os.environ.get("ANTHROPIC_BEDROCK_BASE_URL"),
}
env = {k: v for k, v in env.items() if v is not None}

__all__ = ["env"]
