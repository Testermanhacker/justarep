"""
Vega Router Authentication Middleware

This middleware verifies that requests coming through the Vega Router:
1. Have a valid Cognito JWT token (validated using public JWKS)
2. Have the X-Vega-Target header matching this container's IP address

This ensures that:
- Requests were actually authenticated by the Vega Router
- Requests were routed to the intended destination

Security note: This uses asymmetric cryptography (public JWKS) for validation,
so no secrets need to be stored in the agent task environment. This is important
because LLM agents running in the task could potentially access environment variables.
"""

from __future__ import annotations

import os
import socket
from typing import Callable

from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
import jwt
from jwt import PyJWKClient

from logger_setup import logger


# Header names (must match Go backend/foundation constants)
HEADER_VEGA_TARGET = "X-Vega-Target"
HEADER_LD_TOKEN = "LD-Token"  # Foundation library uses this for Cognito JWT

# Cognito JWKS URL format
COGNITO_JWKS_URL_TEMPLATE = (
    "https://cognito-idp.{region}.amazonaws.com/{user_pool_id}/.well-known/jwks.json"
)


class CognitoJWKSClient:
    """Singleton client for fetching and caching Cognito public keys.

    Security: This class implements fail-fast behavior. If Cognito env vars are set
    (indicating production intent) but JWKS initialization fails, the process exits
    immediately. This matches the Go router's behavior (log.Fatalf on init failure).
    """

    _instance: CognitoJWKSClient | None = None
    _jwks_client: PyJWKClient | None = None
    _initialized: bool = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        region = os.getenv("AWS_REGION")
        user_pool_id = os.getenv("COGNITO_USER_POOL_ID")

        if not region or not user_pool_id:
            logger.info(
                "[vega_auth] AWS_REGION or COGNITO_USER_POOL_ID not set, auth disabled (dev mode)"
            )
            return

        jwks_url = COGNITO_JWKS_URL_TEMPLATE.format(
            region=region, user_pool_id=user_pool_id
        )
        logger.info(f"[vega_auth] Initializing JWKS client with URL: {jwks_url}")

        try:
            # PyJWKClient handles caching of the JWKS automatically
            self._jwks_client = PyJWKClient(jwks_url, cache_keys=True)
            logger.info("[vega_auth] JWKS client initialized successfully")
        except Exception as e:
            # SECURITY: Fail-fast if auth is expected but JWKS init fails
            # This matches Go router behavior (log.Fatalf on init failure)
            logger.critical(f"[vega_auth] Failed to initialize JWKS client: {e}")
            raise SystemExit(1)

    @property
    def is_configured(self) -> bool:
        """Returns True if Cognito is configured and JWKS client is ready."""
        return self._jwks_client is not None

    def validate_token(self, token: str) -> dict | None:
        """Validate a JWT token using Cognito's public keys.

        Returns the decoded token payload if valid, None otherwise.
        """
        if self._jwks_client is None:
            return None

        try:
            # Get the signing key from JWKS
            signing_key = self._jwks_client.get_signing_key_from_jwt(token)

            # Decode and validate the token
            # Cognito uses RS256 algorithm
            payload = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                # We don't validate audience since this is a machine-to-machine token
                options={"verify_aud": False},
            )

            return payload
        except jwt.ExpiredSignatureError:
            logger.warning("[vega_auth] JWT token has expired")
            return None
        except jwt.InvalidTokenError as e:
            logger.warning(f"[vega_auth] Invalid JWT token: {e}")
            return None
        except Exception as e:
            logger.error(f"[vega_auth] Error validating JWT: {e}")
            return None


def get_container_ip() -> str | None:
    """Get the container's private IP address.

    In ECS Fargate, this returns the task's private IP that was assigned
    from the VPC subnet.
    """
    try:
        # Get the hostname and resolve it to get the container's IP
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        logger.info(f"[vega_auth] Container IP detected: {ip}")
        return ip
    except Exception as e:
        logger.warning(f"[vega_auth] Failed to detect container IP: {e}")
        return None


def extract_cognito_token(request: Request) -> str | None:
    """Extract Cognito JWT token from request headers.

    The foundation library uses LD-Token header, not the standard Authorization header.
    """
    # Check LD-Token (used by foundation's privateauth transport)
    return request.headers.get(HEADER_LD_TOKEN)


class VegaAuthMiddleware(BaseHTTPMiddleware):
    """Middleware to verify requests from the Vega Router.

    This middleware:
    1. Validates the Cognito JWT using public JWKS (no secret needed)
    2. Checks that X-Vega-Target matches this container's IP

    Auth is required when Cognito is configured (production).
    When Cognito is not configured (dev), requests are allowed through.
    Health checks are always allowed without auth.
    """

    def __init__(self, app):
        super().__init__(app)
        self.container_ip = get_container_ip()
        self.jwks_client = CognitoJWKSClient()

        logger.info(
            f"[vega_auth] Middleware initialized: auth_enabled={self.jwks_client.is_configured}, container_ip={self.container_ip}"
        )

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip auth for health checks
        if request.url.path == "/health":
            return await call_next(request)

        # If Cognito isn't configured, allow all requests (dev mode)
        if not self.jwks_client.is_configured:
            return await call_next(request)

        # Production mode: require auth

        # 1. Validate X-Vega-Target header
        target = request.headers.get(HEADER_VEGA_TARGET)
        if not target:
            logger.warning("[vega_auth] Missing X-Vega-Target header")
            raise HTTPException(status_code=401, detail="Missing X-Vega-Target header")

        # Verify target matches our IP (fail closed: reject if container IP is unknown)
        if self.container_ip is None:
            logger.error(
                "[vega_auth] Container IP is unknown — cannot verify X-Vega-Target. "
                "Rejecting request to fail closed."
            )
            raise HTTPException(
                status_code=500,
                detail="Container IP unknown, cannot verify routing target",
            )

        if target != self.container_ip:
            logger.warning(
                f"[vega_auth] Target mismatch: got {target}, expected {self.container_ip}"
            )
            raise HTTPException(
                status_code=421,  # Misdirected Request
                detail="Request routed to wrong destination",
            )
        logger.debug(f"[vega_auth] Target verified: {target}")

        # 2. Validate JWT token using Cognito's public JWKS
        token = extract_cognito_token(request)
        if not token:
            logger.warning("[vega_auth] Missing LD-Token header")
            raise HTTPException(status_code=401, detail="Missing authentication token")

        payload = self.jwks_client.validate_token(token)
        if not payload:
            logger.warning("[vega_auth] JWT validation failed")
            raise HTTPException(status_code=401, detail="Invalid authentication token")

        logger.debug(f"[vega_auth] JWT validated, sub={payload.get('sub', 'unknown')}")
        return await call_next(request)


def create_vega_auth_middleware(app):
    """Factory function to create and add the Vega auth middleware to a FastAPI app."""
    logger.info("[vega_auth] Adding Vega authentication middleware")
    app.add_middleware(VegaAuthMiddleware)
