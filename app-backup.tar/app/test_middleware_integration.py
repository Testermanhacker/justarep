"""
Simple integration test to verify the OpenTelemetry middleware works with FastMCP.
Run this to ensure the middleware doesn't interfere with MCP operations.
"""

from fastmcp import FastMCP
from otel_middleware import OpenTelemetryMiddleware
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor

# Set up OpenTelemetry with console exporter for testing
provider = TracerProvider()
processor = SimpleSpanProcessor(ConsoleSpanExporter())
provider.add_span_processor(processor)
trace.set_tracer_provider(provider)

# Create MCP server
mcp = FastMCP(name="test-server")

# Add middleware
mcp.add_middleware(OpenTelemetryMiddleware())


# Add a simple tool
@mcp.tool()
async def test_tool(message: str) -> str:
    """A simple test tool."""
    return f"Echo: {message}"


# Add a simple resource
@mcp.resource("test://resource")
async def test_resource() -> str:
    """A simple test resource."""
    return "Test resource content"


if __name__ == "__main__":
    print("Starting test MCP server with OpenTelemetry middleware...")
    print("The middleware should create spans for each operation.")
    print("You should see span output in the console.")
    print("\nServer is running on http://0.0.0.0:4001/mcp")
    print(
        'Test with: curl -X POST http://localhost:4001/mcp -H \'Content-Type: application/json\' -d \'{"jsonrpc":"2.0","method":"tools/list","id":1}\''
    )

    mcp.run(transport="http", host="0.0.0.0", port=4001, path="/mcp")
