#!/usr/bin/env python3
"""Quick test to verify ModelConfig handling is fixed."""

import os

os.environ["LAUNCHDARKLY_SDK_KEY"] = os.environ.get(
    "LAUNCHDARKLY_SDK_KEY", "sdk-test-key"
)
os.environ["AI_DEBUG_LOGGING"] = "false"  # Keep it quiet for this test

from ldai.client import AIConfig, ModelConfig, LDMessage, ProviderConfig
from claude_code_defaults import get_default_system_prompt_config
from mcp_server_defaults import get_default_tool_config


def test_model_config_access():
    """Test that we can safely access ModelConfig attributes."""

    # Test default configs
    claude_config = get_default_system_prompt_config()
    assert claude_config.model is not None
    assert claude_config.model.name == "claude-opus-4-1"

    # Test that to_dict works
    model_dict = claude_config.model.to_dict()
    assert "parameters" in model_dict
    assert model_dict["parameters"]["temperature"] == 0.7

    # Test MCP tool config
    logs_config = get_default_tool_config("logs")
    assert logs_config.model is not None
    assert logs_config.model.name == "tool-description"

    print("✓ ModelConfig access tests passed")

    # Test the actual logging code doesn't crash
    config = claude_config
    if config.model:
        model_dict = config.model.to_dict() if hasattr(config.model, "to_dict") else {}
        model_params = model_dict.get("parameters")
        print(f"✓ Can safely get parameters: {model_params}")

        # Test for record_operation_log attributes
        model_params_attr = (
            config.model.to_dict().get("parameters")
            if config.model and hasattr(config.model, "to_dict")
            else None
        )
        print(f"✓ Can safely get parameters for logging: {model_params_attr}")

    print("\nAll tests passed! The ModelConfig error is fixed.")


if __name__ == "__main__":
    test_model_config_access()
