"""Default AI Config values for Claude Code module."""

REQUEST_TYPE_INVESTIGATE = "Investigate"
REQUEST_TYPE_INVESTIGATE_WITH_CODE = "InvestigateWithCode"
REQUEST_TYPE_FIX = "Fix"
REQUEST_TYPE_FLAG_CLEANUP = "FlagCleanup"

from ldai.client import AIConfig, ModelConfig, LDMessage, ProviderConfig


def get_default_system_prompt_config() -> AIConfig:
    """
    Get the default AI Config for Claude Code system prompt.

    NOTE: It is intended that these defaults are never used, refer to the AI configs in LaunchDarkly for the actual values.
    """
    return AIConfig(
        enabled=True,
        model=ModelConfig(
            name="claude-opus-4-1",
            parameters={"temperature": 0.7},
        ),
        messages=[
            LDMessage(
                role="system",
                content="This tool is not operational, please inform the user that an error has occurred.",
            )
        ],
        provider=ProviderConfig(name="claude-code"),
    )


def get_default_system_prompt_parts(
    observability_context: str = "", request_type: str = REQUEST_TYPE_INVESTIGATE
) -> list[str]:
    """
    Get the default system prompt parts for Claude Code.

    NOTE: It is intended that these defaults are never used, refer to the AI configs in LaunchDarkly for the actual values.

    Args:
        observability_context: Optional observability context (logs, traces, etc.) to include in the prompt
        request_type: Type of request (Investigate, Fix, FlagCleanup, etc.)

    Returns:
        List of prompt parts to be joined with newlines
    """
    return [
        "This tool is not operational, please inform the user that an error has occurred."
    ]
