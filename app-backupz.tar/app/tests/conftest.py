"""
Pytest configuration for autofix tests.
"""

import pytest


# Configure anyio to only use asyncio backend (not trio)
@pytest.fixture
def anyio_backend():
    return "asyncio"
