import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock, AsyncMock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app


@pytest.fixture
def client():
    return TestClient(app)


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@patch("app.claude_code_generator")
def test_claude_code_endpoint_missing_body(mock_generator, client):
    """Test that missing request body returns 422 validation error."""
    response = client.post("/claude/code")
    assert response.status_code == 422


@patch("app.claude_code_generator")
def test_claude_code_endpoint_empty_prompt(mock_generator, client):
    """Test that empty prompt is accepted but project_id is required."""
    response = client.post("/claude/code", json={"prompt": ""})
    assert response.status_code == 422  # Missing required project_id


@patch("app.claude_code_generator")
def test_claude_code_endpoint_create_conversation(mock_generator, client):
    """Test creating a new conversation with claude/code endpoint."""

    # Setup mock generator to return async generator
    async def mock_async_generator():
        yield "Test response"

    mock_generator.return_value = mock_async_generator()

    response = client.post(
        "/claude/code",
        json={
            "prompt": "Fix this error",
            "project_id": "test-project",
            "max_turns": 5,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert "conversation_id" in data
    assert data["conversation_id"]  # Should be a non-empty string
