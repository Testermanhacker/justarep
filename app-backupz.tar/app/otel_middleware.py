"""
OpenTelemetry middleware for FastMCP servers.

This middleware provides distributed tracing for MCP (Model Context Protocol) operations
by integrating with OpenTelemetry. It extracts trace context from incoming HTTP headers,
creates spans for each MCP operation, and ensures proper context propagation throughout
the request lifecycle.

Usage:
    from fastmcp import FastMCP
    from otel_middleware import OpenTelemetryMiddleware

    mcp = FastMCP(name="my-server")
    mcp.add_middleware(OpenTelemetryMiddleware)
"""

from typing import Any, Optional
import logging

from opentelemetry import trace, context as otel_context
from opentelemetry.propagate import extract
from opentelemetry.trace import SpanKind, Status, StatusCode
from opentelemetry.propagators.textmap import Getter

from fastmcp.server.middleware import Middleware, MiddlewareContext, CallNext

logger = logging.getLogger(__name__)


class MCPHeaderGetter(Getter):
    """
    Getter implementation to extract trace context from HTTP headers in MCP requests.

    This handles the extraction of W3C trace context headers (traceparent, tracestate)
    from the incoming HTTP request to enable distributed tracing.
    """

    def get(self, carrier: dict, key: str) -> Optional[list[str]]:
        """
        Get a header value from the carrier.

        Args:
            carrier: Dictionary of HTTP headers
            key: Header name to retrieve

        Returns:
            List containing the header value, or None if not found
        """
        if not carrier:
            return None

        # HTTP headers are case-insensitive, normalize to lowercase
        key_lower = key.lower()

        # Try to find the header with case-insensitive matching
        for header_key, header_value in carrier.items():
            if header_key.lower() == key_lower:
                # Return as a list for consistency with OpenTelemetry API
                if isinstance(header_value, list):
                    return header_value
                return [str(header_value)]

        return None

    def keys(self, carrier: dict) -> list[str]:
        """
        Get all header keys from the carrier.

        Args:
            carrier: Dictionary of HTTP headers

        Returns:
            List of all header keys
        """
        return list(carrier.keys()) if carrier else []


# Global instance of the header getter
mcp_header_getter = MCPHeaderGetter()


class OpenTelemetryMiddleware(Middleware):
    """
    FastMCP middleware that adds OpenTelemetry tracing to MCP operations.

    This middleware:
    - Extracts parent trace context from incoming HTTP headers (W3C trace context)
    - Creates spans for each MCP operation with appropriate attributes
    - Propagates the trace context through the request lifecycle
    - Handles errors and sets span status appropriately

    The middleware uses the global OpenTelemetry tracer provider and creates
    a tracer named "fastmcp.server".
    """

    def __init__(self, **kwargs):
        """
        Initialize the OpenTelemetry middleware.

        Args:
            **kwargs: Additional arguments (ignored, for FastMCP compatibility)
        """
        super().__init__()
        try:
            # Use the global tracer - this ensures we pick up any configured tracer provider
            self.tracer = trace.get_tracer("fastmcp.server")
            logger.info("Initialized OpenTelemetry middleware successfully")
        except Exception as e:
            logger.error(f"Failed to initialize OpenTelemetry middleware: {e}")
            raise

    def _create_span_attributes(self, ctx: MiddlewareContext) -> dict[str, Any]:
        """
        Create span attributes from the middleware context.

        Args:
            ctx: The middleware context

        Returns:
            Dictionary of span attributes
        """
        attributes = {}

        # Add MCP-specific attributes
        if ctx.method:
            attributes["mcp.method"] = ctx.method

        attributes["mcp.source"] = ctx.source
        attributes["mcp.type"] = ctx.type

        # Add timestamp
        if ctx.timestamp:
            attributes["mcp.timestamp"] = ctx.timestamp.isoformat()

        # Add message type information if available
        if hasattr(ctx.message, "__class__"):
            attributes["mcp.message.type"] = ctx.message.__class__.__name__

        return attributes

    async def on_message(
        self,
        ctx: MiddlewareContext[Any],
        call_next: CallNext[Any, Any],
    ) -> Any:
        """
        Handle all MCP messages by creating a span and propagating context.

        This is the main entry point for the middleware. It:
        1. Extracts parent trace context from HTTP headers
        2. Creates a span for the operation
        3. Adds relevant attributes to the span
        4. Propagates the context through the call chain
        5. Handles errors and sets span status

        Args:
            ctx: The middleware context containing the message and metadata
            call_next: Callable to invoke the next middleware or handler

        Returns:
            The result from the next middleware/handler
        """
        try:
            # Extract HTTP headers for context propagation
            headers = (
                ctx.fastmcp_context.request_context.request.headers
                if ctx.fastmcp_context
                else {}
            )

            # Extract parent trace context from headers (W3C trace context)
            # This enables distributed tracing by linking this span to the parent trace
            parent_context = extract(headers, getter=mcp_header_getter)

            # Determine span name based on the MCP method
            span_name = f"mcp.{ctx.method}" if ctx.method else "mcp.message"

            # Create attributes for the span
            attributes = self._create_span_attributes(ctx)

            # Start a new span as a child of the extracted parent context
            # Use SERVER span kind since this is handling an incoming request
            with self.tracer.start_as_current_span(
                span_name,
                context=parent_context,
                kind=SpanKind.SERVER,
                attributes=attributes,
            ) as span:
                try:
                    # Log span creation for debugging
                    if span.is_recording():
                        span_context = span.get_span_context()
                        logger.debug(
                            f"Created span: {span_name} "
                            f"(trace_id={format(span_context.trace_id, '032x')}, "
                            f"span_id={format(span_context.span_id, '016x')})"
                        )

                    # Call the next middleware/handler with the span context set
                    # This ensures downstream operations can access the current span
                    result = await call_next(ctx)

                    # Mark span as successful
                    if span.is_recording():
                        span.set_status(Status(StatusCode.OK))

                    return result

                except Exception as e:
                    # Record the exception and mark span as failed
                    if span.is_recording():
                        span.record_exception(e)
                        span.set_status(
                            Status(
                                StatusCode.ERROR,
                                description=f"{type(e).__name__}: {str(e)}",
                            )
                        )

                    logger.error(
                        f"Error in MCP operation {span_name}: {e}", exc_info=True
                    )

                    # Re-raise the exception to let the caller handle it
                    raise

        except Exception as e:
            # If there's an error with OpenTelemetry itself, log it but don't break the request
            logger.error(
                f"OpenTelemetry middleware error (falling back to untraced execution): {e}",
                exc_info=True,
            )
            # Fall back to calling the next handler without tracing
            return await call_next(ctx)

    async def on_call_tool(
        self,
        ctx: MiddlewareContext[Any],
        call_next: CallNext[Any, Any],
    ) -> Any:
        """
        Handle tool call operations with additional span attributes.

        Args:
            ctx: The middleware context
            call_next: Callable to invoke the next middleware or handler

        Returns:
            The result from the next middleware/handler
        """
        # Extract tool name if available
        tool_name = None
        if hasattr(ctx.message, "name"):
            tool_name = ctx.message.name
        elif hasattr(ctx.message, "params") and hasattr(ctx.message.params, "name"):
            tool_name = ctx.message.params.name

        # Get the current span and add tool-specific attributes
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording() and tool_name:
            current_span.set_attribute("mcp.tool.name", tool_name)

        # Continue to the next handler
        return await call_next(ctx)

    async def on_read_resource(
        self,
        ctx: MiddlewareContext[Any],
        call_next: CallNext[Any, Any],
    ) -> Any:
        """
        Handle resource read operations with additional span attributes.

        Args:
            ctx: The middleware context
            call_next: Callable to invoke the next middleware or handler

        Returns:
            The result from the next middleware/handler
        """
        # Extract resource URI if available
        resource_uri = None
        if hasattr(ctx.message, "uri"):
            resource_uri = ctx.message.uri
        elif hasattr(ctx.message, "params") and hasattr(ctx.message.params, "uri"):
            resource_uri = ctx.message.params.uri

        # Get the current span and add resource-specific attributes
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording() and resource_uri:
            current_span.set_attribute("mcp.resource.uri", resource_uri)

        # Continue to the next handler
        return await call_next(ctx)

    async def on_get_prompt(
        self,
        ctx: MiddlewareContext[Any],
        call_next: CallNext[Any, Any],
    ) -> Any:
        """
        Handle prompt get operations with additional span attributes.

        Args:
            ctx: The middleware context
            call_next: Callable to invoke the next middleware or handler

        Returns:
            The result from the next middleware/handler
        """
        # Extract prompt name if available
        prompt_name = None
        if hasattr(ctx.message, "name"):
            prompt_name = ctx.message.name
        elif hasattr(ctx.message, "params") and hasattr(ctx.message.params, "name"):
            prompt_name = ctx.message.params.name

        # Get the current span and add prompt-specific attributes
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording() and prompt_name:
            current_span.set_attribute("mcp.prompt.name", prompt_name)

        # Continue to the next handler
        return await call_next(ctx)
