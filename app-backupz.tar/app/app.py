from __future__ import annotations

import asyncio
import base64
import gzip
import json
import os
import signal
import time
import uuid
from typing import AsyncGenerator, Dict

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse, JSONResponse
from opentelemetry.instrumentation.anthropic import AnthropicInstrumentor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from pydantic import BaseModel

from claude_code import (
    claude_code_generator,
    UserMessage,
    TextBlock,
)
from claude_code_defaults import REQUEST_TYPE_INVESTIGATE
from launchdarkly_setup import record_operation_log, start_operation_span
from logger_setup import logger
from vega_auth_middleware import create_vega_auth_middleware

# Initialize Anthropic instrumentation
AnthropicInstrumentor().instrument()

__all__ = ["app"]

app = FastAPI(title="Autofix Claude API", version="0.2.0")
FastAPIInstrumentor.instrument_app(app)

# Idle timeout configuration (1 hour in seconds)
IDLE_TIMEOUT_SECONDS = int(os.getenv("IDLE_TIMEOUT_SECONDS", 3600))
_last_activity_time = time.time()

# SSE keep-alive interval (default 30 seconds) to prevent ALB idle timeout
SSE_KEEPALIVE_INTERVAL_SECONDS = int(os.getenv("SSE_KEEPALIVE_INTERVAL_SECONDS", 30))


def update_activity():
    """Update the last activity timestamp."""
    global _last_activity_time
    _last_activity_time = time.time()


async def idle_timeout_monitor():
    """Background task that monitors for inactivity and shuts down after timeout."""
    while True:
        await asyncio.sleep(60)  # Check every minute
        idle_seconds = time.time() - _last_activity_time
        if idle_seconds >= IDLE_TIMEOUT_SECONDS:
            logger.info(
                f"[app] Idle timeout reached ({idle_seconds:.0f}s >= {IDLE_TIMEOUT_SECONDS}s). Shutting down."
            )
            record_operation_log(
                "Idle timeout reached, shutting down",
                attributes={"idle_seconds": idle_seconds},
            )
            # Send SIGTERM to gracefully shut down
            os.kill(os.getpid(), signal.SIGTERM)
            break


@app.on_event("startup")
async def start_idle_monitor():
    """Start the idle timeout monitor on application startup."""
    if IDLE_TIMEOUT_SECONDS > 0:
        logger.info(f"[app] Starting idle timeout monitor ({IDLE_TIMEOUT_SECONDS}s)")
        asyncio.create_task(idle_timeout_monitor())


# Add Vega Router authentication middleware
# This verifies X-Vega-Target matches this container's IP and validates X-Vega-Signature
create_vega_auth_middleware(app)

# Note: Logging setup is now handled by the centralized logging module

# TODO: Implement message chunking for frontend size restrictions
# Current compression helps but we may still hit browser/network limits
# with very large responses. Consider breaking messages into smaller chunks
# that can be reassembled on the frontend to avoid size restrictions.


@app.get("/health")
async def health_check():
    """Health check endpoint that returns 200 OK."""
    with start_operation_span("health_check"):
        record_operation_log("Health check requested")
        return {"status": "ok"}


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------


class PromptRequest(BaseModel):
    """Shared request body for the simple Claude chat route."""

    prompt: str
    model: str | None = None
    project_id: str


class CodePromptRequest(BaseModel):
    """Request body expected by the Go client (`promptReq` in claude.go)."""

    conversation_id: str | None = None
    prompt: str
    max_turns: int | None = None
    project_id: str
    messages: list[dict] | None = None  # Conversation history from Go backend
    request_type: str = REQUEST_TYPE_INVESTIGATE
    repositories: list[str] | None = None
    system_prompt_template: str | None = None  # System prompt from Go backend AI config


class ConversationResponse(BaseModel):
    conversation_id: str


class JudgeRequest(BaseModel):
    """Request body for the judge endpoint."""

    prompt: str  # The full judging prompt
    max_tokens: int = 2000
    temperature: float = 0.1  # Low temperature for consistent scoring


class JudgeResponse(BaseModel):
    """Response from the judge endpoint."""

    response: str
    model: str
    usage: dict | None = None


# ---------------------------------------------------------------------------
# Judge endpoint for evaluation harness
# ---------------------------------------------------------------------------


@app.post("/claude/judge", response_model=JudgeResponse)
async def judge_response(body: JudgeRequest):
    """Synchronous endpoint for judging AI agent responses.
    This endpoint uses Claude to evaluate agent responses against rubric criteria.
    Unlike the streaming /claude/code endpoint, this returns a complete JSON response.
    """
    import anthropic
    from env import env

    with start_operation_span(
        "judge_request",
        {
            "prompt_length": len(body.prompt),
            "max_tokens": body.max_tokens,
            "temperature": body.temperature,
        },
    ):
        record_operation_log(
            "Judge request received",
            attributes={
                "prompt_length": len(body.prompt),
            },
        )

        logger.info(
            f"[app] Received /claude/judge request: prompt_len={len(body.prompt)}"
        )

        try:
            # Create Bedrock client using AWS credentials
            client = anthropic.AnthropicBedrock(
                aws_region=env["AWS_REGION"],
            )

            # Use the Bedrock model ID format
            model = env["ANTHROPIC_SMALL_FAST_MODEL"]
            logger.info(
                f"[app] Using Bedrock with model: {model}, region: {env['AWS_REGION']}"
            )

            response = client.messages.create(
                model=model,
                max_tokens=body.max_tokens,
                temperature=body.temperature,
                messages=[{"role": "user", "content": body.prompt}],
            )

            # Extract the text response
            response_text = ""
            for block in response.content:
                if hasattr(block, "text"):
                    response_text += block.text

            usage_dict = None
            if response.usage:
                usage_dict = {
                    "input_tokens": response.usage.input_tokens,
                    "output_tokens": response.usage.output_tokens,
                }

            logger.info(
                f"[app] Judge response completed: model={model}, response_len={len(response_text)}"
            )

            record_operation_log(
                "Judge response completed",
                attributes={
                    "model": model,
                    "response_length": len(response_text),
                    "input_tokens": usage_dict.get("input_tokens") if usage_dict else 0,
                    "output_tokens": (
                        usage_dict.get("output_tokens") if usage_dict else 0
                    ),
                },
            )

            return JudgeResponse(
                response=response_text,
                model=model,
                usage=usage_dict,
            )

        except Exception as exc:
            logger.exception(f"[app] Exception in judge endpoint: {exc}")
            record_operation_log(
                f"Judge error: {exc}",
                attributes={"error": str(exc)},
            )
            raise HTTPException(status_code=500, detail=str(exc))


# ---------------------------------------------------------------------------
# In-memory conversation registry
# ---------------------------------------------------------------------------

# TODO(vkorolik) this is an in-memory queue; switch to redis when we scale to a multi-node deploy.
_queues: Dict[str, "asyncio.Queue[dict]"] = {}


# ---------------------------------------------------------------------------
# Conversation history helpers
# ---------------------------------------------------------------------------


def _convert_go_messages_to_claude_messages(go_messages: list[dict]) -> list:
    """Convert Go backend message format to Claude SDK Message objects."""
    from claude_code import convert_db_messages_to_claude_messages

    # The Go messages come in the format of AgentConversationMessage
    # We need to convert them to the format expected by convert_db_messages_to_claude_messages
    class MockDBMessage:
        def __init__(self, msg_dict):
            self.Role = msg_dict.get("role")
            self.Content = msg_dict.get("content")
            self.Turn = msg_dict.get("turn")
            self.IsFinal = msg_dict.get("is_final", False)

    db_messages = [MockDBMessage(msg) for msg in go_messages]
    return convert_db_messages_to_claude_messages(db_messages)


# Note: Message storage functions removed since the Go backend now handles
# all message storage via the store methods and claude_code_generator auto-storage


# ---------------------------------------------------------------------------
# Claude Code endpoints compatible with observability/backend/agent/claude.go
# ---------------------------------------------------------------------------


@app.post("/claude/code", response_model=ConversationResponse)
async def create_claude_conversation(body: CodePromptRequest, request: Request):
    """Start (or continue) a Claude Code conversation.

    The Go helper sends the initial prompt here and expects a JSON reply:
        {"conversation_id": "..."}
    Streaming happens via the companion GET /claude/code/stream endpoint.
    """
    update_activity()

    # Re-use provided ID or assign a new one.
    conv_id = body.conversation_id or str(uuid.uuid4())

    with start_operation_span(
        "claude_conversation",
        {
            "conversation_id": conv_id,
            "project_id": body.project_id,
            "has_existing_conversation": body.conversation_id is not None,
            "prompt_length": len(body.prompt),
            "max_turns": body.max_turns or 0,
        },
    ):
        record_operation_log(
            f"Claude conversation request received",
            attributes={
                "conversation_id": conv_id,
                "project_id": body.project_id,
                "is_continuation": body.conversation_id is not None,
            },
        )

        logger.info(
            f"[app] Received /claude/code request: conversation_id={body.conversation_id}, project_id={body.project_id}, max_turns={body.max_turns}"
        )
        logger.debug(f"[app] Prompt length: {len(body.prompt)}")

        # Ensure a queue exists for this conversation.
        queue: asyncio.Queue[dict] = _queues.setdefault(conv_id, asyncio.Queue())
        logger.debug(
            f"[app] Queue for conversation_id={conv_id} exists: {queue is not None}"
        )

        # Kick off background streaming task only on first prompt (new conversation).
        if body.conversation_id is None:
            logger.info(f"[app] Starting new conversation: {conv_id}")
            record_operation_log(
                "Starting new Claude conversation",
                attributes={"conversation_id": conv_id},
            )

            async def _run_generator() -> None:
                turn = 0
                logger.info(f"[app] Starting generator for conversation {conv_id}")
                with start_operation_span(
                    "claude_generation", {"conversation_id": conv_id, "type": "new"}
                ):
                    try:
                        # Note: User message storage is now handled by Go backend and claude_code_generator
                        logger.debug(
                            f"[app] Calling claude_code_generator with: prompt_len={len(body.prompt)}, max_turns={body.max_turns}, project_id={body.project_id}"
                        )
                        async for chunk in claude_code_generator(
                            prompt=body.prompt,
                            max_turns=body.max_turns,
                            headers=dict(request.headers),
                            project_id=body.project_id,
                            request_type=body.request_type,
                            system_prompt_template=body.system_prompt_template,
                            repositories=body.repositories,
                        ):
                            turn += 1
                            logger.debug(
                                f"[app] Conversation {conv_id}: turn={turn}, chunk_len={len(chunk)}"
                            )
                            if not chunk.strip():
                                logger.warning(
                                    f"[app] Received empty/whitespace-only chunk for conversation {conv_id}, turn {turn}"
                                )
                            await queue.put(
                                {"text": chunk, "turn": turn, "is_final": False}
                            )
                    except Exception as exc:  # noqa: BLE001
                        logger.exception(
                            f"[app] Exception in conversation {conv_id}: {exc}"
                        )
                        record_operation_log(
                            f"Exception in conversation: {exc}",
                            attributes={"conversation_id": conv_id, "error": str(exc)},
                        )
                        await queue.put(
                            {"text": f"[error: {exc}]", "turn": turn, "is_final": True}
                        )
                    finally:
                        logger.info(
                            f"[app] Conversation {conv_id} finished (new conversation)."
                        )
                        record_operation_log(
                            "Conversation completed",
                            attributes={"conversation_id": conv_id, "turns": turn},
                        )
                        await queue.put({"text": "", "turn": turn, "is_final": True})

            asyncio.create_task(_run_generator())

        # If conversation_id was provided, continue the existing conversation with full history
        elif body.prompt:
            logger.info(f"[app] Continuing conversation: {conv_id} with new prompt.")
            record_operation_log(
                "Continuing Claude conversation with history",
                attributes={"conversation_id": conv_id},
            )

            async def _run_generator_continue() -> None:
                turn = 0
                logger.info(
                    f"[app] Starting continued generator for conversation {conv_id}"
                )
                with start_operation_span(
                    "claude_generation",
                    {"conversation_id": conv_id, "type": "continue"},
                ):
                    try:
                        # Use conversation history provided by Go backend
                        messages = []
                        if body.messages:
                            logger.debug(
                                f"[app] Using conversation history from Go backend: {len(body.messages)} messages"
                            )
                            # Convert Go backend message format to Claude SDK format
                            messages = _convert_go_messages_to_claude_messages(
                                body.messages
                            )

                        # Add the new user message
                        new_user_message = UserMessage(
                            content=[TextBlock(text=body.prompt)]
                        )
                        messages.append(new_user_message)

                        logger.debug(
                            f"[app] Calling claude_code_generator (continue) with {len(messages)} messages, max_turns={body.max_turns}, project_id={body.project_id}"
                        )

                        # Call claude_code_generator with full message history
                        async for chunk in claude_code_generator(
                            messages=messages,
                            max_turns=body.max_turns,
                            headers=dict(request.headers),
                            project_id=body.project_id,
                            request_type=body.request_type,
                            system_prompt_template=body.system_prompt_template,
                            repositories=body.repositories,
                        ):
                            turn += 1
                            logger.debug(
                                f"[app] Conversation {conv_id} (continue): turn={turn}, chunk_len={len(chunk)}"
                            )
                            if not chunk.strip():
                                logger.warning(
                                    f"[app] Received empty/whitespace-only chunk for continued conversation {conv_id}, turn {turn}"
                                )
                            await queue.put(
                                {"text": chunk, "turn": turn, "is_final": False}
                            )
                        logger.info(
                            f"[app] Conversation {conv_id} finished (continued)."
                        )
                        record_operation_log(
                            "Conversation continued completed",
                            attributes={"conversation_id": conv_id, "turns": turn},
                        )
                        await queue.put({"text": "", "turn": turn, "is_final": True})
                    except Exception as exc:
                        logger.exception(
                            f"[app] Exception in continued conversation {conv_id}: {exc}"
                        )
                        record_operation_log(
                            f"Exception in continued conversation: {exc}",
                            attributes={"conversation_id": conv_id, "error": str(exc)},
                        )
                        await queue.put(
                            {"text": f"[error: {exc}]", "turn": turn, "is_final": True}
                        )

            asyncio.create_task(_run_generator_continue())

        logger.debug(f"[app] Returning conversation_id={conv_id} to client.")
        return JSONResponse(content={"conversation_id": conv_id})


@app.get("/claude/code/stream")
async def stream_claude_conversation(conversation_id: str):
    """Server-Sent Events endpoint that streams Claude Code responses."""
    update_activity()

    with start_operation_span("claude_stream", {"conversation_id": conversation_id}):
        record_operation_log(
            "Stream requested", attributes={"conversation_id": conversation_id}
        )
        logger.info(
            f"[app] Client requested stream for conversation_id={conversation_id}"
        )

        if conversation_id not in _queues:
            logger.warning(
                f"[app] Unknown conversation_id requested: {conversation_id}"
            )
            record_operation_log(
                "Unknown conversation_id requested",
                attributes={"conversation_id": conversation_id},
            )
            raise HTTPException(status_code=404, detail="unknown conversation_id")

        queue = _queues[conversation_id]

        async def _event_source() -> AsyncGenerator[bytes, None]:
            """Yield SSE data lines from the conversation queue."""
            event_count = 0
            try:
                while True:
                    logger.debug(
                        f"[app] Waiting for event from queue for conversation_id={conversation_id}"
                    )
                    # Use timeout to send keep-alive comments and prevent ALB idle timeout
                    try:
                        event = await asyncio.wait_for(
                            queue.get(), timeout=SSE_KEEPALIVE_INTERVAL_SECONDS
                        )
                    except asyncio.TimeoutError:
                        # Send SSE comment as keep-alive (ignored by clients, keeps connection alive)
                        yield b": keep-alive\n\n"
                        continue
                    update_activity()  # Keep alive during active streaming
                    event_count += 1
                    text_len = len(event.get("text", ""))
                    logger.debug(
                        f"[app] Streaming event for conversation_id={conversation_id}: turn={event.get('turn')}, is_final={event.get('is_final')}, text_len={text_len}"
                    )

                    try:
                        # Get the original text content to compress
                        original_text = event.get("text", "")

                        if original_text.strip():
                            # Compress the original text content from claude_code.py
                            compressed_data = gzip.compress(
                                original_text.encode("utf-8")
                            )
                            # Base64 encode to make it text-safe for SSE
                            encoded_data = base64.b64encode(compressed_data).decode(
                                "ascii"
                            )

                            # Create event with compressed text
                            compressed_event = {
                                "text": encoded_data,
                                "turn": event.get("turn"),
                                "is_final": event.get("is_final"),
                            }
                        else:
                            # No text content, send as-is
                            compressed_event = {
                                "text": original_text,
                                "turn": event.get("turn"),
                                "is_final": event.get("is_final"),
                            }

                        final_data = json.dumps(compressed_event)

                        # Sentinel for completion – the final event has is_final True; we still
                        # send it to the client, then keep listening for more messages.
                        sse_message = f"data: {final_data}\n\n"
                        yield sse_message.encode()

                    except Exception as e:
                        logger.error(f"[app] Error encoding/streaming event: {e}")
                        # Send error event instead
                        error_event = {
                            "text": "[SSE encoding error]",
                            "turn": event.get("turn"),
                            "is_final": True,
                        }
                        yield f"data: {json.dumps(error_event)}\n\n".encode()

                    if event.get("is_final"):
                        # Don't break or clean up - keep the stream alive for potential continuations
                        logger.info(
                            f"[app] Message sequence completed for conversation_id={conversation_id}, keeping stream alive for continuations"
                        )
                        record_operation_log(
                            "Message sequence completed",
                            attributes={
                                "conversation_id": conversation_id,
                                "events_streamed": event_count,
                            },
                        )
                        # Don't break here - keep listening for more messages in continued conversations
                        # The queue and history will be cleaned up when the client disconnects
            finally:
                # Clean up when client disconnects
                logger.info(
                    f"[app] Client disconnected, cleaning up conversation_id={conversation_id}"
                )
                _queues.pop(conversation_id, None)
                record_operation_log(
                    "Stream disconnected and cleaned up",
                    attributes={"conversation_id": conversation_id},
                )

        return StreamingResponse(_event_source(), media_type="text/event-stream")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app=app, host="0.0.0.0", port=8000, log_level="debug")
